using System.Text.Json;
using VisionTrainer.Core;
using VisionTrainer.Data;
using VisionTrainer.Engine;

namespace VisionTrainer.Vision;

public sealed class PreAnnotationResult
{
    public int TotalImages { get; set; }
    public int TotalBoxes { get; set; }
    public int SkippedImages { get; set; }
    /// <summary>模型给出的类别在工程类别表里找不到时，这些框被丢弃，数量记在这里。</summary>
    public int DroppedBoxes { get; set; }
    public List<string> ModelClassNames { get; } = new();
    public List<string> UnmatchedClassNames { get; } = new();
    public List<string> Notes { get; } = new();
    public bool Succeeded => TotalBoxes > 0;
}

/// <summary>
/// AI 预标注桥接。
///
/// 设计前提（很重要）：预标注必须有"已有模型"。新客户没有任何模型时，
/// 只能用通用 COCO 模型，而它只认人、车、瓶子等 80 类，认不出"划痕""缺件"。
///
/// 所以这里的策略是"尽力而为 + 明确告知"，绝不硬报错：
///  - 模型类别 ∩ 工程类别 有交集 → 只保留交集部分的框
///  - 完全无交集 → 返回 Succeeded=false，并给出可读原因，UI 引导客户改用纯手工
/// 客户第一次用会看到"AI 帮不上忙，请先手工标 20 张"，第二次训练后就能用了。
/// </summary>
public interface IPreAnnotator
{
    Task<PreAnnotationResult> RunAsync(
        AnnotationProject project,
        string modelPath,
        double confidence,
        IProgress<(int Done, int Total, string Message)>? progress,
        CancellationToken ct);
}

public sealed class YoloPreAnnotator : IPreAnnotator
{
    private readonly PythonEnvironment _env;
    private readonly Action<string> _log;

    public YoloPreAnnotator(PythonEnvironment env, Action<string>? log = null)
    {
        _env = env;
        _log = log ?? (_ => { });
    }

    public async Task<PreAnnotationResult> RunAsync(
        AnnotationProject project,
        string modelPath,
        double confidence,
        IProgress<(int, int, string)>? progress,
        CancellationToken ct)
    {
        var result = new PreAnnotationResult();

        if (!File.Exists(modelPath))
            throw new FileNotFoundException("找不到模型文件。请先在「训练」页训练一个模型，或选择一个已有的 .pt 文件。", modelPath);

        if (project.Images.Count == 0)
            throw new InvalidOperationException("工程里还没有图片。");

        var script = Path.Combine(AppContext.BaseDirectory, "resources", "python", "predict.py");
        if (!File.Exists(script))
            throw new FileNotFoundException("推理脚本缺失，安装包可能不完整。", script);

        var outJson = Path.Combine(project.RootPath, "prelabel.json");
        var namesJson = JsonSerializer.Serialize(
            project.Classes.OrderBy(c => c.Index).ToDictionary(c => c.Index, c => c.Name));

        var args = new List<string>
        {
            script,
            "--model", modelPath,
            "--images", project.ImagesDir,
            "--out", outJson,
            "--conf", confidence.ToString(System.Globalization.CultureInfo.InvariantCulture),
            "--names-json", namesJson,
        };

        var runner = new ProcessRunner();
        int processed = 0;
        runner.Output += line =>
        {
            _log(line);
            // predict.py 每处理完一张打印 "[PROGRESS] n/total"
            if (line.StartsWith("[PROGRESS]", StringComparison.Ordinal))
            {
                var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 2 && parts[1].Contains('/'))
                {
                    var seg = parts[1].Split('/');
                    if (int.TryParse(seg[0], out var d) && int.TryParse(seg[1], out var t))
                    {
                        processed = d;
                        progress?.Report((d, t, $"正在识别 {d}/{t}"));
                    }
                }
            }
        };
        runner.ErrorOutput += line => _log("[stderr] " + line);

        var code = await runner.RunAsync(
            _env.PythonExe, args, project.RootPath, _env.BuildEnvironment(), ct);

        if (code != 0)
        {
            var tail = string.Join('\n', runner.RecentLines.TakeLast(30));
            throw new InvalidOperationException(
                "AI 预标注失败。请确认已选好模型文件，且运行环境正常。\n\n" + tail);
        }

        if (!File.Exists(outJson))
            throw new InvalidOperationException("推理没有产出结果文件，请重试。");

        ApplyResult(project, outJson, result);
        progress?.Report((project.Images.Count, project.Images.Count, "预标注完成"));
        return result;
    }

    private static void ApplyResult(AnnotationProject project, string jsonPath, PreAnnotationResult result)
    {
        using var doc = JsonDocument.Parse(File.ReadAllText(jsonPath));
        var root = doc.RootElement;

        if (root.TryGetProperty("model_classes", out var mc))
            foreach (var c in mc.EnumerateArray()) result.ModelClassNames.Add(c.GetString() ?? "");

        // 工程类别名（忽略大小写）→ 序号
        var projectClass = project.Classes
            .GroupBy(c => c.Name.Trim(), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.First().Index, StringComparer.OrdinalIgnoreCase);

        var unmatched = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var byFile = new Dictionary<string, List<BoundingBox>>(StringComparer.OrdinalIgnoreCase);

        if (root.TryGetProperty("images", out var images))
        {
            foreach (var img in images.EnumerateArray())
            {
                var fileName = img.GetProperty("file").GetString() ?? "";
                var boxes = new List<BoundingBox>();
                result.TotalImages++;

                if (img.TryGetProperty("boxes", out var arr))
                {
                    foreach (var b in arr.EnumerateArray())
                    {
                        var clsName = b.GetProperty("class_name").GetString() ?? "";
                        if (!projectClass.TryGetValue(clsName, out var idx))
                        {
                            unmatched.Add(clsName);
                            result.DroppedBoxes++;
                            continue;
                        }

                        var box = new BoundingBox
                        {
                            ClassIndex = idx,
                            Cx = b.GetProperty("cx").GetDouble(),
                            Cy = b.GetProperty("cy").GetDouble(),
                            W = b.GetProperty("w").GetDouble(),
                            H = b.GetProperty("h").GetDouble(),
                            FromAi = true,
                        };
                        if (box.IsValid) boxes.Add(box);
                    }
                }

                byFile[fileName] = boxes;
            }
        }

        result.UnmatchedClassNames.AddRange(unmatched);

        // 把结果合并到工程：AI 只补空图，不覆盖客户已手工标的内容
        foreach (var img in project.Images)
        {
            if (!byFile.TryGetValue(img.FileName, out var boxes) || boxes.Count == 0)
            {
                result.SkippedImages++;
                continue;
            }

            if (img.HasAnnotations)
            {
                // 已有手工标注：保留人工结果，AI 结果丢弃（人工永远优先）
                result.Notes.Add($"{img.FileName} 已有手工标注，AI 结果已跳过。");
                continue;
            }

            img.Boxes.AddRange(boxes);
            img.IsDirty = true;
            result.TotalBoxes += boxes.Count;
        }

        if (result.DroppedBoxes > 0 && unmatched.Count > 0)
        {
            result.Notes.Add(
                $"模型认出了 {unmatched.Count} 个工程里没有的类别（{string.Join("、", unmatched.Take(5))}），" +
                $"共 {result.DroppedBoxes} 个框未采用。请检查类别名是否与模型一致。");
        }
    }
}
