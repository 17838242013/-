using System.Text.Json;
using VisionTrainer.Core;
using VisionTrainer.Engine;

namespace VisionTrainer.Vision;

/// <summary>单张图片的检测结果（像素坐标）。</summary>
public sealed class DetectionBox
{
    public int ClassId { get; init; }
    public string ClassName { get; init; } = "";
    /// <summary>归一化中心坐标与宽高（0~1）。</summary>
    public double Cx { get; init; }
    public double Cy { get; init; }
    public double W { get; init; }
    public double H { get; init; }
    public double Score { get; init; }
}

public sealed class DetectionResult
{
    public string ImagePath { get; init; } = "";
    public string VisPath { get; init; } = "";
    public int Width { get; init; }
    public int Height { get; init; }
    public List<DetectionBox> Boxes { get; } = new();
}

public sealed class VerifyOutput
{
    public List<string> ModelClasses { get; } = new();
    public List<DetectionResult> Results { get; } = new();
    public string Device { get; set; } = "";
    /// <summary>结果保存目录（画好框的图/视频都在这里）。</summary>
    public string? SaveDir { get; set; }

    /// <summary>视频模式的结果摘要。</summary>
    public VideoSummaryInfo? Video { get; set; }
    /// <summary>摄像头模式的结果摘要。</summary>
    public CameraSummaryInfo? Camera { get; set; }
}

public sealed class VideoSummaryInfo
{
    public int Frames { get; set; }
    public int TotalBoxes { get; set; }
    public string SavedVideo { get; set; } = "";
    public int Width { get; set; }
    public int Height { get; set; }
}

public sealed class CameraSummaryInfo
{
    public int Frames { get; set; }
    public int TotalBoxes { get; set; }
    public string SavedVideo { get; set; } = "";
}

/// <summary>
/// 模型验证推理桥接：跑 verify.py，解析 JSON 结果。
/// 与预标注不同，这里不做类别过滤——验证页要展示模型"真实认出的一切"，
/// 包括它多检/误检的部分，否则客户看不到模型的问题。
/// </summary>
public sealed class ModelVerifier
{
    private readonly PythonEnvironment _env;
    private readonly Action<string> _log;

    public ModelVerifier(PythonEnvironment env, Action<string>? log = null)
    {
        _env = env;
        _log = log ?? (_ => { });
    }

    /// <summary>
    /// 对一批图片或视频推理。图片可混合文件与目录。
    /// videoPath 传视频文件时走视频模式（输出标注视频）。
    /// </summary>
    public async Task<VerifyOutput> RunAsync(
        string modelPath, IEnumerable<string> images, double confidence,
        IProgress<(int Done, int Total)>? progress, CancellationToken ct,
        bool saveVideo = false)
    {
        if (!File.Exists(modelPath))
            throw new FileNotFoundException("模型文件不存在。", modelPath);

        var script = Path.Combine(AppContext.BaseDirectory, "resources", "python", "verify.py");
        if (!File.Exists(script))
            throw new FileNotFoundException("推理脚本缺失，安装包可能不完整。", script);

        var pathList = images.Where(p => File.Exists(p) || Directory.Exists(p)).ToList();
        if (pathList.Count == 0)
            throw new InvalidOperationException("没有可处理的图片。");

        // 区分视频与图片：视频走 --video 单文件参数
        var videoFile = saveVideo
            ? pathList.FirstOrDefault(p => File.Exists(p) &&
                new[] { ".mp4", ".avi", ".mov", ".mkv", ".wmv" }.Contains(Path.GetExtension(p).ToLowerInvariant()))
            : null;

        var saveDir = Path.Combine(AppPaths.DataRoot, "verify", DateTime.Now.ToString("yyyyMMdd_HHmmss"));

        var args = new List<string>
        {
            script,
            "--model", modelPath,
            "--save-dir", saveDir,
            "--conf", confidence.ToString(System.Globalization.CultureInfo.InvariantCulture),
        };

        if (videoFile is not null)
        {
            args.Add("--video");
            args.Add(videoFile);
        }
        else
        {
            // nargs="*" 要把每张图作为独立参数传
            foreach (var p in pathList)
            {
                args.Add("--images");
                args.Add(p);
            }
        }

        var output = await LaunchAsync(modelPath, args, progress, ct);
        output.SaveDir = saveDir;
        return output;
    }

    /// <summary>
    /// 摄像头实时检测：弹出 Python/OpenCV 窗口实时画框，按 Q 或关窗口结束。
    /// 可选把检测画面录制成视频。结束返回帧数统计。
    /// </summary>
    public async Task<VerifyOutput> RunCameraAsync(
        string modelPath, int cameraIndex, double confidence,
        bool record, CancellationToken ct)
    {
        if (!File.Exists(modelPath))
            throw new FileNotFoundException("模型文件不存在。", modelPath);

        var script = Path.Combine(AppContext.BaseDirectory, "resources", "python", "verify.py");
        if (!File.Exists(script))
            throw new FileNotFoundException("推理脚本缺失，安装包可能不完整。", script);

        var saveDir = Path.Combine(AppPaths.DataRoot, "verify",
            "camera_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"));

        var args = new List<string>
        {
            script,
            "--model", modelPath,
            "--save-dir", saveDir,
            "--conf", confidence.ToString(System.Globalization.CultureInfo.InvariantCulture),
            "--camera", Math.Max(0, cameraIndex).ToString(),
        };
        if (record) args.Add("--save-camera");

        var output = await LaunchAsync(modelPath, args, null, ct);
        output.SaveDir = saveDir;
        return output;
    }

    private async Task<VerifyOutput> LaunchAsync(
        string modelPath, List<string> args,
        IProgress<(int Done, int Total)>? progress, CancellationToken ct)
    {
        var runner = new ProcessRunner();
        var stdoutLines = new List<string>();
        runner.Output += line =>
        {
            _log(line);
            stdoutLines.Add(line);
            if (line.StartsWith("[PROGRESS]", StringComparison.Ordinal))
            {
                var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 2 && parts[1].Contains('/'))
                {
                    var seg = parts[1].Split('/');
                    if (int.TryParse(seg[0], out var d) && int.TryParse(seg[1], out var t))
                        progress?.Report((d, t));
                }
            }
        };
        runner.ErrorOutput += line => _log("[stderr] " + line);

        var code = await runner.RunAsync(
            _env.PythonExe, args, AppPaths.DataRoot, _env.BuildEnvironment(), ct);

        if (code != 0)
        {
            var tail = string.Join('\n', runner.RecentLines.TakeLast(30));
            throw new InvalidOperationException("检测失败：\n" + tail);
        }

        // 结果 JSON 在最后一行，前缀 __RESULT__
        var resultLine = stdoutLines.LastOrDefault(l => l.StartsWith("__RESULT__", StringComparison.Ordinal))
            ?? throw new InvalidOperationException("推理没有返回结果。");
        return Parse(resultLine["__RESULT__".Length..]);
    }

    /// <summary>公开给冒烟测试：JSON 结构与 verify.py 的约定必须同步验证。</summary>
    public static VerifyOutput Parse(string json)
    {
        var output = new VerifyOutput();
        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;

        if (root.TryGetProperty("model_classes", out var mc))
            foreach (var c in mc.EnumerateArray()) output.ModelClasses.Add(c.GetString() ?? "");

        if (root.TryGetProperty("results", out var results))
        {
            foreach (var r in results.EnumerateArray())
            {
                var dr = new DetectionResult
                {
                    ImagePath = r.GetProperty("image").GetString() ?? "",
                    VisPath = r.TryGetProperty("vis_path", out var vp) ? vp.GetString() ?? "" : "",
                    Width = r.TryGetProperty("width", out var w) ? w.GetInt32() : 0,
                    Height = r.TryGetProperty("height", out var h) ? h.GetInt32() : 0,
                };
                if (r.TryGetProperty("boxes", out var boxes))
                {
                    foreach (var b in boxes.EnumerateArray())
                    {
                        dr.Boxes.Add(new DetectionBox
                        {
                            ClassId = b.GetProperty("class_id").GetInt32(),
                            ClassName = b.GetProperty("class_name").GetString() ?? "",
                            Cx = b.GetProperty("cx").GetDouble(),
                            Cy = b.GetProperty("cy").GetDouble(),
                            W = b.GetProperty("w").GetDouble(),
                            H = b.GetProperty("h").GetDouble(),
                            Score = b.GetProperty("score").GetDouble(),
                        });
                    }
                }
                output.Results.Add(dr);
            }
        }

        // 视频模式摘要
        if (root.TryGetProperty("video", out var video))
        {
            output.Video = new VideoSummaryInfo
            {
                Frames = video.TryGetProperty("video", out var vf) ? vf.GetInt32() : 0,
                TotalBoxes = video.TryGetProperty("total_boxes", out var vb) ? vb.GetInt32() : 0,
                SavedVideo = video.TryGetProperty("saved", out var vs) ? vs.GetString() ?? "" : "",
                Width = video.TryGetProperty("width", out var vw) ? vw.GetInt32() : 0,
                Height = video.TryGetProperty("height", out var vh) ? vh.GetInt32() : 0,
            };
        }

        // 摄像头模式摘要
        if (root.TryGetProperty("camera", out var cam))
        {
            output.Camera = new CameraSummaryInfo
            {
                Frames = cam.TryGetProperty("camera", out var cf) ? cf.GetInt32() : 0,
                TotalBoxes = cam.TryGetProperty("total_boxes", out var cb) ? cb.GetInt32() : 0,
                SavedVideo = cam.TryGetProperty("saved", out var cs) ? cs.GetString() ?? "" : "",
            };
        }
        return output;
    }
}
