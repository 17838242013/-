using VisionTrainer.Core;
using VisionTrainer.Engine;
using VisionTrainer.Engine.Pipelines;

namespace VisionTrainer.Pipeline;

/// <summary>
/// 训练任务编排器：串起"环境 → 数据 → 训练 → 落盘"。
/// 与 UI 完全解耦，WinForm / 控制台 / 未来的服务端都能复用。
/// </summary>
public sealed class JobRunner
{
    private readonly AppSettings _settings;
    private readonly Action<string> _platformLog;

    public JobRunner(AppSettings settings, Action<string>? platformLog = null)
    {
        _settings = settings;
        _platformLog = platformLog ?? (_ => { });
    }

    public static void BootstrapPipelines()
    {
        PipelineRegistry.Register(new DetectionPipeline());
        // 后续扩展（不实现也能编译，UI 会自动灰掉对应选项）：
        //   PipelineRegistry.Register(new ClassificationPipeline());
        //   PipelineRegistry.Register(new OcrPipeline());
        //   PipelineRegistry.Register(new LlmFinetunePipeline());
    }

    public async Task<TrainingJob> RunAsync(
        TrainingJob job,
        IProgress<TrainingProgress>? progress,
        CancellationToken ct)
    {
        AppPaths.EnsureCreated();
        job.WorkDirectory = AppPaths.NewProjectDir(job.Name);
        var logFile = Path.Combine(job.WorkDirectory, "training.log");

        void Log(string line)
        {
            try { File.AppendAllText(logFile, $"{DateTime.Now:HH:mm:ss} {line}{Environment.NewLine}"); }
            catch { /* 磁盘满或占用时不能让日志拖垮训练 */ }
            progress?.Report(new TrainingProgress { Kind = ProgressKind.Log, Message = line });
        }

        try
        {
            // ---------- 1. 环境 ----------
            job.State = JobState.Preparing;
            progress?.Report(new TrainingProgress { Kind = ProgressKind.Stage, Percent = 0, Message = "检查运行环境" });

            var env = new PythonEnvironment(_settings, log: Log);
            if (!env.IsReady)
            {
                Log("首次使用，正在准备训练环境（仅需一次，约 10~30 分钟）");
                var envProgress = new Progress<PythonEnvironment.ProgressReport>(r =>
                    progress?.Report(new TrainingProgress
                    {
                        Kind = ProgressKind.Stage,
                        Percent = r.Percent * 0.02, // 环境准备占总进度很小一部分
                        Message = r.Stage,
                    }));
                await env.EnsureReadyAsync(job.Profile, envProgress, ct);
            }
            else
            {
                Log("运行环境已就绪");
            }

            // ---------- 2. 训练 ----------
            var pipeline = PipelineRegistry.Get(job.Options.Task);
            var dataset = job.Dataset ?? throw new InvalidOperationException("数据集为空，请先导入数据集。");

            var errors = pipeline.Validate(dataset, job.Options);
            if (errors.Count > 0)
                throw new InvalidOperationException("训练前检查未通过：\n· " + string.Join("\n· ", errors));

            job.State = JobState.Running;
            var ctx = new TrainingContext
            {
                Log = Log,
                OnEpoch = m => progress?.Report(new TrainingProgress { Kind = ProgressKind.Epoch, Metric = m }),
                OnStage = (pct, stage) => progress?.Report(new TrainingProgress
                {
                    Kind = ProgressKind.Stage,
                    Percent = pct,
                    Message = stage,
                }),
                OnRawProgress = _ => { },
                OnArtifact = path => progress?.Report(new TrainingProgress
                {
                    Kind = ProgressKind.Artifact,
                    Message = path,
                }),
            };

            await pipeline.RunAsync(job, env, ctx, ct);

            job.State = JobState.Succeeded;
            job.FinishedAt = DateTime.Now;
            progress?.Report(new TrainingProgress
            {
                Kind = ProgressKind.Stage,
                Percent = 100,
                Message = "训练完成",
            });
        }
        catch (OperationCanceledException)
        {
            job.State = JobState.Canceled;
            job.FinishedAt = DateTime.Now;
            Log("训练已被用户取消");
            progress?.Report(new TrainingProgress { Kind = ProgressKind.Stage, Message = "已取消" });
        }
        catch (Exception ex)
        {
            job.State = JobState.Failed;
            job.ErrorMessage = ex.Message;
            job.FinishedAt = DateTime.Now;
            Log("[错误] " + ex);
            progress?.Report(new TrainingProgress
            {
                Kind = ProgressKind.Error,
                Message = ex.Message,
            });
        }

        // 任务快照落盘，重启软件后能查看历史
        try
        {
            var json = System.Text.Json.JsonSerializer.Serialize(job, SettingsStore.Options);
            await File.WriteAllTextAsync(Path.Combine(job.WorkDirectory, "job.json"), json);
        }
        catch { /* 快照失败不影响主流程 */ }

        return job;
    }
}

public enum ProgressKind
{
    Stage = 0,
    Log = 1,
    Epoch = 2,
    Artifact = 3,
    Error = 4,
}

public sealed class TrainingProgress
{
    public ProgressKind Kind { get; init; }
    public double Percent { get; init; }
    public string Message { get; init; } = "";
    public EpochMetrics? Metric { get; init; }
}
