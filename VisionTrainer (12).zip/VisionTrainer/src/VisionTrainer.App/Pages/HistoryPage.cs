using VisionTrainer.App.UI;
using VisionTrainer.Core;

namespace VisionTrainer.App.Pages;

public sealed class HistoryPage : UserControl, INavigablePage
{
    private readonly MainForm _host;
    private readonly DataGridView _grid = new();
    private readonly Label _empty = new();

    public HistoryPage(MainForm host)
    {
        _host = host;
        BackColor = Theme.Background;

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 78));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var header = new Panel { Dock = DockStyle.Fill };
        header.Controls.Add(new Label
        {
            Text = "历史任务",
            Font = Theme.H1,
            ForeColor = Theme.TextPrimary,
            AutoSize = true,
            Location = new Point(0, 4),
        });
        header.Controls.Add(new Label
        {
            Text = "每次训练的配置、日志与产物都会保存在这里，可以随时打开查看。",
            Font = Theme.SmallFont,
            ForeColor = Theme.TextSecondary,
            AutoSize = true,
            Location = new Point(2, 40),
        });

        var card = new CardPanel { Dock = DockStyle.Fill, Margin = new Padding(0) };

        _grid.Dock = DockStyle.Fill;
        _grid.ReadOnly = true;
        _grid.AllowUserToAddRows = false;
        _grid.RowHeadersVisible = false;
        _grid.BackgroundColor = Theme.Surface;
        _grid.BorderStyle = BorderStyle.None;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _grid.EnableHeadersVisualStyles = false;
        _grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(248, 249, 251);
        _grid.ColumnHeadersDefaultCellStyle.Font = Theme.SmallFont;
        _grid.ColumnHeadersHeight = 32;
        _grid.DefaultCellStyle.Font = Theme.BaseFont;
        _grid.RowTemplate.Height = 34;
        _grid.GridColor = Theme.Border;

        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "name", HeaderText = "任务名称", FillWeight = 30 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "state", HeaderText = "状态", FillWeight = 12 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "map", HeaderText = "最佳 mAP50-95", FillWeight = 16 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "epochs", HeaderText = "轮数", FillWeight = 10 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "time", HeaderText = "完成时间", FillWeight = 20 });
        _grid.Columns.Add(new DataGridViewButtonColumn
        {
            Name = "open",
            HeaderText = "",
            Text = "打开目录",
            UseColumnTextForButtonValue = true,
            FillWeight = 12,
        });

        _grid.CellContentClick += (_, e) =>
        {
            if (e.RowIndex < 0 || _grid.Columns[e.ColumnIndex].Name != "open") return;
            if (_grid.Rows[e.RowIndex].Tag is string dir && Directory.Exists(dir))
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = dir,
                    UseShellExecute = true,
                });
        };

        _empty.Dock = DockStyle.Fill;
        _empty.TextAlign = ContentAlignment.MiddleCenter;
        _empty.Font = Theme.BodyFont;
        _empty.ForeColor = Theme.TextSecondary;
        _empty.Text = "还没有训练记录。";
        _empty.Visible = false;

        card.Controls.Add(_grid);
        card.Controls.Add(_empty);

        root.Controls.Add(header, 0, 0);
        root.Controls.Add(card, 0, 1);
        Controls.Add(root);
    }

    public void OnNavigatedTo() => Reload();

    private void Reload()
    {
        _grid.Rows.Clear();
        if (!Directory.Exists(AppPaths.ProjectsRoot)) return;

        var jobs = new List<TrainingJob>();
        foreach (var dir in Directory.GetDirectories(AppPaths.ProjectsRoot))
        {
            var file = Path.Combine(dir, "job.json");
            if (!File.Exists(file)) continue;
            try
            {
                var job = System.Text.Json.JsonSerializer.Deserialize<TrainingJob>(
                    File.ReadAllText(file), SettingsStore.Options);
                if (job is not null)
                {
                    if (string.IsNullOrEmpty(job.WorkDirectory)) job.WorkDirectory = dir;
                    jobs.Add(job);
                }
            }
            catch
            {
                // 损坏的快照直接跳过，不能让历史页整体崩掉
            }
        }

        foreach (var job in jobs.OrderByDescending(j => j.CreatedAt))
        {
            var idx = _grid.Rows.Add(
                job.Name,
                StateText(job.State),
                job.Best?.Map50_95?.ToString("F4") ?? "-",
                job.Options.Epochs.ToString(),
                job.FinishedAt?.ToString("yyyy-MM-dd HH:mm") ?? "-");
            _grid.Rows[idx].Tag = job.WorkDirectory;

            if (job.State == JobState.Failed)
                _grid.Rows[idx].Cells[1].Style.ForeColor = Theme.Danger;
            else if (job.State == JobState.Succeeded)
                _grid.Rows[idx].Cells[1].Style.ForeColor = Theme.Success;
        }

        _empty.Visible = _grid.Rows.Count == 0;
    }

    private static string StateText(JobState state) => state switch
    {
        JobState.Succeeded => "完成",
        JobState.Failed => "失败",
        JobState.Canceled => "已取消",
        JobState.Running => "训练中",
        JobState.Preparing => "准备中",
        _ => "排队中",
    };
}
