using VisionTrainer.App.UI;
using VisionTrainer.Core;
using VisionTrainer.Data;
using VisionTrainer.Engine;
using VisionTrainer.Vision;

namespace VisionTrainer.App.Pages;

/// <summary>
/// 标注页。三栏布局：左图片列表 / 中画布 / 右类别与框列表。
///
/// 设计原则：客户不懂标注，所以每一步都要有即时反馈——
/// 标过的图打绿勾、框画完立刻出现在右侧列表、随时能看到"已标 N / 共 M"。
/// </summary>
public sealed class AnnotatePage : UserControl, INavigablePage
{
    private readonly MainForm _host;
    private readonly AppSettings _settings;

    private AnnotationProject? _project;
    private ListBox _imageList = new();
    private AnnotationCanvas _canvas = new();
    private FlowLayoutPanel _classPanel = new();
    private DataGridView _boxGrid = new();
    private OnboardingOverlay? _overlay;

    private readonly Label _projectLabel = new();
    private readonly Label _statsLabel = new();
    private readonly Label _hintBar = new();
    private readonly Panel _emptyState = new();
    private readonly Panel _workspace = new();
    private readonly ProgressBar _aiProgress = new();

    public AnnotatePage(MainForm host, AppSettings settings)
    {
        _host = host;
        _settings = settings;
        BackColor = Theme.Background;

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3 };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 62));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));

        root.Controls.Add(BuildToolbar(), 0, 0);

        var body = new Panel { Dock = DockStyle.Fill };
        body.Controls.Add(_workspace);
        body.Controls.Add(_emptyState);
        BuildWorkspace();
        BuildEmptyState();
        root.Controls.Add(body, 0, 1);

        _hintBar.Dock = DockStyle.Fill;
        _hintBar.Font = Theme.SmallFont;
        _hintBar.ForeColor = Theme.TextSecondary;
        _hintBar.TextAlign = ContentAlignment.MiddleLeft;
        _hintBar.Text = "快捷键：拖拽左侧图片切换  ·  在图上按住鼠标拖动即可画框  ·  选中框后按 Delete 删除";
        root.Controls.Add(_hintBar, 0, 2);

        Controls.Add(root);

        _overlay = new OnboardingOverlay(BuildSteps());
        Controls.Add(_overlay);
        _overlay.BringToFront();
    }

    // ---------------- 顶部工具栏 ----------------
    private Control BuildToolbar()
    {
        var bar = new Panel { Dock = DockStyle.Fill, Padding = new Padding(0, 0, 0, 8) };

        _projectLabel.AutoSize = true;
        _projectLabel.Font = Theme.H2;
        _projectLabel.ForeColor = Theme.TextPrimary;
        _projectLabel.Location = new Point(0, 6);
        _projectLabel.Text = "标注工具";

        _statsLabel.AutoSize = true;
        _statsLabel.Font = Theme.SmallFont;
        _statsLabel.ForeColor = Theme.TextSecondary;
        _statsLabel.Location = new Point(2, 32);
        _statsLabel.Text = "还没有打开标注工程";

        var right = new FlowLayoutPanel
        {
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
            Location = new Point(bar.Width - 700, 6),
        };
        bar.Resize += (_, _) => right.Left = Math.Max(300, bar.Width - right.Width - 4);

        var newBtn = MakeButton("新建 / 打开工程", primary: true);
        newBtn.Click += (_, _) => CreateOrOpenProject();

        var aiBtn = MakeButton("AI 预标注", primary: false);
        aiBtn.Click += async (_, _) => await RunPreAnnotationAsync();

        var openDirBtn = MakeButton("打开目录", primary: false);
        openDirBtn.Click += (_, _) =>
        {
            if (_project is null) return;
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = _project.RootPath,
                UseShellExecute = true,
            });
        };

        var trainBtn = MakeButton("用这批数据训练", primary: true);
        trainBtn.Click += (_, _) => ExportAndTrain();

        var helpBtn = MakeButton("?", primary: false);
        helpBtn.Width = 38;
        helpBtn.Click += (_, _) => _overlay?.Start();

        right.Controls.AddRange(new Control[] { newBtn, aiBtn, openDirBtn, trainBtn, helpBtn });

        bar.Controls.Add(right);
        bar.Controls.Add(_statsLabel);
        bar.Controls.Add(_projectLabel);
        return bar;
    }

    private static Button MakeButton(string text, bool primary)
    {
        var b = new Button
        {
            Text = text,
            Height = 34,
            Width = Math.Max(90, text.Length * 15 + 26),
            FlatStyle = FlatStyle.Flat,
            Font = Theme.BaseFont,
            Cursor = Cursors.Hand,
            Margin = new Padding(0, 0, 8, 0),
        };
        b.FlatAppearance.BorderSize = primary ? 0 : 1;
        b.FlatAppearance.BorderColor = Theme.Border;
        b.BackColor = primary ? Theme.Primary : Theme.Surface;
        b.ForeColor = primary ? Color.White : Theme.TextPrimary;
        return b;
    }

    // ---------------- 空状态 ----------------
    private void BuildEmptyState()
    {
        _emptyState.Dock = DockStyle.Fill;
        _emptyState.BackColor = Theme.Background;
        _emptyState.Paint += (_, e) =>
        {
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            var cx = _emptyState.Width / 2;
            var cy = _emptyState.Height / 2;

            var card = new Rectangle(cx - 260, cy - 120, 520, 240);
            using (var path = Theme.RoundedRect(card, Theme.Radius))
            using (var brush = new SolidBrush(Theme.Surface))
            using (var pen = new Pen(Theme.Border))
            {
                g.FillPath(brush, path);
                g.DrawPath(pen, path);
            }

            TextRenderer.DrawText(g, "还没有标注工程", Theme.H2,
                new Rectangle(card.X, card.Y + 32, card.Width, 28), Theme.TextPrimary,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            TextRenderer.DrawText(g,
                "新建一个工程，把图片导进来，就可以开始标了。\n标注结果会自动保存成 YOLO 格式，标完直接能训练。",
                Theme.BodyFont,
                new Rectangle(card.X + 30, card.Y + 70, card.Width - 60, 60), Theme.TextSecondary,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.WordBreak);
        };
        _emptyState.Resize += (_, _) => { _emptyState.Invalidate(); LayoutEmptyButton(); };
    }

    private Button? _emptyButton;

    private void LayoutEmptyButton()
    {
        if (_emptyButton is not null) _emptyButton.Dispose();
        _emptyButton = MakeButton("新建标注工程", primary: true);
        _emptyButton.Width = 160;
        _emptyButton.Height = 40;
        _emptyButton.Location = new Point(_emptyState.Width / 2 - 80, _emptyState.Height / 2 + 56);
        _emptyButton.Click += (_, _) => CreateOrOpenProject();
        _emptyState.Controls.Add(_emptyButton);
        _emptyButton.BringToFront();
    }

    // ---------------- 工作区三栏 ----------------
    private void BuildWorkspace()
    {
        _workspace.Dock = DockStyle.Fill;
        _workspace.Visible = false;
        _workspace.Padding = new Padding(0);

        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1 };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 210));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 250));

        // 左：图片列表
        var leftCard = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Surface, Margin = new Padding(0, 0, 8, 0) };
        leftCard.Paint += (_, e) =>
        {
            using var pen = new Pen(Theme.Border);
            e.Graphics.DrawRectangle(pen, 0, 0, leftCard.Width - 1, leftCard.Height - 1);
        };

        var leftHeader = new Label
        {
            Dock = DockStyle.Top,
            Height = 34,
            Text = "图片列表",
            Font = Theme.H3,
            ForeColor = Theme.TextPrimary,
            Padding = new Padding(12, 0, 0, 0),
            TextAlign = ContentAlignment.MiddleLeft,
            BackColor = Color.FromArgb(250, 251, 253),
        };

        _imageList.Dock = DockStyle.Fill;
        _imageList.BorderStyle = BorderStyle.None;
        _imageList.Font = Theme.BaseFont;
        _imageList.IntegralHeight = false;
        _imageList.DrawMode = DrawMode.OwnerDrawFixed;
        _imageList.ItemHeight = 30;
        _imageList.DrawItem += ImageList_DrawItem;
        _imageList.SelectedIndexChanged += (_, _) => OnImageSelected();

        leftCard.Controls.Add(_imageList);
        leftCard.Controls.Add(leftHeader);

        // 中：画布
        var canvasHost = new Panel { Dock = DockStyle.Fill, Margin = new Padding(0, 0, 8, 0), BackColor = Color.FromArgb(38, 40, 44) };
        _canvas.Dock = DockStyle.Fill;
        _canvas.Font = Theme.SmallFont;
        _canvas.ClassColorProvider = cls =>
        {
            var hex = _project?.ClassOf(cls)?.ColorHex ?? "#FF3B30";
            try { return ColorTranslator.FromHtml(hex); } catch { return Theme.Danger; }
        };
        _canvas.ClassNameProvider = cls => _project?.ClassOf(cls)?.Name ?? $"类别 {cls}";
        _canvas.AnnotationsChanged += () =>
        {
            RefreshBoxGrid();
            RefreshImageListKeepSelection();
            UpdateStats();
        };
        canvasHost.Controls.Add(_canvas);

        // 右：类别 + 框列表
        var rightCard = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Surface, Margin = new Padding(0) };
        rightCard.Paint += (_, e) =>
        {
            using var pen = new Pen(Theme.Border);
            e.Graphics.DrawRectangle(pen, 0, 0, rightCard.Width - 1, rightCard.Height - 1);
        };

        var rightTop = new Label
        {
            Dock = DockStyle.Top,
            Height = 34,
            Text = "选择要标的类别",
            Font = Theme.H3,
            ForeColor = Theme.TextPrimary,
            Padding = new Padding(12, 0, 0, 0),
            TextAlign = ContentAlignment.MiddleLeft,
            BackColor = Color.FromArgb(250, 251, 253),
        };

        _classPanel.Dock = DockStyle.Top;
        _classPanel.Height = 150;
        _classPanel.FlowDirection = FlowDirection.TopDown;
        _classPanel.WrapContents = false;
        _classPanel.AutoScroll = true;
        _classPanel.BackColor = Theme.Surface;
        _classPanel.Padding = new Padding(8);

        var boxHeader = new Label
        {
            Dock = DockStyle.Top,
            Height = 34,
            Text = "本图已标注",
            Font = Theme.H3,
            ForeColor = Theme.TextPrimary,
            Padding = new Padding(12, 0, 0, 0),
            TextAlign = ContentAlignment.MiddleLeft,
            BackColor = Color.FromArgb(250, 251, 253),
        };

        _boxGrid.Dock = DockStyle.Fill;
        _boxGrid.AllowUserToAddRows = false;
        _boxGrid.RowHeadersVisible = false;
        _boxGrid.BackgroundColor = Theme.Surface;
        _boxGrid.BorderStyle = BorderStyle.None;
        _boxGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _boxGrid.EnableHeadersVisualStyles = false;
        _boxGrid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(250, 251, 253);
        _boxGrid.ColumnHeadersDefaultCellStyle.Font = Theme.SmallFont;
        _boxGrid.ColumnHeadersHeight = 28;
        _boxGrid.DefaultCellStyle.Font = Theme.BaseFont;
        _boxGrid.RowTemplate.Height = 28;
        _boxGrid.GridColor = Theme.Border;
        _boxGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "cls", HeaderText = "类别", FillWeight = 55, ReadOnly = true });
        _boxGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "src", HeaderText = "来源", FillWeight = 45, ReadOnly = true });
        _boxGrid.SelectionChanged += (_, _) =>
        {
            if (_boxGrid.CurrentRow is { Index: >= 0 } row) _canvas.SelectBox(row.Index);
        };

        var bottomBar = new Panel { Dock = DockStyle.Bottom, Height = 44, Padding = new Padding(8, 6, 8, 6) };
        var delBtn = MakeButton("删除选中框", primary: false);
        delBtn.Dock = DockStyle.Right;
        delBtn.Width = 110;
        delBtn.Click += (_, _) =>
        {
            _canvas.DeleteSelected();
            RefreshBoxGrid();
        };
        var clearBtn = MakeButton("清空本图", primary: false);
        clearBtn.Dock = DockStyle.Right;
        clearBtn.Width = 96;
        clearBtn.Click += (_, _) =>
        {
            if (_canvas.CurrentImage is null) return;
            if (MessageBox.Show(this, "确定清空这张图的所有标注？", "确认",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) return;
            _canvas.ClearAll();
            RefreshBoxGrid();
        };
        bottomBar.Controls.Add(clearBtn);
        bottomBar.Controls.Add(delBtn);

        rightCard.Controls.Add(_boxGrid);
        rightCard.Controls.Add(bottomBar);
        rightCard.Controls.Add(boxHeader);
        rightCard.Controls.Add(_classPanel);
        rightCard.Controls.Add(rightTop);

        layout.Controls.Add(leftCard, 0, 0);
        layout.Controls.Add(canvasHost, 1, 0);
        layout.Controls.Add(rightCard, 2, 0);
        _workspace.Controls.Add(layout);
    }

    private void ImageList_DrawItem(object? sender, DrawItemEventArgs e)
    {
        if (e.Index < 0 || _project is null || e.Index >= _project.Images.Count) return;
        var img = _project.Images[e.Index];
        var g = e.Graphics;
        var selected = (e.State & DrawItemState.Selected) != 0;

        using (var bg = new SolidBrush(selected ? Color.FromArgb(232, 241, 254) : Theme.Surface))
            g.FillRectangle(bg, e.Bounds);

        // 状态圆点：已标=绿，未标=灰
        var dotColor = img.HasAnnotations ? Theme.Success : Color.FromArgb(200, 205, 212);
        using (var dot = new SolidBrush(dotColor))
            g.FillEllipse(dot, e.Bounds.X + 10, e.Bounds.Y + e.Bounds.Height / 2 - 4, 8, 8);

        var text = img.FileName;
        var textRect = new Rectangle(e.Bounds.X + 26, e.Bounds.Y, e.Bounds.Width - 50, e.Bounds.Height);
        TextRenderer.DrawText(g, text, Theme.SmallFont, textRect,
            selected ? Theme.Primary : Theme.TextPrimary,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);

        if (img.Boxes.Count > 0)
        {
            var badge = img.Boxes.Count.ToString();
            var size = TextRenderer.MeasureText(badge, Theme.SmallFont);
            TextRenderer.DrawText(g, badge, Theme.SmallFont,
                new Rectangle(e.Bounds.Right - size.Width - 12, e.Bounds.Y, size.Width, e.Bounds.Height),
                Theme.TextSecondary, TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
        }
    }

    // ---------------- 工程管理 ----------------
    private void CreateOrOpenProject()
    {
        using var dlg = new ProjectSetupDialog(_settings);
        if (dlg.ShowDialog(FindForm()) != DialogResult.OK || dlg.Result is null) return;
        LoadProject(dlg.Result);
    }

    private void LoadProject(AnnotationProject project)
    {
        _project = project;
        _project.Rescan();
        _projectLabel.Text = project.Name;
        _emptyState.Visible = false;
        _workspace.Visible = true;

        BuildClassButtons();
        RefreshImageListKeepSelection();
        UpdateStats();

        if (_project.Images.Count > 0)
        {
            _imageList.SelectedIndex = 0;
            OnImageSelected();
        }

        // 首次进入自动放引导
        if (!_settings.AnnotationGuideSeen)
        {
            _settings.AnnotationGuideSeen = true;
            SettingsStore.Save(_settings);
            _overlay?.Start();
        }
    }

    private void BuildClassButtons()
    {
        _classPanel.Controls.Clear();
        if (_project is null) return;

        foreach (var c in _project.Classes.OrderBy(c => c.Index))
        {
            var color = ColorTranslator.FromHtml(c.ColorHex);
            var btn = new Button
            {
                Text = c.Name,
                Width = 214,
                Height = 32,
                FlatStyle = FlatStyle.Flat,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = Theme.BaseFont,
                Cursor = Cursors.Hand,
                Margin = new Padding(0, 0, 0, 4),
                Padding = new Padding(26, 0, 0, 0),
                Tag = c.Index,
                BackColor = c.Index == _canvas.CurrentClass ? Color.FromArgb(232, 241, 254) : Theme.Surface,
            };
            btn.FlatAppearance.BorderColor = c.Index == _canvas.CurrentClass ? Theme.Primary : Theme.Border;
            btn.FlatAppearance.BorderSize = 1;
            btn.Paint += (s, e) =>
            {
                var b = (Button)s!;
                var g = e.Graphics;
                // 类别色块画在左侧，客户一眼对上画布上的框颜色
                using var brush = new SolidBrush(color);
                g.FillRectangle(brush, 8, b.Height / 2 - 6, 12, 12);
            };
            btn.Click += (_, _) =>
            {
                _canvas.CurrentClass = c.Index;
                BuildClassButtons();
            };
            _classPanel.Controls.Add(btn);
        }
    }

    private void RefreshImageListKeepSelection()
    {
        if (_project is null) return;
        var sel = _imageList.SelectedIndex;
        _imageList.BeginUpdate();
        _imageList.Items.Clear();
        foreach (var img in _project.Images) _imageList.Items.Add(img.FileName);
        _imageList.EndUpdate();
        if (sel >= 0 && sel < _imageList.Items.Count) _imageList.SelectedIndex = sel;
    }

    private void OnImageSelected()
    {
        if (_project is null || _imageList.SelectedIndex < 0 || _imageList.SelectedIndex >= _project.Images.Count) return;

        // 切换前先把上一张存盘，防止客户快速翻图丢标注
        if (_canvas.CurrentImage is { IsDirty: true } prev)
        {
            _project.SaveImage(prev);
            RefreshImageListKeepSelection();
        }

        var img = _project.Images[_imageList.SelectedIndex];
        _canvas.SetImage(img);
        RefreshBoxGrid();
        UpdateStats();
    }

    private void RefreshBoxGrid()
    {
        _boxGrid.Rows.Clear();
        var img = _canvas.CurrentImage;
        if (img is null || _project is null) return;

        foreach (var b in img.Boxes)
        {
            _boxGrid.Rows.Add(
                _project.ClassOf(b.ClassIndex)?.Name ?? $"类别 {b.ClassIndex}",
                b.FromAi ? "AI 预标注" : "手工");
        }
    }

    private void UpdateStats()
    {
        if (_project is null) return;
        _statsLabel.Text =
            $"已标注 {_project.AnnotatedCount} / {_project.Images.Count} 张　·　共 {_project.TotalBoxes} 个框　·　" +
            $"{_project.Classes.Count} 个类别";
    }

    // ---------------- AI 预标注 ----------------
    private async Task RunPreAnnotationAsync()
    {
        if (_project is null)
        {
            MessageBox.Show(this, "请先新建或打开一个标注工程。", "提示",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using var dlg = new ModelPickerDialog(_host);
        if (dlg.ShowDialog(FindForm()) != DialogResult.OK || dlg.SelectedModel is null) return;

        _aiProgress.Visible = true;
        _aiProgress.Value = 0;
        Cursor = Cursors.WaitCursor;

        try
        {
            var env = new PythonEnvironment(_settings);
            var annotator = new YoloPreAnnotator(env);
            var progress = new Progress<(int Done, int Total, string Message)>(p =>
            {
                if (p.Total > 0) _aiProgress.Value = (int)Math.Clamp(p.Done * 100.0 / p.Total, 0, 100);
                _hintBar.Text = p.Message;
            });

            var result = await Task.Run(() =>
                annotator.RunAsync(_project, dlg.SelectedModel, 0.25, progress, CancellationToken.None));

            _project.SaveAll();
            RefreshImageListKeepSelection();
            RefreshBoxGrid();
            UpdateStats();

            ShowPreAnnotationReport(result);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "AI 预标注未完成",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        finally
        {
            Cursor = Cursors.Default;
            _aiProgress.Visible = false;
            _hintBar.Text = "快捷键：拖拽左侧图片切换  ·  在图上按住鼠标拖动即可画框  ·  选中框后按 Delete 删除";
        }
    }

    private void ShowPreAnnotationReport(PreAnnotationResult r)
    {
        if (r.TotalBoxes > 0)
        {
            var msg = $"AI 已为 {r.TotalImages} 张图预标注了 {r.TotalBoxes} 个框（虚线框）。\n\n" +
                      "请注意：AI 只是帮忙省力，结果必须人工复核。\n" +
                      "确认无误后，把虚线框改一下类别或拖动一下就会变成实线（表示已人工确认）。";
            if (r.UnmatchedClassNames.Count > 0)
                msg += "\n\n" + string.Join("\n", r.Notes);
            MessageBox.Show(this, msg, "预标注完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        // AI 帮不上忙时的引导——这是新客户最可能遇到的情况，必须说清楚为什么
        var detail = r.UnmatchedClassNames.Count > 0
            ? $"这个模型认识的是：{string.Join("、", r.UnmatchedClassNames.Take(8))}\n" +
              $"而你的工程要标的是：{string.Join("、", _project!.Classes.Select(c => c.Name))}\n\n" +
              "两者对不上，所以没有采用任何框。"
            : "模型在这批图片里没有找到置信度足够高的目标。";

        MessageBox.Show(this,
            "AI 没能帮上忙。\n\n" + detail + "\n\n" +
            "建议这样做：\n" +
            "1. 先手工标 20~30 张图（每个类别至少 10 张）\n" +
            "2. 用这些数据训练一个模型（训练页）\n" +
            "3. 再回来点「AI 预标注」，它就会按你的类别自动框了\n\n" +
            "第一次总是要手工标一些，之后效率会高很多。",
            "预标注未生效", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    // ---------------- 导出并训练 ----------------
    private void ExportAndTrain()
    {
        if (_project is null) return;

        if (_project.AnnotatedCount == 0)
        {
            MessageBox.Show(this, "还没有标注任何图片，无法训练。", "提示",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        if (_project.AnnotatedCount < 20)
        {
            if (MessageBox.Show(this,
                    $"目前只标注了 {_project.AnnotatedCount} 张图，数量偏少，训练效果可能不理想。\n" +
                    "建议每类至少 50 张。\n\n仍要继续吗？",
                    "样本偏少", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) != DialogResult.OK)
                return;
        }

        _project.SaveAll();

        var workDir = AppPaths.NewProjectDir(_project.Name + "_annotated");
        var yaml = _project.ExportForTraining(workDir);

        // 转成 DatasetSummary 直接喂给训练页
        var dataset = new DatasetSummary
        {
            RootPath = Path.Combine(workDir, "dataset"),
            Task = TaskKind.Detection,
            Layout = nameof(DataLayout.YoloDetection),
            TrainImages = _project.AnnotatedCount,
            ValImages = 0,
            Classes = _project.Classes.ToList(),
        };
        dataset.Warnings.Add($"来自标注工程「{_project.Name}」，{_project.AnnotatedCount} 张已标注图片。");

        _host.GoToTrainingWithDataset(dataset);
    }

    // ---------------- 引导 ----------------
    private static List<OnboardingStep> BuildSteps() => new()
    {
        new OnboardingStep(
            "先把图片导进来",
            "点「新建 / 打开工程」，选择一个装有图片的文件夹，\n" +
            "再填上你要标注的类别名称（比如：划痕、缺件、污渍）。\n\n" +
            "图片会被复制一份到工程里，原文件夹不会被动到。",
            "类别名称建议用客户能听懂的业务词，不要用 class1/class2。"),

        new OnboardingStep(
            "在图片上拖一个框",
            "1. 先在右侧「选择要标的类别」里点一下要标的类别\n" +
            "2. 然后按住鼠标左键，在图上的目标外面拖一个矩形\n" +
            "3. 松开鼠标，框就画好了",
            "框要尽量贴紧目标边缘，但不要切掉目标的一部分。"),

        new OnboardingStep(
            "标完一张，换下一张",
            "画错的框：先单击选中它（会出现半透明底色），再按键盘 Delete 键删除。\n" +
            "要重新画：直接再拖一个新框就行。\n\n" +
            "标完后点左侧列表里的下一张图片，当前这张会自动保存。",
            "左侧列表里，绿点表示这张已标过，灰点表示还没标。"),

        new OnboardingStep(
            "用 AI 帮你省力（可选）",
            "如果你之前训练过模型，点「AI 预标注」，它会自动把目标框出来（虚线框）。\n" +
            "你只需要检查、拖动微调、删掉错的，比从零画快很多。\n\n" +
            "第一次用没有模型也没关系，先手工标几十张，训练后再回来看这个功能。",
            "虚线框是 AI 猜的，一定要人工过一遍，别直接拿去训练。"),

        new OnboardingStep(
            "标完就去训练",
            "点右上角「用这批数据训练」，标注好的数据会自动整理成训练格式，\n" +
            "直接跳到训练页，设置几个参数就能开始。\n\n" +
            "建议每类至少标 50 张，效果才稳定。",
            "随时可以点右上角「?」重新看这份引导。"),
    };

    public void OnNavigatedTo()
    {
        if (_project is null && _host.AnnotationProject is not null)
            LoadProject(_host.AnnotationProject);
    }
}
