using VisionTrainer.App.UI;
using VisionTrainer.Core;
using VisionTrainer.Pipeline;

namespace VisionTrainer.App.Pages;

/// <summary>
/// 训练页：左侧参数、右侧实时日志与指标曲线。
/// 关键取舍：训练在后台线程跑，UI 只通过 IProgress 接收增量更新，
/// 绝不在 UI 线程等待 Python 进程。
/// </summary>
public sealed class TrainPage : UserControl, INavigablePage
{
    private readonly MainForm _host;
    private readonly AppSettings _settings;

    private readonly NumericUpDown _epochs = new();
    private readonly NumericUpDown _batch = new();
    private readonly NumericUpDown _imgsz = new();
    private readonly NumericUpDown _lr = new();
    private readonly NumericUpDown _patience = new();
    private readonly CheckBox _augment = new();
    private readonly ComboBox _modelCombo = new();
    private readonly Label _datasetLabel = new();
    private readonly RichTextBox _logBox = new();
    private readonly ProgressBar _progress = new();
    private readonly Label _stageLabel = new();
    private readonly MetricsChart _chart = new();
    private readonly Button _startBtn = new();
    private readonly Button _stopBtn = new();

    private CancellationTokenSource? _cts;
    private TrainingJob? _job;

    public TrainPage(MainForm host, AppSettings settings)
    {
        _host = host;
        _settings = settings;
        BackColor = Theme.Background;
        Padding = new Padding(0);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 340));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        layout.Controls.Add(BuildLeftPanel(), 0, 0);
        layout.Controls.Add(BuildRightPanel(), 1, 0);
        Controls.Add(layout);
    }

    private Control BuildLeftPanel()
    {
        var scroll = new Panel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            Margin = new Padding(0, 0, 6, 0),
            BackColor = Theme.Background,
        };

        var card = new CardPanel
        {
            Dock = DockStyle.Top,
            Height = 560,
            Title = "训练参数",
            Subtitle = "不确定就保持默认",
        };

        var stack = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
            Padding = new Padding(0, 8, 0, 0),
        };

        _datasetLabel.AutoSize = false;
        _datasetLabel.Height = 40;
        _datasetLabel.Width = 292;
        _datasetLabel.Font = Theme.SmallFont;
        _datasetLabel.ForeColor = Theme.TextSecondary;
        _datasetLabel.Text = "尚未导入数据集";

        stack.Controls.Add(_datasetLabel);

        _modelCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        _modelCombo.Font = Theme.BaseFont;
        _modelCombo.Width = 292;
        foreach (var (text, tag) in new[]
        {
            ("Nano · 最快，精度略低", "yolo11n"),
            ("Small · 速度与精度平衡", "yolo11s"),
            ("Medium · 更准，更吃显存", "yolo11m"),
        })
        {
            _modelCombo.Items.Add(new ModelItem(text, tag));
        }
        _modelCombo.SelectedIndex = 0;
        stack.Controls.Add(Field("基础模型", _modelCombo));

        ConfigureNumeric(_epochs, 1, 1000, 100, 0);
        stack.Controls.Add(Field("训练轮数（轮）", _epochs));

        ConfigureNumeric(_batch, 1, 128, 16, 0);
        stack.Controls.Add(Field("批大小", _batch));

        ConfigureNumeric(_imgsz, 320, 1280, 640, 0, increment: 32);
        stack.Controls.Add(Field("输入尺寸（px）", _imgsz));

        ConfigureNumeric(_lr, 0.00001m, 0.1m, 0.01m, 5, increment: 0.001m);
        stack.Controls.Add(Field("学习率", _lr));

        ConfigureNumeric(_patience, 0, 200, 30, 0);
        stack.Controls.Add(Field("早停耐心值", _patience));

        _augment.Text = "启用数据增强（小数据集建议开启）";
        _augment.Font = Theme.BaseFont;
        _augment.AutoSize = true;
        _augment.Checked = true;
        _augment.Margin = new Padding(0, 4, 0, 12);
        stack.Controls.Add(_augment);

        _startBtn.Text = "开始训练";
        _startBtn.Width = 292;
        _startBtn.Height = 40;
        _startBtn.Margin = new Padding(0, 4, 0, 8);
        StyleAccent(_startBtn);
        _startBtn.Click += async (_, _) => await StartAsync();

        _stopBtn.Text = "停止训练";
        _stopBtn.Width = 292;
        _stopBtn.Height = 36;
        _stopBtn.Enabled = false;
        _stopBtn.FlatStyle = FlatStyle.Flat;
        _stopBtn.FlatAppearance.BorderColor = Theme.Border;
        _stopBtn.BackColor = Theme.Surface;
        _stopBtn.Font = Theme.BaseFont;
        _stopBtn.Cursor = Cursors.Hand;
        _stopBtn.Click += (_, _) => _cts?.Cancel();

        stack.Controls.Add(_startBtn);
        stack.Controls.Add(_stopBtn);

        card.Controls.Add(stack);
        scroll.Controls.Add(card);
        return scroll;
    }

    private Control BuildRightPanel()
    {
        var card = new CardPanel
        {
            Dock = DockStyle.Fill,
            Title = "训练进度",
            Subtitle = "横轴为轮次，纵轴为 mAP50-95（越高越好）",
            Margin = new Padding(6, 0, 0, 0),
        };

        var bottom = new Panel { Dock = DockStyle.Bottom, Height = 90 };
        _progress.Dock = DockStyle.Top;
        _progress.Height = 8;
        _progress.Style = ProgressBarStyle.Continuous;
        _progress.Margin = new Padding(0, 0, 0, 6);

        _stageLabel.Dock = DockStyle.Top;
        _stageLabel.Height = 24;
        _stageLabel.Font = Theme.SmallFont;
        _stageLabel.ForeColor = Theme.TextSecondary;
        _stageLabel.Text = "等待开始";

        var logHost = new Panel { Dock = DockStyle.Fill };
        _logBox.Dock = DockStyle.Fill;
        _logBox.BackColor = Color.FromArgb(30, 32, 36);
        _logBox.ForeColor = Color.FromArgb(200, 205, 212);
        _logBox.Font = Theme.MonoFont;
        _logBox.BorderStyle = BorderStyle.None;
        _logBox.ReadOnly = true;
        _logBox.WordWrap = false;
        _logBox.ScrollBars = RichTextBoxScrollBars.Both;
        logHost.Controls.Add(_logBox);

        var progressHost = new Panel { Dock = DockStyle.Bottom, Height = 46, Padding = new Padding(0, 6, 0, 6) };
        progressHost.Controls.Add(_stageLabel);
        progressHost.Controls.Add(_progress);

        card.Controls.Add(logHost);
        card.Controls.Add(progressHost);
        card.Controls.Add(new Panel { Dock = DockStyle.Bottom, Height = 190 }.Also(p =>
        {
            p.Controls.Add(_chart);
            _chart.Dock = DockStyle.Fill;
        }));

        return card;
    }

    private static void ConfigureNumeric(
        NumericUpDown n, decimal min, decimal max, decimal value, int decimals, decimal increment = 1)
    {
        n.Minimum = min;
        n.Maximum = max;
        n.Value = Math.Clamp(value, min, max);
        n.DecimalPlaces = decimals;
        n.Increment = increment;
        n.Font = Theme.BaseFont;
        n.Width = 130;
        n.Height = 28;
    }

    private static void StyleAccent(Button b)
    {
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = 0;
        b.BackColor = Theme.Primary;
        b.ForeColor = Color.White;
        b.Font = Theme.BodyFont;
        b.Cursor = Cursors.Hand;
    }

    private static Control Field(string label, Control input)
    {
        var panel = new Panel { Width = 292, Height = 58, Margin = new Padding(0, 0, 0, 4) };
        var lbl = new Label
        {
            Text = label,
            Font = Theme.SmallFont,
            ForeColor = Theme.TextSecondary,
            AutoSize = true,
            Location = new Point(0, 0),
        };
        input.Location = new Point(0, 20);
        input.Width = 292;
        panel.Controls.Add(lbl);
        panel.Controls.Add(input);
        return panel;
    }

    private void AppendLog(string line)
    {
        if (_logBox.IsDisposed) return;
        _logBox.AppendText(line + Environment.NewLine);
        _logBox.SelectionStart = _logBox.TextLength;
        _logBox.ScrollToCaret();
    }

    private async Task StartAsync()
    {
        if (_host.CurrentDataset is not { } dataset)
        {
            MessageBox.Show(this, "请先在「数据集」页面导入数据。", "提示",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var options = new TrainingOptions
        {
            Task = TaskKind.Detection,
            BaseModel = (_modelCombo.SelectedItem as ModelItem)?.Tag ?? "yolo11n",
            Epochs = (int)_epochs.Value,
            BatchSize = (int)_batch.Value,
            ImageSize = (int)_imgsz.Value,
            LearningRate = (double)_lr.Value,
            Patience = (int)_patience.Value,
            UseAugmentation = _augment.Checked,
        };

        var job = new TrainingJob
        {
            Name = $"{options.BaseModel}_{DateTime.Now:MMdd_HHmm}",
            Options = options,
            Dataset = dataset,
            Profile = _settings.Profile,
        };
        _job = job;

        _logBox.Clear();
        _chart.Clear();
        _progress.Value = 0;
        _startBtn.Enabled = false;
        _startBtn.BackColor = Theme.PrimaryDisabled;
        _stopBtn.Enabled = true;
        _cts = new CancellationTokenSource();

        var progress = new Progress<TrainingProgress>(OnProgress);

        try
        {
            var runner = new JobRunner(_settings);
            await Task.Run(() => runner.RunAsync(job, progress, _cts.Token));

            if (job.State == JobState.Succeeded)
            {
                _stageLabel.ForeColor = Theme.Success;
                _stageLabel.Text = "训练完成";
                MessageBox.Show(this,
                    $"训练完成。\n\n产物目录：\n{job.WorkDirectory}",
                    "完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (job.State == JobState.Failed)
            {
                _stageLabel.ForeColor = Theme.Danger;
                _stageLabel.Text = "训练失败";
                MessageBox.Show(this, job.ErrorMessage ?? "未知错误", "训练失败",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                _stageLabel.ForeColor = Theme.Warning;
                _stageLabel.Text = "已取消";
            }
        }
        finally
        {
            _startBtn.Enabled = true;
            _startBtn.BackColor = Theme.Primary;
            _stopBtn.Enabled = false;
            _cts?.Dispose();
            _cts = null;
            _host.RefreshStatus();
        }
    }

    private void OnProgress(TrainingProgress p)
    {
        if (IsDisposed) return;
        switch (p.Kind)
        {
            case ProgressKind.Stage:
                if (p.Percent > 0) _progress.Value = (int)Math.Clamp(p.Percent, 0, 100);
                if (!string.IsNullOrEmpty(p.Message))
                {
                    _stageLabel.ForeColor = Theme.TextSecondary;
                    _stageLabel.Text = $"{p.Message}　({p.Percent:0}%)";
                }
                break;

            case ProgressKind.Log:
                AppendLog(p.Message);
                break;

            case ProgressKind.Epoch:
                if (p.Metric is { } m)
                {
                    _chart.AddPoint(m.Epoch, m.Map50_95 ?? m.Top1 ?? 0);
                    var best = _job?.Best?.Map50_95 ?? m.Map50_95;
                    _stageLabel.Text =
                        $"第 {m.Epoch}/{m.TotalEpochs} 轮　|　mAP50-95 = {m.Map50_95:F4}　|　最佳 = {best:F4}";
                    if (m.TotalEpochs > 0)
                        _progress.Value = (int)Math.Clamp(m.Epoch / (double)m.TotalEpochs * 100, 0, 100);
                }
                break;

            case ProgressKind.Error:
                AppendLog("[错误] " + p.Message);
                break;
        }
    }

    public void OnNavigatedTo()
    {
        if (_host.CurrentDataset is { } d)
        {
            _datasetLabel.ForeColor = Theme.TextPrimary;
            _datasetLabel.Text =
                $"当前数据集：{Path.GetFileName(d.RootPath)}\n" +
                $"训练图 {d.TrainImages} 张 · {d.Classes.Count} 个类别";
        }
    }

    private sealed record ModelItem(string Text, string Tag)
    {
        public override string ToString() => Text;
    }
}

/// <summary>轻量折线图。不引第三方图表库，避免额外依赖与体积。</summary>
public sealed class MetricsChart : Control
{
    private readonly List<(int Epoch, double Value)> _points = new();

    public MetricsChart()
    {
        DoubleBuffered = true;
        BackColor = Theme.Background;
    }

    public void AddPoint(int epoch, double value)
    {
        _points.Add((epoch, value));
        Invalidate();
    }

    public void Clear()
    {
        _points.Clear();
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

        var plot = new Rectangle(48, 12, Math.Max(10, Width - 64), Math.Max(10, Height - 44));
        using (var bg = new SolidBrush(Color.FromArgb(250, 251, 253)))
            g.FillRectangle(bg, plot);

        // 网格与坐标轴
        using var gridPen = new Pen(Color.FromArgb(235, 238, 242));
        using var axisPen = new Pen(Theme.Border);
        for (int i = 0; i <= 4; i++)
        {
            int y = plot.Top + plot.Height * i / 4;
            g.DrawLine(gridPen, plot.Left, y, plot.Right, y);
            var label = (1.0 - i / 4.0).ToString("0.00");
            TextRenderer.DrawText(g, label, Theme.SmallFont,
                new Rectangle(0, y - 8, plot.Left - 8, 16), Theme.TextSecondary,
                TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
        }
        g.DrawRectangle(axisPen, plot);

        if (_points.Count == 0)
        {
            TextRenderer.DrawText(g, "暂无数据", Theme.SmallFont,
                plot, Theme.TextSecondary,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            return;
        }

        var maxEpoch = Math.Max(1, _points.Max(p => p.Epoch));
        var pts = _points.Select(p => new PointF(
            plot.Left + (float)(p.Epoch / (double)maxEpoch) * plot.Width,
            plot.Bottom - (float)Math.Clamp(p.Value, 0, 1) * plot.Height)).ToArray();

        if (pts.Length >= 2)
        {
            using var linePen = new Pen(Theme.Primary, 2f);
            g.DrawLines(linePen, pts);

            // 面积填充，让曲线更易读
            var area = pts.Concat(new[]
            {
                new PointF(pts[^1].X, plot.Bottom),
                new PointF(pts[0].X, plot.Bottom),
            }).ToArray();
            using var fillBrush = new SolidBrush(Color.FromArgb(30, Theme.Primary));
            g.FillPolygon(fillBrush, area);
        }

        foreach (var pt in pts)
        {
            using var dot = new SolidBrush(Theme.Primary);
            g.FillEllipse(dot, pt.X - 2.5f, pt.Y - 2.5f, 5, 5);
        }
    }
}

internal static class ControlExtensions
{
    public static T Also<T>(this T self, Action<T> action)
    {
        action(self);
        return self;
    }
}
