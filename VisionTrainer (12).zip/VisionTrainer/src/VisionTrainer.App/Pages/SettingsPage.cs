using VisionTrainer.App.UI;
using VisionTrainer.Core;
using VisionTrainer.Engine;

namespace VisionTrainer.App.Pages;

public sealed class SettingsPage : UserControl, INavigablePage
{
    private readonly MainForm _host;
    private readonly AppSettings _settings;

    private readonly Label _gpuLabel = new();
    private readonly Label _envLabel = new();
    private readonly ComboBox _profileCombo = new();
    private readonly ComboBox _pipCombo = new();
    private readonly ComboBox _torchCombo = new();
    private readonly RichTextBox _diagBox = new();
    private readonly ProgressBar _installProgress = new();
    private readonly Label _installStatus = new();
    private readonly Button _installBtn = new();
    private readonly Button _localWheelBtn = new();

    private CancellationTokenSource? _cts;

    public SettingsPage(MainForm host, AppSettings settings)
    {
        _host = host;
        _settings = settings;
        BackColor = Theme.Background;

        var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true };

        var stack = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
        };

        var title = new Label
        {
            Text = "环境与设置",
            Font = Theme.H1,
            ForeColor = Theme.TextPrimary,
            AutoSize = true,
            Margin = new Padding(0, 0, 0, 14),
        };
        stack.Controls.Add(title);

        // ---- 硬件卡片 ----
        var hwCard = NewCard("运行环境", "训练依赖会自动安装到用户目录，不影响系统其他程序");
        _gpuLabel.Font = Theme.BodyFont;
        _gpuLabel.AutoSize = true;
        _gpuLabel.Margin = new Padding(0, 8, 0, 4);
        _envLabel.Font = Theme.SmallFont;
        _envLabel.ForeColor = Theme.TextSecondary;
        _envLabel.AutoSize = true;
        _envLabel.Margin = new Padding(0, 0, 0, 12);

        _profileCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        _profileCombo.Font = Theme.BaseFont;
        _profileCombo.Width = 280;
        foreach (var p in new[]
        {
            ComputeProfile.Cpu, ComputeProfile.Cuda118, ComputeProfile.Cuda121, ComputeProfile.Cuda124 })
        {
            _profileCombo.Items.Add(new ProfileItem(GpuDetector.Describe(p), p));
        }
        _profileCombo.SelectedIndex = (int)_settings.Profile;

        _installBtn.Text = "安装 / 修复运行环境";
        _installBtn.Width = 200;
        _installBtn.Height = 36;
        _installBtn.FlatStyle = FlatStyle.Flat;
        _installBtn.FlatAppearance.BorderSize = 0;
        _installBtn.BackColor = Theme.Primary;
        _installBtn.ForeColor = Color.White;
        _installBtn.Font = Theme.BodyFont;
        _installBtn.Cursor = Cursors.Hand;
        _installBtn.Margin = new Padding(0, 0, 12, 0);
        _installBtn.Click += async (_, _) => await InstallAsync();

        _installProgress.Width = 280;
        _installProgress.Height = 8;
        _installProgress.Margin = new Padding(0, 12, 0, 4);
        _installProgress.Style = ProgressBarStyle.Continuous;

        _installStatus.Font = Theme.SmallFont;
        _installStatus.ForeColor = Theme.TextSecondary;
        // 不能 AutoSize：单行标签遇到 pip 的长报错会横向溢出卡片，
        // 内容被下一张卡盖住，用户只能看到半句错误（真实反馈）。
        // 固定 4 行高度 + 自动换行，装得下大部分报错。
        _installStatus.AutoSize = false;
        _installStatus.Width = 660;
        _installStatus.Height = 64;
        _installStatus.TextAlign = ContentAlignment.TopLeft;

        // 「从本地 whl 安装」：国内环境下最可靠的路径。
        // 客户在能上网的机器上下好 whl（或直接拿到我们发的离线包），拷过来就能装，
        // 完全不走网络——比任何镜像都快。
        _localWheelBtn.Text = "从本地 whl 安装…";
        _localWheelBtn.Width = 170;
        _localWheelBtn.Height = 36;
        _localWheelBtn.FlatStyle = FlatStyle.Flat;
        _localWheelBtn.BackColor = Theme.Surface;
        _localWheelBtn.Font = Theme.BaseFont;
        _localWheelBtn.Cursor = Cursors.Hand;
        _localWheelBtn.FlatAppearance.BorderColor = Theme.Border;
        _localWheelBtn.Click += async (_, _) => await InstallFromLocalWheelsAsync();

        // 用 FlowLayoutPanel 自动排列，替代手写坐标——
        // 前两版手写定位都出过遮挡事故（状态文字被裁、按钮叠进度条），
        // 控件增删时坐标全要人肉重算，不再采用。
        var hwFlow = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
        };
        hwFlow.Controls.Add(_gpuLabel);
        hwFlow.Controls.Add(_envLabel);
        hwFlow.Controls.Add(_profileCombo);

        var btnRow = new FlowLayoutPanel
        {
            AutoSize = true,
            WrapContents = false,
            Margin = new Padding(0, 6, 0, 0),
        };
        btnRow.Controls.Add(_installBtn);
        btnRow.Controls.Add(_installProgress);
        hwFlow.Controls.Add(btnRow);

        _localWheelBtn.Margin = new Padding(0, 8, 0, 4);
        hwFlow.Controls.Add(_localWheelBtn);

        _installStatus.Margin = new Padding(0, 6, 0, 0);
        hwFlow.Controls.Add(_installStatus);

        hwCard.Controls.Add(hwFlow);
        stack.Controls.Add(hwCard);

        // ---- 网络卡片 ----
        var netCard = NewCard("下载源",
            "国内直连官方源通常只有几百 KB/s，PyTorch 那 2.5GB 要下一两个小时。默认已走国内镜像，一般不用动。");
        var pipLabel = new Label
        {
            Text = "pip 镜像地址（Python 依赖）",
            Font = Theme.SmallFont,
            ForeColor = Theme.TextSecondary,
            AutoSize = true,
            Margin = new Padding(0, 6, 0, 4),
        };
        // pip 源也用下拉框：客户手打 URL 十个有八个拼错，而拼错的报错信息毫无指向性
        _pipCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        _pipCombo.Font = Theme.BaseFont;
        _pipCombo.Width = 440;
        foreach (var (name, url) in PipMirrors.All)
            _pipCombo.Items.Add(new PipMirrorItem(name, url));
        var pipIdx = _pipCombo.Items.Cast<PipMirrorItem>()
            .Select((it, i) => (it, i))
            .FirstOrDefault(t => t.it.Url == _settings.PipIndexUrl).i;
        _pipCombo.SelectedIndex = pipIdx >= 0 && pipIdx < _pipCombo.Items.Count ? pipIdx : 0;

        var saveBtn = new Button
        {
            Text = "保存设置",
            Width = 110,
            Height = 32,
            FlatStyle = FlatStyle.Flat,
            BackColor = Theme.Surface,
            Font = Theme.BaseFont,
            Cursor = Cursors.Hand,
        };
        saveBtn.FlatAppearance.BorderColor = Theme.Border;
        saveBtn.Click += (_, _) =>
        {
            if (_pipCombo.SelectedItem is PipMirrorItem pm)
                _settings.PipIndexUrl = pm.Url;
            if (_torchCombo.SelectedItem is TorchMirrorItem tm)
                _settings.TorchIndexPattern = tm.Pattern;
            _settings.Profile = ((ProfileItem)_profileCombo.SelectedItem!).Profile;
            SettingsStore.Save(_settings);
            // 已装好的环境不会因为换源而变快——换源只影响下一次安装，
            // 必须提示用户重新装一遍，否则他改完发现没变化会以为功能坏了
            var installed = File.Exists(AppPaths.PythonExe);
            MessageBox.Show(this,
                installed
                    ? "已保存。\n\n注意：新的下载源只在「安装 / 修复运行环境」时生效，已在使用的环境不会自动换源。如需重新下载 PyTorch，请点上方「安装 / 修复运行环境」。"
                    : "已保存。下次安装运行环境时会使用新的下载源。",
                "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
        };

        pipLabel.SetLocation(20, 58);
        _pipCombo.SetLocation(20, 80);

        var torchLabel = new Label
        {
            Text = "PyTorch 下载源（占 2.5GB 大头，换源提速最明显）",
            Font = Theme.SmallFont,
            ForeColor = Theme.TextSecondary,
            AutoSize = true,
        };
        // 用下拉框而不是文本框：客户不该手打 URL，也避免抄错路径
        _torchCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        _torchCombo.Font = Theme.BaseFont;
        _torchCombo.Width = 440;
        foreach (var (name, pattern) in TorchMirrors.All)
            _torchCombo.Items.Add(new TorchMirrorItem(name, pattern));

        var idx = _torchCombo.Items.Cast<TorchMirrorItem>()
            .Select((it, i) => (it, i))
            .FirstOrDefault(t => t.it.Pattern == _settings.TorchIndexPattern).i;
        _torchCombo.SelectedIndex = idx >= 0 && idx < _torchCombo.Items.Count ? idx : 0;

        torchLabel.SetLocation(20, 114);
        _torchCombo.SetLocation(20, 136);
        saveBtn.SetLocation(20, 176);
        netCard.Height = 226;

        netCard.Controls.Add(saveBtn);
        netCard.Controls.Add(_torchCombo);
        netCard.Controls.Add(torchLabel);
        netCard.Controls.Add(_pipCombo);
        netCard.Controls.Add(pipLabel);
        stack.Controls.Add(netCard);

        // ---- 诊断卡片 ----
        var diagCard = NewCard("诊断信息", "反馈问题时请复制下面内容，能省掉很多来回沟通");
        _diagBox.Width = 620;
        _diagBox.Height = 150;
        _diagBox.Font = Theme.MonoFont;
        _diagBox.ReadOnly = true;
        _diagBox.BorderStyle = BorderStyle.FixedSingle;
        _diagBox.BackColor = Color.FromArgb(250, 251, 253);
        _diagBox.Margin = new Padding(0, 6, 0, 8);

        var copyBtn = new Button
        {
            Text = "复制诊断信息",
            Width = 130,
            Height = 32,
            FlatStyle = FlatStyle.Flat,
            BackColor = Theme.Surface,
            Font = Theme.BaseFont,
            Cursor = Cursors.Hand,
        };
        copyBtn.FlatAppearance.BorderColor = Theme.Border;
        copyBtn.Click += (_, _) =>
        {
            if (string.IsNullOrEmpty(_diagBox.Text)) return;
            Clipboard.SetText(_diagBox.Text);
            MessageBox.Show(this, "已复制到剪贴板。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
        };

        diagCard.Controls.Add(copyBtn);
        diagCard.Controls.Add(_diagBox);
        _diagBox.SetLocation(20, 58);
        copyBtn.SetLocation(20, 216);
        diagCard.Height = 262;
        stack.Controls.Add(diagCard);

        scroll.Controls.Add(stack);
        Controls.Add(scroll);
    }

    private static CardPanel NewCard(string title, string subtitle)
    {
        return new CardPanel
        {
            Width = 700,
            Height = 200,
            Title = title,
            Subtitle = subtitle,
            Margin = new Padding(0, 0, 0, Theme.Gap),
            Padding = new Padding(20, 56, 20, 16),
            Anchor = AnchorStyles.Top | AnchorStyles.Left,
        };
    }

    public void OnNavigatedTo()
    {
        var gpus = GpuDetector.Detect();
        _gpuLabel.Text = gpus.Count > 0
            ? $"✓ 检测到显卡：{string.Join("，", gpus)}"
            : "未检测到 NVIDIA 显卡，将使用 CPU 训练（速度慢很多）";
        _gpuLabel.ForeColor = gpus.Count > 0 ? Theme.Success : Theme.Warning;

        var ready = File.Exists(AppPaths.PythonExe);
        _envLabel.Text = ready
            ? $"运行环境已安装：{AppPaths.PythonRoot}"
            : "运行环境尚未安装。首次训练会自动安装，也可点下方按钮提前安装。";

        _diagBox.Text = SystemProbe.Describe();
    }

    private async Task InstallAsync()
    {
        // 先保存用户当前选择的档位，安装过程读的是这个
        _settings.Profile = ((ProfileItem)_profileCombo.SelectedItem!).Profile;
        if (_pipCombo.SelectedItem is PipMirrorItem pm) _settings.PipIndexUrl = pm.Url;
        if (_torchCombo.SelectedItem is TorchMirrorItem tm) _settings.TorchIndexPattern = tm.Pattern;
        SettingsStore.Save(_settings);

        _installBtn.Enabled = false;
        _cts = new CancellationTokenSource();

        var progress = new Progress<PythonEnvironment.ProgressReport>(r =>
        {
            _installProgress.Value = (int)Math.Clamp(r.Percent, 0, 100);
            _installStatus.Text = $"{r.Stage}　{r.Percent:0}%";
        });

        try
        {
            var env = new PythonEnvironment(_settings);
            await env.EnsureReadyAsync(_settings.Profile, progress, _cts.Token);
            _installStatus.ForeColor = Theme.Success;
            _installStatus.Text = "环境准备完成，可以开始训练了。";
            _host.RefreshStatus();
        }
        catch (OperationCanceledException)
        {
            _installStatus.ForeColor = Theme.Warning;
            _installStatus.Text = "已取消。";
        }
        catch (Exception ex)
        {
            _installStatus.ForeColor = Theme.Danger;
            _installStatus.Text = "安装失败：" + ex.Message;
        }
        finally
        {
            _installBtn.Enabled = true;
            _cts?.Dispose();
            _cts = null;
            OnNavigatedTo();
        }
    }

    /// <summary>
    /// 从用户指定的本地 wheel 目录安装。这是国内网络环境下最可靠的方式：
    /// 在能联网的机器上用浏览器下好 whl，U 盘拷过来，pip --no-index 直接装。
    /// </summary>
    private async Task InstallFromLocalWheelsAsync()
    {
        using var dlg = new FolderBrowserDialog
        {
            Description = "选择存放 .whl 文件的文件夹（torch、torchvision、ultralytics 等）",
            UseDescriptionForTitle = true,
            ShowNewFolderButton = false,
        };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        var dir = dlg.SelectedPath;
        if (!PythonEnvironment.HasTorchWheel(dir))
        {
            // 没有 torch 的 whl 也可能只想补装 ultralytics，但不能让用户误以为装成功了
            var go = MessageBox.Show(this,
                "这个文件夹里没找到 torch-*.whl。\n\n" +
                "如果只有 ultralytics 等小依赖，可以继续，PyTorch 会走网络下载。\n" +
                "如果要完整离线安装，请确认 torch 的 whl 也放在这个文件夹里。\n\n继续吗？",
                "未找到 PyTorch wheel", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (go != DialogResult.Yes) return;
        }

        _settings.LocalWheelDir = dir;
        SettingsStore.Save(_settings);

        _localWheelBtn.Enabled = false;
        _installBtn.Enabled = false;
        _cts = new CancellationTokenSource();
        _installStatus.ForeColor = Theme.TextSecondary;
        _installStatus.Text = "正在从本地 wheel 安装…";

        var progress = new Progress<PythonEnvironment.ProgressReport>(r =>
        {
            _installProgress.Value = (int)Math.Clamp(r.Percent, 0, 100);
            _installStatus.Text = $"{r.Stage}　{r.Percent:0}%";
        });

        try
        {
            var env = new PythonEnvironment(_settings);
            // 先把 Python 运行时准备好（这一步若本地没有 wheels 仍会联网）
            await env.EnsureReadyAsync(_settings.Profile, progress, _cts.Token);
            _installStatus.ForeColor = Theme.Success;
            _installStatus.Text = "安装完成，可以开始训练了。";
            _host.RefreshStatus();
        }
        catch (OperationCanceledException)
        {
            _installStatus.ForeColor = Theme.Warning;
            _installStatus.Text = "已取消。";
        }
        catch (Exception ex)
        {
            _installStatus.ForeColor = Theme.Danger;
            _installStatus.Text = "安装失败：" + ex.Message;
            // 失败时把日志摊开，比一行动态错误有用得多
            MessageBox.Show(this,
                "安装失败：\n\n" + ex.Message +
                "\n\n常见原因：\n" +
                "· wheel 的 Python 版本不匹配（本程序用 3.11，要 cp311 的包）\n" +
                "· wheel 是 linux/macos 平台（要 win_amd64）\n" +
                "· 文件夹里缺 torchvision 等配套包",
                "安装失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            _localWheelBtn.Enabled = true;
            _installBtn.Enabled = true;
            _cts?.Dispose();
            _cts = null;
            OnNavigatedTo();
        }
    }

    private sealed record ProfileItem(string Text, ComputeProfile Profile)
    {
        public override string ToString() => Text;
    }

    private sealed record TorchMirrorItem(string Text, string Pattern)
    {
        public override string ToString() => Text;
    }

    private sealed record PipMirrorItem(string Text, string Url)
    {
        public override string ToString() => Text;
    }
}

internal static class SettingsPageExtensions
{
    public static void SetLocation(this Control c, int x, int y) => c.Location = new Point(x, y);
}
