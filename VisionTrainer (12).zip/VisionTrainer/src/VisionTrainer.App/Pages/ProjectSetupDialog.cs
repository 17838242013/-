using VisionTrainer.App.UI;
using VisionTrainer.Core;
using VisionTrainer.Data;

namespace VisionTrainer.App.Pages;

/// <summary>
/// 新建标注工程对话框。三步合一：选图片目录 → 填工程名 → 填类别。
/// 类别输入支持"一行一个"，也支持逗号/顿号分隔——客户不会按你的格式来。
/// </summary>
public sealed class ProjectSetupDialog : Form
{
    private readonly AppSettings _settings;

    private readonly TabControl _tabs = new();
    // 新建页
    private readonly TextBox _nameBox = new();
    private readonly TextBox _srcBox = new();
    private readonly TextBox _classBox = new();
    private readonly Label _previewLabel = new();
    // 打开页
    private readonly ListBox _recentList = new();

    public AnnotationProject? Result { get; private set; }

    public ProjectSetupDialog(AppSettings settings)
    {
        _settings = settings;

        Text = "标注工程";
        Size = new Size(560, 512);
        MinimumSize = new Size(520, 470);
        BackColor = Theme.Background;
        Font = Theme.BaseFont;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent;

        _tabs.Dock = DockStyle.Fill;
        _tabs.Font = Theme.BaseFont;
        _tabs.Padding = new Point(14, 5);

        var newPage = BuildNewPage();
        var openPage = BuildOpenPage();
        _tabs.TabPages.Add(newPage);
        _tabs.TabPages.Add(openPage);

        var bottom = new Panel { Dock = DockStyle.Bottom, Height = 56, Padding = new Padding(16, 10, 16, 10) };
        var cancel = new Button
        {
            Text = "取消",
            DialogResult = DialogResult.Cancel,
            Width = 88,
            Height = 34,
            Dock = DockStyle.Right,
            FlatStyle = FlatStyle.Flat,
            BackColor = Theme.Surface,
            Font = Theme.BaseFont,
            Cursor = Cursors.Hand,
            Margin = new Padding(8, 0, 0, 0),
        };
        cancel.FlatAppearance.BorderColor = Theme.Border;

        var ok = new Button
        {
            Text = "确定",
            Width = 96,
            Height = 34,
            Dock = DockStyle.Right,
            FlatStyle = FlatStyle.Flat,
            BackColor = Theme.Primary,
            ForeColor = Color.White,
            Font = Theme.BodyFont,
            Cursor = Cursors.Hand,
        };
        ok.FlatAppearance.BorderSize = 0;
        ok.Click += (_, _) => OnConfirm();

        bottom.Controls.Add(cancel);
        bottom.Controls.Add(ok);

        Controls.Add(_tabs);
        Controls.Add(bottom);

        Load += (_, _) =>
        {
            Theme.CenterOnScreen(this);
            Location = new Point(
                Owner is null ? Location.X : Owner.Left + (Owner.Width - Width) / 2,
                Owner is null ? Location.Y : Owner.Top + (Owner.Height - Height) / 2);
            _nameBox.Focus();
        };
    }

    private TabPage BuildNewPage()
    {
        var page = new TabPage("新建工程") { BackColor = Theme.Background, Padding = new Padding(16) };

        var y = 16;
        AddLabel(page, "工程名称", ref y);
        _nameBox.SetBounds(16, y, 480, 28);
        _nameBox.Font = Theme.BaseFont;
        _nameBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        _nameBox.Text = $"标注_{DateTime.Now:MMdd}";
        page.Controls.Add(_nameBox);
        y += 40;

        AddLabel(page, "图片所在文件夹", ref y);
        // 用 Dock 结构保证不重叠：按钮先 Dock.Right，文本框 Fill 占剩余宽度。
        // 之前手写坐标 + Anchor 的方案在 TabPage 首次布局时会把文本框拉伸到
        // 整行、盖住按钮（WinForms 后添加的控件在 Z 序底层）。
        var srcRow = new Panel { Location = new Point(16, y), Size = new Size(464, 30), Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
        _srcBox.Dock = DockStyle.Fill;
        _srcBox.Font = Theme.BaseFont;
        var browse = new Button
        {
            Text = "浏览…",
            Dock = DockStyle.Right,
            Width = 84,
            FlatStyle = FlatStyle.Flat,
            BackColor = Theme.Surface,
            Font = Theme.BaseFont,
            Cursor = Cursors.Hand,
        };
        browse.FlatAppearance.BorderColor = Theme.Border;
        browse.Click += (_, _) => BrowseSource();
        // 停靠规则：z-order 靠前（index 0）的控件最后布局。
        // 想让「浏览…」先占住右边缘、文本框 Fill 吃剩余宽度，
        // 必须把 browse 提到 z-order 顶部（BringToFront），
        // 否则 Fill 的文本框铺满整行把按钮挤没了（截图确认过的真实 bug）。
        srcRow.Controls.Add(_srcBox);
        srcRow.Controls.Add(browse);
        browse.BringToFront();
        page.Controls.Add(srcRow);
        y += 40;

        _previewLabel.SetBounds(16, y, 480, 20);
        _previewLabel.Font = Theme.SmallFont;
        _previewLabel.ForeColor = Theme.TextSecondary;
        _previewLabel.Text = "选择文件夹后会自动统计图片数量";
        page.Controls.Add(_previewLabel);
        y += 28;

        AddLabel(page, "要标注哪些类别（每行一个，或用逗号分隔）", ref y);
        _classBox.SetBounds(16, y, 464, 130);
        _classBox.Multiline = true;
        _classBox.ScrollBars = ScrollBars.Vertical;
        _classBox.Font = Theme.BaseFont;
        _classBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        _classBox.Text = "划痕\r\n缺件";
        page.Controls.Add(_classBox);
        y += 140;

        var hint = new Label
        {
            Text = "提示：类别名用业务术语，多个类别按顺序排列。之后可在工程里继续添加。",
            Font = Theme.SmallFont,
            ForeColor = Theme.TextSecondary,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
        };
        hint.SetBounds(16, y, 464, 34);
        page.Controls.Add(hint);

        return page;
    }

    private TabPage BuildOpenPage()
    {
        var page = new TabPage("打开已有工程") { BackColor = Theme.Background, Padding = new Padding(16) };

        var hint = new Label
        {
            Text = "选择之前创建的工程目录（里面有 project.json）：",
            Font = Theme.SmallFont,
            ForeColor = Theme.TextSecondary,
            Dock = DockStyle.Top,
            Height = 24,
        };

        _recentList.Dock = DockStyle.Fill;
        _recentList.Font = Theme.BaseFont;
        _recentList.BorderStyle = BorderStyle.FixedSingle;
        _recentList.DoubleClick += (_, _) => OnConfirm();

        var browseBtn = new Button
        {
            Text = "浏览工程目录…",
            Dock = DockStyle.Bottom,
            Height = 34,
            FlatStyle = FlatStyle.Flat,
            BackColor = Theme.Surface,
            Font = Theme.BaseFont,
            Cursor = Cursors.Hand,
        };
        browseBtn.FlatAppearance.BorderColor = Theme.Border;
        browseBtn.Click += (_, _) => BrowseProjectFolder();

        page.Controls.Add(_recentList);
        page.Controls.Add(browseBtn);
        page.Controls.Add(hint);
        RefreshRecent();
        return page;
    }

    private static void AddLabel(Control parent, string text, ref int y)
    {
        var lbl = new Label
        {
            Text = text,
            Font = Theme.SmallFont,
            ForeColor = Theme.TextSecondary,
            AutoSize = true,
            Location = new Point(16, y),
        };
        parent.Controls.Add(lbl);
        y += 22;
    }

    private void RefreshRecent()
    {
        _recentList.Items.Clear();
        var root = AppPaths.AnnotationRoot;
        if (!Directory.Exists(root)) return;
        foreach (var dir in Directory.GetDirectories(root))
        {
            if (File.Exists(Path.Combine(dir, "project.json")))
                _recentList.Items.Add(dir);
        }
        if (_recentList.Items.Count == 0)
            _recentList.Items.Add("（还没有工程，请先新建）");
    }

    private void BrowseSource()
    {
        using var dlg = new FolderBrowserDialog
        {
            Description = "选择装有图片的文件夹",
            UseDescriptionForTitle = true,
            ShowNewFolderButton = false,
        };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        _srcBox.Text = dlg.SelectedPath;
        var count = Directory.EnumerateFiles(dlg.SelectedPath, "*.*", SearchOption.TopDirectoryOnly)
            .Count(DatasetScanner.IsImage);
        var sub = Directory.GetDirectories(dlg.SelectedPath).Length;

        _previewLabel.ForeColor = count > 0 ? Theme.Success : Theme.Warning;
        _previewLabel.Text = count > 0
            ? $"✓ 找到 {count} 张图片" + (sub > 0 ? $"（另有 {sub} 个子文件夹，暂不递归读取）" : "")
            : "✗ 这个文件夹里没有找到图片（支持 jpg/png/bmp/webp）";
    }

    private void BrowseProjectFolder()
    {
        using var dlg = new FolderBrowserDialog
        {
            Description = "选择标注工程目录",
            UseDescriptionForTitle = true,
        };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        var project = AnnotationProject.Load(dlg.SelectedPath);
        if (project is null)
        {
            MessageBox.Show(this, "这个目录不是有效的标注工程（缺少 project.json）。",
                "打开失败", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        Result = project;
        DialogResult = DialogResult.OK;
        Close();
    }

    private void OnConfirm()
    {
        if (_tabs.SelectedIndex == 1)
        {
            if (_recentList.SelectedItem is not string path || !File.Exists(Path.Combine(path, "project.json")))
            {
                MessageBox.Show(this, "请先在列表里选择一个工程。", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            var loaded = AnnotationProject.Load(path);
            if (loaded is null)
            {
                MessageBox.Show(this, "工程文件损坏，无法打开。", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Result = loaded;
            DialogResult = DialogResult.OK;
            Close();
            return;
        }

        // 新建
        var name = _nameBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(name))
        {
            MessageBox.Show(this, "请填写工程名称。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            _nameBox.Focus();
            return;
        }

        var src = _srcBox.Text.Trim();
        if (!Directory.Exists(src))
        {
            MessageBox.Show(this, "请选择一个存在的图片文件夹。", "提示",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var classes = _classBox.Text
            .Split(new[] { '\r', '\n', ',', '，', '、', ';', '；' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(s => s.Trim())
            .Where(s => s.Length > 0)
            .Distinct()
            .ToList();

        if (classes.Count == 0)
        {
            MessageBox.Show(this, "请至少填写一个类别名称。", "提示",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            _classBox.Focus();
            return;
        }

        var images = Directory.EnumerateFiles(src, "*.*", SearchOption.TopDirectoryOnly)
            .Where(DatasetScanner.IsImage)
            .ToList();

        if (images.Count == 0)
        {
            MessageBox.Show(this, "选中的文件夹里没有图片。", "提示",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var safeName = string.Concat(name.Select(ch => Path.GetInvalidFileNameChars().Contains(ch) ? '_' : ch));
        var root = Path.Combine(AppPaths.AnnotationRoot, $"{safeName}_{DateTime.Now:HHmmss}");
        if (Directory.Exists(root))
        {
            MessageBox.Show(this, "同名工程已存在，请换个名称。", "提示",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        try
        {
            Cursor = Cursors.WaitCursor;
            Result = AnnotationProject.Create(root, name, images, classes);
            AnnotationProjectRegistry.Touch(root);
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "创建工程失败：" + ex.Message, "错误",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            Cursor = Cursors.Default;
        }
    }
}

/// <summary>
/// 选择用于预标注的模型。来源：历史训练产物 + 手动浏览。
/// </summary>
public sealed class ModelPickerDialog : Form
{
    private readonly ListBox _list = new();
    private readonly Label _desc = new();
    private string? _manualPath;

    public string? SelectedModel { get; private set; }

    public ModelPickerDialog(MainForm host)
    {
        Text = "选择用于预标注的模型";
        Size = new Size(600, 440);
        BackColor = Theme.Background;
        Font = Theme.BaseFont;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent;

        var hint = new Label
        {
            Dock = DockStyle.Top,
            Height = 52,
            Padding = new Padding(16, 12, 16, 0),
            Font = Theme.SmallFont,
            ForeColor = Theme.TextSecondary,
            Text = "选择一个你之前训练出来的模型（best.pt），它会用学到的类别来预标注。\n" +
                   "没有历史模型的话，可以先手工标几十张、训练一次，再回来用这个功能。",
        };

        _list.Dock = DockStyle.Fill;
        _list.Font = Theme.BaseFont;
        _list.BorderStyle = BorderStyle.FixedSingle;
        _list.DoubleClick += (_, _) => Confirm();
        _list.SelectedIndexChanged += (_, _) => UpdateDesc();

        _desc.Dock = DockStyle.Bottom;
        _desc.Height = 52;
        _desc.Padding = new Padding(16, 4, 16, 4);
        _desc.Font = Theme.SmallFont;
        _desc.ForeColor = Theme.TextSecondary;

        var bottom = new Panel { Dock = DockStyle.Bottom, Height = 54, Padding = new Padding(16, 10, 16, 10) };
        var browse = new Button
        {
            Text = "浏览 .pt 文件…",
            Dock = DockStyle.Left,
            Width = 140,
            Height = 34,
            FlatStyle = FlatStyle.Flat,
            BackColor = Theme.Surface,
            Font = Theme.BaseFont,
            Cursor = Cursors.Hand,
        };
        browse.FlatAppearance.BorderColor = Theme.Border;
        browse.Click += (_, _) => BrowseModel();

        var ok = new Button
        {
            Text = "开始预标注",
            Dock = DockStyle.Right,
            Width = 120,
            Height = 34,
            FlatStyle = FlatStyle.Flat,
            BackColor = Theme.Primary,
            ForeColor = Color.White,
            Font = Theme.BodyFont,
            Cursor = Cursors.Hand,
        };
        ok.FlatAppearance.BorderSize = 0;
        ok.Click += (_, _) => Confirm();

        bottom.Controls.Add(ok);
        bottom.Controls.Add(browse);

        Controls.Add(_list);
        Controls.Add(_desc);
        Controls.Add(bottom);
        Controls.Add(hint);

        RefreshModels();
        Load += (_, _) =>
        {
            if (Owner is not null)
                Location = new Point(
                    Owner.Left + (Owner.Width - Width) / 2,
                    Owner.Top + (Owner.Height - Height) / 2);
        };
    }

    private void RefreshModels()
    {
        _list.Items.Clear();
        var root = AppPaths.ProjectsRoot;
        if (!Directory.Exists(root)) return;

        // 从训练产物里找 best.pt，按时间倒序
        var found = new List<(string Path, DateTime Time)>();
        foreach (var dir in Directory.GetDirectories(root))
        {
            foreach (var pt in Directory.EnumerateFiles(dir, "best.pt", SearchOption.AllDirectories))
            {
                var fi = new FileInfo(pt);
                found.Add((pt, fi.LastWriteTime));
            }
        }

        foreach (var (path, time) in found.OrderByDescending(f => f.Time))
        {
            var project = Path.GetFileName(Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(path))) ?? "");
            _list.Items.Add(new ModelEntry($"{project}　·　{time:MM-dd HH:mm}", path));
        }

        if (_list.Items.Count == 0)
            _list.Items.Add(new ModelEntry("（没有找到历史训练模型，可点左下角浏览 .pt 文件）", null));
        else
            _list.SelectedIndex = 0;
    }

    private void UpdateDesc()
    {
        if (_list.SelectedItem is not ModelEntry e || e.Path is null)
        {
            _desc.Text = "";
            return;
        }
        try
        {
            var fi = new FileInfo(e.Path);
            _desc.Text = $"{e.Path}\n大小 {fi.Length / 1024.0 / 1024.0:F1} MB";
        }
        catch
        {
            _desc.Text = e.Path;
        }
    }

    private void BrowseModel()
    {
        using var dlg = new OpenFileDialog
        {
            Title = "选择模型文件",
            Filter = "YOLO 模型 (*.pt)|*.pt|所有文件 (*.*)|*.*",
        };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        _manualPath = dlg.FileName;
        _list.Items.Add(new ModelEntry("手动选择：" + Path.GetFileName(dlg.FileName), dlg.FileName));
        _list.SelectedIndex = _list.Items.Count - 1;
    }

    private void Confirm()
    {
        var path = _list.SelectedItem is ModelEntry { Path: { } p } ? p : _manualPath;
        if (path is null || !File.Exists(path))
        {
            MessageBox.Show(this, "请选择一个有效的模型文件。", "提示",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        SelectedModel = path;
        DialogResult = DialogResult.OK;
        Close();
    }

    private sealed record ModelEntry(string Text, string? Path)
    {
        public override string ToString() => Text;
    }
}
