using VisionTrainer.App.UI;
using VisionTrainer.Core;
using VisionTrainer.Engine;
using VisionTrainer.Vision;

namespace VisionTrainer.App.Pages;

/// <summary>
/// 检测验证页：训练完的模型在这里"看效果"。
/// 支持三种输入：图片（多选）、视频文件（逐帧检测并输出标注视频）、摄像头（实时检测窗口）。
/// 所有结果（画好框的图/视频）保存在 %LOCALAPPDATA%\VisionTrainer\verify\ 下，可一键打开。
/// </summary>
public sealed class VerifyPage : UserControl, INavigablePage
{
    private readonly MainForm _host;
    private readonly AppSettings _settings;

    private readonly ComboBox _modelCombo = new();
    private readonly ComboBox _modeCombo = new();
    private readonly Button _browseModelBtn = new();
    private readonly Button _pickBtn = new();
    private readonly TrackBar _confSlider = new();
    private readonly Label _confLabel = new();
    private readonly Button _runBtn = new();
    private readonly Label _statusLabel = new();
    private readonly ProgressBar _progress = new();
    private readonly ListBox _imageList = new();
    private readonly PictureBox _pictureBox = new();
    private readonly ListBox _boxList = new();
    private readonly Label _summaryLabel = new();
    private readonly Button _openFolderBtn = new();
    private readonly CheckBox _saveCameraCheck = new();

    private List<string> _images = new();
    private string? _videoPath;
    private VerifyOutput? _lastOutput;
    private CancellationTokenSource? _cts;
    private string? _lastSaveDir;

    public VerifyPage(MainForm host, AppSettings settings)
    {
        _host = host;
        _settings = settings;
        BackColor = Theme.Background;

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Theme.Background,
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 380));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        // ================= 左列：参数卡片 =================
        // 全部用 FlowLayoutPanel 自动排列，杜绝绝对定位遮挡
        //（上一版手写坐标，标签和输入框叠在一起，截图确认过）
        var left = new CardPanel
        {
            Dock = DockStyle.Fill,
            Title = "检测设置",
            Subtitle = "选择模型与检测来源",
            Margin = new Padding(0, 0, Theme.Gap, 0),
        };

        var flow = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
        };
        flow.Controls.Add(FieldLabel("模型（.pt）"));

        var modelRow = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = new Padding(0, 2, 0, 8) };
        _modelCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        _modelCombo.Font = Theme.BaseFont;
        _modelCombo.Width = 230;
        _browseModelBtn.Text = "浏览…";
        _browseModelBtn.Width = 76;
        _browseModelBtn.Height = 27;
        _browseModelBtn.FlatStyle = FlatStyle.Flat;
        _browseModelBtn.BackColor = Theme.Surface;
        _browseModelBtn.FlatAppearance.BorderColor = Theme.Border;
        _browseModelBtn.Margin = new Padding(8, 1, 0, 0);
        _browseModelBtn.Click += (_, _) => BrowseModel();
        modelRow.Controls.Add(_modelCombo);
        modelRow.Controls.Add(_browseModelBtn);
        flow.Controls.Add(modelRow);

        flow.Controls.Add(FieldLabel("检测来源"));

        _modeCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        _modeCombo.Font = Theme.BaseFont;
        _modeCombo.Width = 314;
        _modeCombo.Margin = new Padding(0, 2, 0, 8);
        _modeCombo.Items.AddRange(new object[] { "图片（可多选）", "视频文件", "摄像头（实时检测）" });
        _modeCombo.SelectedIndex = 0;
        _modeCombo.SelectedIndexChanged += (_, _) => OnModeChanged();
        flow.Controls.Add(_modeCombo);

        _pickBtn.Text = "选择图片…";
        _pickBtn.Width = 314;
        _pickBtn.Height = 32;
        _pickBtn.FlatStyle = FlatStyle.Flat;
        _pickBtn.BackColor = Theme.Surface;
        _pickBtn.FlatAppearance.BorderColor = Theme.Border;
        _pickBtn.Margin = new Padding(0, 0, 0, 8);
        _pickBtn.Click += (_, _) => PickSource();
        flow.Controls.Add(_pickBtn);

        // 摄像头模式的附属选项
        _saveCameraCheck.Text = "同时把检测画面录制成视频保存";
        _saveCameraCheck.AutoSize = true;
        _saveCameraCheck.Font = Theme.SmallFont;
        _saveCameraCheck.ForeColor = Theme.TextSecondary;
        _saveCameraCheck.Margin = new Padding(0, 0, 0, 8);
        _saveCameraCheck.Checked = true;
        flow.Controls.Add(_saveCameraCheck);

        flow.Controls.Add(FieldLabel("置信度阈值：低于该分数的框不显示"));

        var confRow = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = new Padding(0, 2, 0, 8) };
        _confSlider.Minimum = 1;
        _confSlider.Maximum = 90;
        _confSlider.TickStyle = TickStyle.None;
        _confSlider.Width = 240;
        _confSlider.Value = 25;
        _confSlider.ValueChanged += (_, _) =>
            _confLabel.Text = $"{_confSlider.Value / 100.0:0.00}";
        _confLabel.Text = "0.25";
        _confLabel.Font = Theme.BaseFont;
        _confLabel.ForeColor = Theme.Primary;
        _confLabel.Margin = new Padding(12, 10, 0, 0);
        confRow.Controls.Add(_confSlider);
        confRow.Controls.Add(_confLabel);
        flow.Controls.Add(confRow);

        _runBtn.Text = "开始检测";
        _runBtn.Width = 314;
        _runBtn.Height = 38;
        _runBtn.FlatStyle = FlatStyle.Flat;
        _runBtn.FlatAppearance.BorderSize = 0;
        _runBtn.BackColor = Theme.Primary;
        _runBtn.ForeColor = Color.White;
        _runBtn.Font = Theme.BodyFont;
        _runBtn.Cursor = Cursors.Hand;
        _runBtn.Margin = new Padding(0, 4, 0, 6);
        _runBtn.Click += async (_, _) => await RunAsync();
        flow.Controls.Add(_runBtn);

        _progress.Width = 314;
        _progress.Height = 8;
        _progress.Style = ProgressBarStyle.Continuous;
        flow.Controls.Add(_progress);

        _statusLabel.Font = Theme.SmallFont;
        _statusLabel.ForeColor = Theme.TextSecondary;
        _statusLabel.AutoSize = false;
        _statusLabel.Width = 314;
        _statusLabel.Height = 46;
        _statusLabel.TextAlign = ContentAlignment.TopLeft;
        flow.Controls.Add(_statusLabel);

        _openFolderBtn.Text = "打开结果文件夹";
        _openFolderBtn.Width = 140;
        _openFolderBtn.Height = 28;
        _openFolderBtn.FlatStyle = FlatStyle.Flat;
        _openFolderBtn.BackColor = Theme.Surface;
        _openFolderBtn.FlatAppearance.BorderColor = Theme.Border;
        _openFolderBtn.Font = Theme.SmallFont;
        _openFolderBtn.Enabled = false;
        _openFolderBtn.Click += (_, _) => OpenResultFolder();
        flow.Controls.Add(_openFolderBtn);

        left.Controls.Add(flow);

        // ================= 右列：结果 =================
        var right = new CardPanel
        {
            Dock = DockStyle.Fill,
            Title = "检测结果",
        };

        _summaryLabel.Font = Theme.SmallFont;
        _summaryLabel.ForeColor = Theme.TextSecondary;
        _summaryLabel.AutoSize = false;
        _summaryLabel.Height = 22;
        _summaryLabel.TextAlign = ContentAlignment.MiddleLeft;
        _summaryLabel.SetLocation(16, 70);
        _summaryLabel.Width = 500;

        _imageList.Font = Theme.SmallFont;
        _imageList.Width = 200;
        _imageList.Height = 220;
        _imageList.IntegralHeight = false;
        _imageList.BorderStyle = BorderStyle.FixedSingle;
        _imageList.SetLocation(16, 96);
        _imageList.SelectedIndexChanged += (_, _) => ShowSelected();

        _pictureBox.BackColor = Color.FromArgb(38, 38, 42);
        _pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
        _pictureBox.BorderStyle = BorderStyle.FixedSingle;
        _pictureBox.Width = 400;
        _pictureBox.Height = 300;
        _pictureBox.SetLocation(226, 96);

        _boxList.Font = Theme.MonoFont;
        _boxList.IntegralHeight = false;
        _boxList.BorderStyle = BorderStyle.FixedSingle;
        _boxList.SetLocation(16, 430);
        _boxList.Width = 610;
        _boxList.Height = 120;

        right.Controls.AddRange(new Control[] { _summaryLabel, _imageList, _pictureBox, _boxList });
        right.Resize += (_, _) =>
        {
            _summaryLabel.Width = Math.Max(120, right.Width - 34);
            _pictureBox.Size = new Size(
                Math.Max(120, right.Width - _imageList.Width - 62),
                Math.Max(90, right.Height - 250));
            _pictureBox.SetLocation(_imageList.Right + 10, 96);
            _boxList.Width = Math.Max(120, right.Width - 34);
            _boxList.SetLocation(16, _pictureBox.Bottom + 12);
            _boxList.Height = Math.Max(60, right.Height - _boxList.Top - 26);
        };

        root.Controls.Add(left, 0, 0);
        root.Controls.Add(right, 1, 0);
        Controls.Add(root);
    }

    private static Label FieldLabel(string text) => new()
    {
        Text = text,
        Font = Theme.SmallFont,
        ForeColor = Theme.TextSecondary,
        AutoSize = true,
        Margin = new Padding(0, 6, 0, 2),
    };

    private void OnModeChanged()
    {
        _saveCameraCheck.Visible = _modeCombo.SelectedIndex == 2;
        _pickBtn.Text = _modeCombo.SelectedIndex switch
        {
            1 => (_videoPath is null ? "选择视频文件…" : "已选：" + Path.GetFileName(_videoPath) + "（点击更换）"),
            2 => "摄像头检测不需要选文件",
            _ => (_images.Count == 0 ? "选择图片…" : $"已选 {_images.Count} 张（点击更换）"),
        };
    }

    /// <summary>扫描历史训练产物里的 best.pt，让客户不用手动找路径。</summary>
    private List<(string Path, string Display)> DiscoverModels()
    {
        var list = new List<(string Path, string Display)>();
        try
        {
            var projects = AppPaths.ProjectsRoot;
            if (Directory.Exists(projects))
            {
                foreach (var pt in Directory.EnumerateFiles(projects, "best.pt", SearchOption.AllDirectories))
                {
                    var rel = Path.GetRelativePath(projects, pt);
                    var parts = rel.Split(Path.DirectorySeparatorChar);
                    var name = parts.Length > 0 ? parts[0] : rel;
                    list.Add((pt, $"历史训练 · {name}"));
                }
            }
            list.Sort((a, b) => string.Compare(b.Path, a.Path, StringComparison.OrdinalIgnoreCase));
        }
        catch { /* 扫描失败不阻断 */ }
        return list;
    }

    public void OnNavigatedTo()
    {
        var models = DiscoverModels();
        _modelCombo.Items.Clear();
        foreach (var (path, display) in models)
            _modelCombo.Items.Add(new ModelItem(display, path));

        if (!string.IsNullOrWhiteSpace(_settings.LastVerifyModel) && File.Exists(_settings.LastVerifyModel))
        {
            var custom = new ModelItem("自定义 · " + Path.GetFileName(_settings.LastVerifyModel),
                _settings.LastVerifyModel);
            if (!_modelCombo.Items.Cast<ModelItem>().Any(m => m.Path == custom.Path))
                _modelCombo.Items.Insert(0, custom);
        }

        if (_modelCombo.Items.Count > 0) _modelCombo.SelectedIndex = 0;
        else _statusLabel.Text = "还没有可用模型。请先在「训练」页训练一次。";
    }

    private void BrowseModel()
    {
        using var dlg = new OpenFileDialog
        {
            Title = "选择模型文件",
            Filter = "YOLO 模型 (*.pt)|*.pt",
        };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;
        _settings.LastVerifyModel = dlg.FileName;
        SettingsStore.Save(_settings);
        OnNavigatedTo();
    }

    private void PickSource()
    {
        switch (_modeCombo.SelectedIndex)
        {
            case 1: // 视频
            {
                using var dlg = new OpenFileDialog
                {
                    Title = "选择视频文件",
                    Filter = "视频|*.mp4;*.avi;*.mov;*.mkv;*.wmv",
                };
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                _videoPath = dlg.FileName;
                break;
            }
            case 2: // 摄像头
                MessageBox.Show(this,
                    "点「开始检测」后会弹出实时检测窗口。\n\n把物体放到摄像头前即可看到检测框，按 Q 键（或关掉窗口）结束。",
                    "摄像头检测", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            default: // 图片
            {
                using var dlg = new OpenFileDialog
                {
                    Title = "选择要检测的图片（可按住 Ctrl 多选）",
                    Filter = "图片|*.jpg;*.jpeg;*.png;*.bmp;*.webp",
                    Multiselect = true,
                };
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                _images = dlg.FileNames.ToList();
                break;
            }
        }
        OnModeChanged();
    }

    private async Task RunAsync()
    {
        if (_modelCombo.SelectedItem is not ModelItem model)
        {
            MessageBox.Show(this, "请先选择模型。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var mode = _modeCombo.SelectedIndex;
        if (mode == 0 && _images.Count == 0)
        {
            MessageBox.Show(this, "请先选择要检测的图片。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (mode == 1 && _videoPath is null)
        {
            MessageBox.Show(this, "请先选择视频文件。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        _runBtn.Enabled = false;
        _openFolderBtn.Enabled = false;
        _cts = new CancellationTokenSource();
        _statusLabel.ForeColor = Theme.TextSecondary;
        _statusLabel.Text = mode == 2 ? "正在打开摄像头…" : "正在检测…";

        var conf = _confSlider.Value / 100.0;
        var progress = new Progress<(int Done, int Total)>(p =>
        {
            _progress.Value = (int)Math.Clamp(p.Done * 100.0 / Math.Max(1, p.Total), 0, 100);
            if (mode == 1)
                _statusLabel.Text = $"正在检测视频 {p.Done}/{p.Total} 帧…";
            else
                _statusLabel.Text = $"正在检测 {p.Done}/{p.Total}…";
        });

        try
        {
            var env = new PythonEnvironment(_settings);
            var verifier = new ModelVerifier(env);

            if (mode == 1)
            {
                _lastOutput = await verifier.RunAsync(model.Path,
                    new[] { _videoPath! }, conf, progress, _cts.Token, saveVideo: true);
            }
            else if (mode == 2)
            {
                _lastOutput = await verifier.RunCameraAsync(model.Path, 0, conf,
                    _saveCameraCheck.Checked, _cts.Token);
            }
            else
            {
                _lastOutput = await verifier.RunAsync(model.Path, _images, conf, progress, _cts.Token);
            }

            _lastSaveDir = _lastOutput.SaveDir;
            _openFolderBtn.Enabled = _lastSaveDir is not null &&
                                     Directory.Exists(_lastSaveDir);

            if (mode == 2)
            {
                var camResult = _lastOutput.Camera;
                _imageList.Items.Clear();
                _pictureBox.Image = null;
                _boxList.Items.Clear();
                _statusLabel.ForeColor = Theme.Success;
                _statusLabel.Text = camResult is { Frames: > 0 }
                    ? $"检测结束：共 {camResult.Frames} 帧。" +
                      (File.Exists(camResult.SavedVideo) ? "录像已保存。" : "")
                    : "摄像头检测已结束。";
            }
            else
            {
                _imageList.Items.Clear();
                for (int i = 0; i < _lastOutput.Results.Count; i++)
                {
                    var r = _lastOutput.Results[i];
                    _imageList.Items.Add($"{i + 1}. {Path.GetFileName(r.ImagePath)}  ({r.Boxes.Count}框)");
                }
                if (_imageList.Items.Count > 0) _imageList.SelectedIndex = 0;

                var totalBoxes = _lastOutput.Results.Sum(r => r.Boxes.Count);
                _statusLabel.ForeColor = Theme.Success;
                var videoNote = mode == 1 && File.Exists(_lastOutput.Results.FirstOrDefault()?.VisPath)
                    ? "，标注视频已保存" : "";
                _statusLabel.Text = $"检测完成：{_lastOutput.Results.Count} 张图，共 {totalBoxes} 个框{videoNote}。";
            }
        }
        catch (OperationCanceledException)
        {
            _statusLabel.ForeColor = Theme.Warning;
            _statusLabel.Text = "已取消。";
        }
        catch (Exception ex)
        {
            _statusLabel.ForeColor = Theme.Danger;
            _statusLabel.Text = "检测失败：" + ex.Message.Split('\n').FirstOrDefault();
            MessageBox.Show(this, ex.Message, "检测失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            _runBtn.Enabled = true;
            _cts?.Dispose();
            _cts = null;
        }
    }

    private void OpenResultFolder()
    {
        if (_lastSaveDir is null || !Directory.Exists(_lastSaveDir)) return;
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
        {
            FileName = _lastSaveDir,
            UseShellExecute = true,
        });
    }

    private void ShowSelected()
    {
        if (_lastOutput is null || _imageList.SelectedIndex < 0) return;
        int idx = _imageList.SelectedIndex;
        if (idx >= _lastOutput.Results.Count) return;
        var r = _lastOutput.Results[idx];

        var showPath = File.Exists(r.VisPath) ? r.VisPath : r.ImagePath;
        try
        {
            var old = _pictureBox.Image;
            using var fs = new FileStream(showPath, FileMode.Open, FileAccess.Read);
            _pictureBox.Image = Image.FromStream(fs);
            old?.Dispose();
        }
        catch { }

        _boxList.Items.Clear();
        foreach (var b in r.Boxes.OrderByDescending(b => b.Score))
            _boxList.Items.Add(
                $"{b.ClassName,-12} {b.Score,5:P0}   ({b.Cx * r.Width:F0},{b.Cy * r.Height:F0}) {b.W * r.Width:F0}x{b.H * r.Height:F0}");

        _summaryLabel.Text = r.Boxes.Count == 0
            ? "这张图没有检测到目标。可以试着调低置信度，或确认图里确实有训练过的类别。"
            : $"检测到 {r.Boxes.Count} 个目标（按置信度排序）：";
    }

    private sealed record ModelItem(string Text, string Path)
    {
        public override string ToString() => Text;
    }
}
