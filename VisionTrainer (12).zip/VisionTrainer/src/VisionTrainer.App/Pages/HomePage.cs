using VisionTrainer.App.UI;
using VisionTrainer.Core;
using VisionTrainer.Data;

namespace VisionTrainer.App.Pages;

public sealed class HomePage : UserControl, INavigablePage
{
    private readonly MainForm _host;
    private readonly FlowLayoutPanel _tasks;

    public HomePage(MainForm host)
    {
        _host = host;
        BackColor = Theme.Background;
        Padding = new Padding(4);

        var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 1,
            Padding = new Padding(0),
            BackColor = Theme.Background,
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        root.Controls.Add(BuildHero());

        var sectionLabel = new Label
        {
            Text = "选择要训练的任务",
            Font = Theme.H2,
            ForeColor = Theme.TextPrimary,
            AutoSize = true,
            Margin = new Padding(0, 24, 0, 10),
        };
        root.Controls.Add(sectionLabel);

        _tasks = new FlowLayoutPanel
        {
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            BackColor = Theme.Background,
            Margin = new Padding(0),
        };
        root.Controls.Add(_tasks);

        scroll.Controls.Add(root);
        Controls.Add(scroll);
    }

    private Control BuildHero()
    {
        var card = new Panel
        {
            Height = 168,
            Dock = DockStyle.Top,
            Margin = new Padding(0, 0, 0, 8),
            BackColor = Theme.Background,
        };
        card.Paint += (_, e) =>
        {
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            var rect = new Rectangle(0, 0, card.Width - 1, card.Height - 1);
            using var path = Theme.RoundedRect(rect, Theme.Radius);
            using var brush = new System.Drawing.Drawing2D.LinearGradientBrush(
                rect, Color.FromArgb(0, 122, 255), Color.FromArgb(88, 86, 214), 0f);
            g.FillPath(brush, path);

            TextRenderer.DrawText(g, "把图片变成能用的模型", Theme.H1,
                new Rectangle(32, 32, card.Width - 64, 36), Color.White,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
            TextRenderer.DrawText(g,
                "标注数据放进来，点开始，剩下的交给它。不用装 Python，不用敲命令。",
                Theme.BodyFont,
                new Rectangle(32, 76, card.Width - 64, 24), Color.FromArgb(235, 244, 255),
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
        };

        var startBtn = new Button
        {
            Text = "开始标注",
            Size = new Size(130, 38),
            Location = new Point(32, 112),
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.White,
            ForeColor = Theme.Primary,
            Font = Theme.H3,
            Cursor = Cursors.Hand,
        };
        startBtn.FlatAppearance.BorderSize = 0;
        startBtn.Click += (_, _) => _host.Navigate("annotate");
        card.Controls.Add(startBtn);

        var importBtn = new Button
        {
            Text = "我已有标注数据",
            Size = new Size(150, 38),
            Location = new Point(174, 112),
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(40, 255, 255, 255),
            ForeColor = Color.White,
            Font = Theme.BaseFont,
            Cursor = Cursors.Hand,
        };
        importBtn.FlatAppearance.BorderSize = 1;
        importBtn.FlatAppearance.BorderColor = Color.FromArgb(150, 255, 255, 255);
        importBtn.Click += (_, _) => _host.Navigate("dataset");
        card.Controls.Add(importBtn);

        return card;
    }

    private void BuildTaskCards()
    {
        _tasks.Controls.Clear();
        _tasks.Controls.Add(TaskCard(
            "数据标注", "在图片上框出目标，或者让 AI 帮你先框好。\n标完自动存成训练格式。",
            "可用", true, () => _host.Navigate("annotate")));

        _tasks.Controls.Add(TaskCard(
            "目标检测训练", "框出图片里的物体，并告诉你它是什么、在哪。\n适合质检、安防、盘点等场景。",
            "可用", true, () => _host.Navigate("dataset")));

        _tasks.Controls.Add(TaskCard(
            "图像分类", "判断整张图片属于哪个类别。\n适合良品/不良品分拣。",
            "开发中", false, null));

        _tasks.Controls.Add(TaskCard(
            "文字识别 OCR", "读取图片中的文字内容。\n适合单据、标签、铭牌。",
            "规划中", false, null));
    }

    private Control TaskCard(string title, string desc, string badge, bool enabled, Action? onClick)
    {
        var card = new Panel
        {
            Size = new Size(258, 152),
            Margin = new Padding(0, 0, Theme.Gap, Theme.Gap),
            BackColor = Theme.Background,
        };

        card.Paint += (_, e) =>
        {
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            var rect = new Rectangle(0, 0, card.Width - 1, card.Height - 1);
            using var path = Theme.RoundedRect(rect, Theme.Radius);
            using var brush = new SolidBrush(enabled ? Theme.Surface : Color.FromArgb(250, 251, 252));
            using var pen = new Pen(enabled ? Theme.Border : Color.FromArgb(238, 240, 244));
            g.FillPath(brush, path);
            g.DrawPath(pen, path);

            TextRenderer.DrawText(g, title, Theme.H3,
                new Rectangle(16, 14, card.Width - 32, 22),
                enabled ? Theme.TextPrimary : Theme.TextSecondary,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter);

            var badgeColor = enabled ? Theme.Success : Theme.TextSecondary;
            var badgeSize = TextRenderer.MeasureText(badge, Theme.SmallFont);
            var badgeRect = new Rectangle(card.Width - badgeSize.Width - 24, 16, badgeSize.Width + 10, 18);
            using var badgeBrush = new SolidBrush(Color.FromArgb(28, badgeColor));
            using var badgePath = Theme.RoundedRect(badgeRect, 9);
            g.FillPath(badgeBrush, badgePath);
            TextRenderer.DrawText(g, badge, Theme.SmallFont,
                new Rectangle(badgeRect.X, badgeRect.Y, badgeRect.Width, badgeRect.Height),
                badgeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

            TextRenderer.DrawText(g, desc, Theme.SmallFont,
                new Rectangle(16, 44, card.Width - 32, 70),
                Theme.TextSecondary,
                TextFormatFlags.Left | TextFormatFlags.WordBreak);
        };

        if (enabled && onClick is not null)
        {
            card.Cursor = Cursors.Hand;
            card.Click += (_, _) => onClick();
        }

        return card;
    }

    public void OnNavigatedTo() => BuildTaskCards();
}
