using VisionTrainer.App.UI;
using VisionTrainer.Core;
using VisionTrainer.Data;

namespace VisionTrainer.App.Pages;

/// <summary>
/// 数据集页。核心体验目标：客户把文件夹拖进来 / 点一下选择，就能看到
/// "识别到什么格式、多少张图、多少个类别"，不需要懂 YOLO 目录规范。
/// </summary>
public sealed class DatasetPage : UserControl, INavigablePage
{
    private readonly MainForm _host;
    private readonly AppSettings _settings;

    private readonly ComboBox _taskCombo = new();
    private readonly StyledTextBox _pathBox = new();
    private readonly Button _browseBtn = new();
    private readonly Button _scanBtn = new();
    private readonly Panel _dropZone = new();
    private readonly DataGridView _classGrid = new();
    private readonly Label _summaryLabel = new();
    private readonly ListBox _messageList = new();
    private readonly Button _nextBtn = new();

    private DatasetSummary? _summary;

    public DatasetPage(MainForm host, AppSettings settings)
    {
        _host = host;
        _settings = settings;
        BackColor = Theme.Background;

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 96));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 56));

        root.Controls.Add(BuildTopBar(), 0, 0);
        root.Controls.Add(BuildBody(), 0, 1);
        root.Controls.Add(BuildBottomBar(), 0, 2);

        Controls.Add(root);

        AllowDrop = true;
        DragEnter += OnDragEnter;
        DragDrop += OnDragDrop;
        _dropZone.AllowDrop = true;
        _dropZone.DragEnter += OnDragEnter;
        _dropZone.DragDrop += OnDragDrop;
    }

    private Control BuildTopBar()
    {
        var panel = new Panel { Dock = DockStyle.Fill, Margin = new Padding(0, 0, 0, 12) };

        var title = new Label
        {
            Text = "导入数据集",
            Font = Theme.H1,
            ForeColor = Theme.TextPrimary,
            AutoSize = true,
            Location = new Point(0, 4),
        };

        var sub = new Label
        {
            Text = "支持 YOLO、COCO、Pascal VOC 三种标注格式，以及按文件夹分类的图像数据集。原数据不会被修改。",
            Font = Theme.SmallFont,
            ForeColor = Theme.TextSecondary,
            AutoSize = true,
            Location = new Point(2, 40),
        };

        _taskCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        _taskCombo.Font = Theme.BodyFont;
        _taskCombo.Width = 190;
        _taskCombo.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        _taskCombo.Location = new Point(panel.Width - 190, 8);
        _taskCombo.Items.AddRange(new object[] { "目标检测", "图像分类", "文字识别 OCR", "大模型微调" });
        _taskCombo.SelectedIndex = 0;
        panel.Resize += (_, _) => _taskCombo.Left = panel.Width - _taskCombo.Width;

        var taskLabel = new Label
        {
            Text = "任务类型",
            Font = Theme.SmallFont,
            ForeColor = Theme.TextSecondary,
            AutoSize = true,
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
        };
        taskLabel.Location = new Point(panel.Width - 250, 12);
        panel.Resize += (_, _) => taskLabel.Left = _taskCombo.Left - 70;

        panel.Controls.AddRange(new Control[] { title, sub, taskLabel, _taskCombo });
        return panel;
    }

    private Control BuildBody()
    {
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            Margin = new Padding(0),
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 46));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 54));

        // ---- 左：选择路径 ----
        var left = new CardPanel
        {
            Dock = DockStyle.Fill,
            Title = "选择数据位置",
            Subtitle = "把文件夹拖到下面的区域，或点「浏览」",
            Margin = new Padding(0, 0, 6, 0),
            Padding = new Padding(16, 16, 16, 16),
        };

        _dropZone.Dock = DockStyle.Top;
        _dropZone.Height = 150;
        _dropZone.BackColor = Theme.Background;
        _dropZone.Cursor = Cursors.Hand;
        _dropZone.Paint += (_, e) =>
        {
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            var rect = new Rectangle(0, 0, _dropZone.Width - 1, _dropZone.Height - 1);
            using var path = Theme.RoundedRect(rect, Theme.Radius);

            using (var bg = new SolidBrush(Color.FromArgb(250, 251, 253))) g.FillPath(bg, path);
            // 虚线边框：GDI+ 没有原生虚线圆角，用 Pen.DashStyle 在圆角路径上画效果尚可
            using (var pen = new Pen(Theme.Border, 1.4f) { DashStyle = System.Drawing.Drawing2D.DashStyle.Dash })
                g.DrawPath(pen, path);

            var iconRect = new Rectangle(_dropZone.Width / 2 - 16, 32, 32, 32);
            using (var iconPen = new Pen(Theme.Primary, 2))
            {
                g.DrawRectangle(iconPen, iconRect);
                g.DrawLine(iconPen, iconRect.Left + 6, iconRect.Top + 24, iconRect.Left + 14, iconRect.Top + 14);
                g.DrawLine(iconPen, iconRect.Left + 14, iconRect.Top + 14, iconRect.Left + 22, iconRect.Top + 22);
            }

            TextRenderer.DrawText(g, "拖拽数据集文件夹到这里",
                Theme.BodyFont,
                new Rectangle(0, 76, _dropZone.Width, 24),
                Theme.TextPrimary,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            TextRenderer.DrawText(g, "或点击此处浏览",
                Theme.SmallFont,
                new Rectangle(0, 100, _dropZone.Width, 20),
                Theme.TextSecondary,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        };
        _dropZone.Click += (_, _) => BrowseFolder();

        _pathBox.Dock = DockStyle.Top;
        _pathBox.PlaceholderText = @"例如 D:\数据\缺陷检测";
        _pathBox.Height = 30;
        _pathBox.Margin = new Padding(0, 0, 0, 8);

        var pathRow = new Panel { Dock = DockStyle.Top, Height = 40, Padding = new Padding(0, 10, 0, 0) };
        _browseBtn.Text = "浏览…";
        _browseBtn.Dock = DockStyle.Left;
        _browseBtn.Width = 76;
        _browseBtn.FlatStyle = FlatStyle.Flat;
        _browseBtn.FlatAppearance.BorderColor = Theme.Border;
        _browseBtn.BackColor = Theme.Surface;
        _browseBtn.Font = Theme.BaseFont;
        _browseBtn.Cursor = Cursors.Hand;
        _browseBtn.Click += (_, _) => BrowseFolder();

        _scanBtn.Text = "识别数据集";
        _scanBtn.Dock = DockStyle.Right;
        _scanBtn.Width = 110;
        _scanBtn.FlatStyle = FlatStyle.Flat;
        _scanBtn.FlatAppearance.BorderSize = 0;
        _scanBtn.BackColor = Theme.Primary;
        _scanBtn.ForeColor = Color.White;
        _scanBtn.Font = Theme.BodyFont;
        _scanBtn.Cursor = Cursors.Hand;
        _scanBtn.Click += async (_, _) => await ScanAsync();

        pathRow.Controls.Add(_scanBtn);
        pathRow.Controls.Add(_browseBtn);

        left.Controls.Add(pathRow);
        left.Controls.Add(_pathBox);
        left.Controls.Add(_dropZone);

        // ---- 右：识别结果 ----
        var right = new CardPanel
        {
            Dock = DockStyle.Fill,
            Title = "识别结果",
            Subtitle = "类别名称可双击修改",
            Margin = new Padding(6, 0, 0, 0),
        };

        _summaryLabel.Dock = DockStyle.Top;
        _summaryLabel.Height = 32;
        _summaryLabel.Font = Theme.BodyFont;
        _summaryLabel.Text = "尚未识别";
        _summaryLabel.ForeColor = Theme.TextSecondary;

        _classGrid.Dock = DockStyle.Top;
        _classGrid.Height = 168;
        _classGrid.AllowUserToAddRows = false;
        _classGrid.AllowUserToDeleteRows = false;
        _classGrid.RowHeadersVisible = false;
        _classGrid.BackgroundColor = Theme.Surface;
        _classGrid.BorderStyle = BorderStyle.FixedSingle;
        _classGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _classGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        _classGrid.ColumnHeadersHeight = 30;
        _classGrid.EnableHeadersVisualStyles = false;
        _classGrid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(248, 249, 251);
        _classGrid.ColumnHeadersDefaultCellStyle.Font = Theme.SmallFont;
        _classGrid.DefaultCellStyle.Font = Theme.BaseFont;
        _classGrid.GridColor = Theme.Border;
        _classGrid.ReadOnly = false;
        _classGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "idx", HeaderText = "编号", FillWeight = 22, ReadOnly = true });
        _classGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "name", HeaderText = "类别名称", FillWeight = 78 });

        _messageList.Dock = DockStyle.Fill;
        _messageList.BorderStyle = BorderStyle.None;
        _messageList.Font = Theme.SmallFont;
        _messageList.ForeColor = Theme.TextSecondary;
        _messageList.IntegralHeight = false;

        var msgHost = new Panel { Dock = DockStyle.Fill, Padding = new Padding(0, 8, 0, 0) };
        msgHost.Controls.Add(_messageList);

        right.Controls.Add(msgHost);
        right.Controls.Add(_classGrid);
        right.Controls.Add(_summaryLabel);

        layout.Controls.Add(left, 0, 0);
        layout.Controls.Add(right, 1, 0);
        return layout;
    }

    private Control BuildBottomBar()
    {
        var panel = new Panel { Dock = DockStyle.Fill };

        _nextBtn.Text = "下一步：设置训练参数";
        _nextBtn.Size = new Size(190, 38);
        _nextBtn.Anchor = AnchorStyles.Right | AnchorStyles.Top;
        _nextBtn.FlatStyle = FlatStyle.Flat;
        _nextBtn.FlatAppearance.BorderSize = 0;
        _nextBtn.BackColor = Theme.PrimaryDisabled;
        _nextBtn.ForeColor = Color.White;
        _nextBtn.Font = Theme.BodyFont;
        _nextBtn.Enabled = false;
        _nextBtn.Location = new Point(panel.Width - 190, 10);
        _nextBtn.Click += (_, _) =>
        {
            if (_summary is null) return;
            _summary.Classes = ReadClassesFromGrid();
            _host.GoToTrainingWithDataset(_summary);
        };
        panel.Resize += (_, _) => _nextBtn.Left = panel.Width - _nextBtn.Width;

        panel.Controls.Add(_nextBtn);
        return panel;
    }

    private void BrowseFolder()
    {
        using var dlg = new FolderBrowserDialog
        {
            Description = "选择数据集根目录",
            UseDescriptionForTitle = true,
            ShowNewFolderButton = false,
        };
        if (dlg.ShowDialog(FindForm()) == DialogResult.OK)
        {
            _pathBox.Text = dlg.SelectedPath;
            _ = ScanAsync();
        }
    }

    private void OnDragEnter(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetDataPresent(DataFormats.FileDrop) == true)
            e.Effect = DragDropEffects.Copy;
    }

    private void OnDragDrop(object? sender, DragEventArgs e)
    {
        if (e.Data?.GetData(DataFormats.FileDrop) is string[] { Length: > 0 } paths)
        {
            _pathBox.Text = paths[0];
            _ = ScanAsync();
        }
    }

    private async Task ScanAsync()
    {
        var path = _pathBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path))
        {
            MessageBox.Show(this, "请选择一个存在的文件夹。", "提示",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        _scanBtn.Enabled = false;
        _summaryLabel.Text = "正在识别…";
        _summaryLabel.ForeColor = Theme.TextSecondary;
        _messageList.Items.Clear();
        _classGrid.Rows.Clear();

        var task = _taskCombo.SelectedIndex switch
        {
            1 => TaskKind.Classification,
            2 => TaskKind.Ocr,
            3 => TaskKind.LlmFinetune,
            _ => TaskKind.Detection,
        };

        try
        {
            var summary = await Task.Run(() => DatasetScanner.Scan(path, task));
            _summary = summary;
            RenderSummary(summary);
        }
        catch (Exception ex)
        {
            _summaryLabel.Text = "识别失败";
            _summaryLabel.ForeColor = Theme.Danger;
            _messageList.Items.Add(ex.Message);
        }
        finally
        {
            _scanBtn.Enabled = true;
        }
    }

    private void RenderSummary(DatasetSummary s)
    {
        _summaryLabel.ForeColor = s.IsUsable ? Theme.Success : Theme.Danger;
        _summaryLabel.Text = s.IsUsable
            ? $"✓ 格式：{LayoutName(s.Layout)}　|　训练图 {s.TrainImages} 张　|　验证图 {s.ValImages} 张　|　{s.Classes.Count} 个类别"
            : "✗ 数据集不可用";

        _classGrid.Rows.Clear();
        foreach (var c in s.Classes.OrderBy(c => c.Index))
            _classGrid.Rows.Add(c.Index, c.Name);

        _messageList.Items.Clear();
        foreach (var w in s.Warnings) _messageList.Items.Add("⚠ " + w);
        foreach (var err in s.Errors) _messageList.Items.Add("✗ " + err);

        var supported = PipelineIsSupported(s.Task);
        _nextBtn.Enabled = s.IsUsable && supported;
        _nextBtn.BackColor = _nextBtn.Enabled ? Theme.Primary : Theme.PrimaryDisabled;

        if (!supported)
            _messageList.Items.Add("✗ 该任务类型尚未实现，当前版本仅支持目标检测。");
    }

    private static bool PipelineIsSupported(TaskKind kind) =>
        VisionTrainer.Engine.PipelineRegistry.IsSupported(kind);

    private List<ClassDef> ReadClassesFromGrid()
    {
        var list = new List<ClassDef>();
        foreach (DataGridViewRow row in _classGrid.Rows)
        {
            if (row.IsNewRow) continue;
            var idx = Convert.ToInt32(row.Cells[0].Value ?? list.Count);
            var name = row.Cells[1].Value?.ToString()?.Trim() ?? $"class_{idx}";
            list.Add(new ClassDef { Index = idx, Name = name, ColorHex = Palette.ColorFor(idx) });
        }
        return list;
    }

    private static string LayoutName(string layout) => layout switch
    {
        nameof(DataLayout.YoloDetection) => "YOLO",
        nameof(DataLayout.CocoDetection) => "COCO",
        nameof(DataLayout.VocDetection) => "Pascal VOC",
        nameof(DataLayout.ImageFolder) => "图像分类目录",
        _ => "未知",
    };

    public void OnNavigatedTo() { }
}
