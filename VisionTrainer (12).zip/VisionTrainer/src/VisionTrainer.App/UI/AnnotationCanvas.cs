using System.Drawing.Drawing2D;
using VisionTrainer.Data;

namespace VisionTrainer.App.UI;

/// <summary>
/// 标注画布。负责：图片等比缩放显示、拖拽画框、选中/移动/删除框。
///
/// 坐标系统说明（这是本控件最容易出错的地方，改动前务必看懂）：
///  - 标注数据一律存归一化坐标 0~1（与 YOLO 一致，与图片分辨率无关）
///  - 屏幕坐标 ↔ 图片像素坐标 要用 _scale 和 _offset 转换
///  - _scale = 显示尺寸 / 原图尺寸，图片在控件里居中，_offset 是左上角的偏移
/// </summary>
public sealed class AnnotationCanvas : Control
{
    private Image? _image;
    private AnnotationImage? _current;

    private float _scale = 1f;
    private PointF _offset;

    // 交互状态
    private bool _drawing;
    private PointF _dragStart;
    private PointF _dragCurrent;
    private int _moveIndex = -1;
    private PointF _moveStartPoint;
    private List<BoundingBox> _moveOriginals = new();

    public event Action? AnnotationsChanged;

    /// <summary>当前选中的框下标，-1 表示无。</summary>
    public int SelectedIndex { get; private set; } = -1;

    /// <summary>画新框时使用的类别。</summary>
    public int CurrentClass { get; set; }

    public Func<int, Color>? ClassColorProvider { get; set; }
    public Func<int, string>? ClassNameProvider { get; set; }

    public AnnotationCanvas()
    {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                 ControlStyles.Selectable, true);
        BackColor = Color.FromArgb(38, 40, 44);
        TabStop = true;
    }

    public AnnotationImage? CurrentImage => _current;

    public void SetImage(AnnotationImage? image)
    {
        if (_current != image)
        {
            _current?.Boxes.RemoveAll(b => !b.IsValid);
            _image?.Dispose();
            _image = null;
        }

        _current = image;
        SelectedIndex = -1;

        if (image is not null && File.Exists(image.FilePath))
        {
            try
            {
                // 用流加载后再复制一份，避免文件被 Image 长期占用导致无法删除
                using var fs = new FileStream(image.FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                using var tmp = Image.FromStream(fs);
                _image = new Bitmap(tmp);
                if (image.Width <= 0 || image.Height <= 0)
                {
                    image.Width = _image.Width;
                    image.Height = _image.Height;
                }
            }
            catch
            {
                _image = null;
            }
        }

        UpdateLayout();
        Invalidate();
    }

    private void UpdateLayout()
    {
        if (_image is null || Width <= 0 || Height <= 0)
        {
            _scale = 1f;
            _offset = PointF.Empty;
            return;
        }

        const int pad = 12;
        var availW = Math.Max(1, Width - pad * 2);
        var availH = Math.Max(1, Height - pad * 2);
        _scale = MathF.Min(availW / (float)_image.Width, availH / (float)_image.Height);
        var dispW = _image.Width * _scale;
        var dispH = _image.Height * _scale;
        _offset = new PointF((Width - dispW) / 2f, (Height - dispH) / 2f);
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        UpdateLayout();
    }

    // ---------- 坐标换算 ----------
    private PointF ToImagePixel(PointF screen) => new(
        (screen.X - _offset.X) / _scale,
        (screen.Y - _offset.Y) / _scale);

    private RectangleF ToScreenRect(BoundingBox b)
    {
        if (_image is null) return RectangleF.Empty;
        return new RectangleF(
            _offset.X + (float)(b.Left * _image.Width) * _scale,
            _offset.Y + (float)(b.Top * _image.Height) * _scale,
            (float)b.W * _image.Width * _scale,
            (float)b.H * _image.Height * _scale);
    }

    private bool InsideImage(PointF screen)
    {
        if (_image is null) return false;
        var w = _image.Width * _scale;
        var h = _image.Height * _scale;
        return screen.X >= _offset.X && screen.X <= _offset.X + w &&
               screen.Y >= _offset.Y && screen.Y <= _offset.Y + h;
    }

    // ---------- 鼠标交互 ----------
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        Focus();
        if (_current is null || _image is null || e.Button != MouseButtons.Left) return;

        var pt = e.Location;

        // 先判断是否点在已有的框上 → 进入移动模式
        var hit = HitTest(pt);
        if (hit >= 0)
        {
            SelectedIndex = hit;
            _moveIndex = hit;
            _moveStartPoint = pt;
            var target = _current.Boxes[hit];
            _moveOriginals = _current.Boxes.Select(b => b.Clone()).ToList();
            Cursor = Cursors.SizeAll;
            Invalidate();
            return;
        }

        // 否则开始画新框
        if (!InsideImage(pt)) return;
        SelectedIndex = -1;
        _drawing = true;
        _dragStart = pt;
        _dragCurrent = pt;
        Invalidate();
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);

        if (_moveIndex >= 0 && _current is not null && _image is not null)
        {
            var dx = (e.X - _moveStartPoint.X) / _scale / _image.Width;
            var dy = (e.Y - _moveStartPoint.Y) / _scale / _image.Height;

            // 把整批框一起移动（多选暂不支持，这里只移当前选中的）
            var original = _moveOriginals[_moveIndex];
            var moved = _current.Boxes[_moveIndex];
            moved.Cx = Math.Clamp(original.Cx + dx, moved.W / 2, 1 - moved.W / 2);
            moved.Cy = Math.Clamp(original.Cy + dy, moved.H / 2, 1 - moved.H / 2);
            _current.IsDirty = true;
            Invalidate();
            return;
        }

        if (_drawing)
        {
            _dragCurrent = e.Location;
            Invalidate();
            return;
        }

        // 悬停时换光标，给客户"这里可以点"的反馈
        Cursor = _current is not null && HitTest(e.Location) >= 0 ? Cursors.SizeAll
            : InsideImage(e.Location) ? Cursors.Cross
            : Cursors.Default;
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (_current is null || _image is null) return;

        if (_moveIndex >= 0)
        {
            _moveIndex = -1;
            _moveOriginals.Clear();
            AnnotationsChanged?.Invoke();
            return;
        }

        if (!_drawing) return;
        _drawing = false;

        var startPx = ToImagePixel(_dragStart);
        var endPx = ToImagePixel(e.Location);

        // 太小的拖动视为误触，避免产生一堆 1px 的垃圾框
        if (Math.Abs(endPx.X - startPx.X) < 4 || Math.Abs(endPx.Y - startPx.Y) < 4)
        {
            Invalidate();
            return;
        }

        var box = BoundingBox.FromPixels(startPx.X, startPx.Y, endPx.X, endPx.Y,
            _image.Width, _image.Height, CurrentClass);

        if (box.IsValid)
        {
            _current.Boxes.Add(box);
            _current.IsDirty = true;
            SelectedIndex = _current.Boxes.Count - 1;
            AnnotationsChanged?.Invoke();
        }
        Invalidate();
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        if (_current is null) return;

        if (e.KeyCode is Keys.Delete or Keys.Back)
        {
            DeleteSelected();
            e.Handled = true;
        }
    }

    public void DeleteSelected()
    {
        if (_current is null || SelectedIndex < 0 || SelectedIndex >= _current.Boxes.Count) return;
        _current.Boxes.RemoveAt(SelectedIndex);
        _current.IsDirty = true;
        SelectedIndex = -1;
        AnnotationsChanged?.Invoke();
        Invalidate();
    }

    public void ClearAll()
    {
        if (_current is null || _current.Boxes.Count == 0) return;
        _current.Boxes.Clear();
        _current.IsDirty = true;
        SelectedIndex = -1;
        AnnotationsChanged?.Invoke();
        Invalidate();
    }

    public void SelectBox(int index)
    {
        SelectedIndex = index >= 0 && _current is not null && index < _current.Boxes.Count ? index : -1;
        Invalidate();
    }

    private int HitTest(PointF pt)
    {
        if (_current is null) return -1;
        // 从后往前找，后画的框在上层
        for (int i = _current.Boxes.Count - 1; i >= 0; i--)
        {
            if (ToScreenRect(_current.Boxes[i]).Contains(pt)) return i;
        }
        return -1;
    }

    // ---------- 绘制 ----------
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(BackColor);

        if (_image is null)
        {
            TextRenderer.DrawText(g, "没有可显示的图片", Font ?? SystemFonts.DefaultFont,
                ClientRectangle, Color.FromArgb(140, 145, 155),
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            return;
        }

        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        var dest = new RectangleF(_offset.X, _offset.Y,
            _image.Width * _scale, _image.Height * _scale);
        g.DrawImage(_image, dest);

        g.SmoothingMode = SmoothingMode.AntiAlias;
        using var borderPen = new Pen(Color.FromArgb(90, 95, 105));
        g.DrawRectangle(borderPen, dest.X, dest.Y, dest.Width, dest.Height);

        if (_current is not null)
        {
            for (int i = 0; i < _current.Boxes.Count; i++)
                DrawBox(g, _current.Boxes[i], i == SelectedIndex);
        }

        if (_drawing)
            DrawPreview(g);
    }

    private void DrawBox(Graphics g, BoundingBox box, bool selected)
    {
        var rect = ToScreenRect(box);
        if (rect.Width < 1 || rect.Height < 1) return;

        var color = ClassColorProvider?.Invoke(box.ClassIndex) ?? Color.OrangeRed;

        // 选中时加半透明填充，未选中只描边，画面更干净
        if (selected)
        {
            using var fill = new SolidBrush(Color.FromArgb(40, color));
            g.FillRectangle(fill, rect);
        }

        // AI 预标注用虚线，提醒客户这是机器猜的、需要复核
        using var pen = new Pen(color, selected ? 2.4f : 1.6f)
        {
            DashStyle = box.FromAi ? DashStyle.Dash : DashStyle.Solid,
        };
        g.DrawRectangle(pen, rect.X, rect.Y, rect.Width, rect.Height);

        // 左上角类别标签
        var name = ClassNameProvider?.Invoke(box.ClassIndex) ?? $"#{box.ClassIndex}";
        var text = box.FromAi ? name + " · AI" : name;
        var size = g.MeasureString(text, Font ?? SystemFonts.DefaultFont);
        var labelRect = new RectangleF(rect.X, Math.Max(_offset.Y, rect.Y - size.Height - 2),
            size.Width + 8, size.Height + 2);

        using var labelBg = new SolidBrush(color);
        g.FillRectangle(labelBg, labelRect);
        using var textBrush = new SolidBrush(Color.White);
        g.DrawString(text, Font ?? SystemFonts.DefaultFont, textBrush, labelRect.X + 4, labelRect.Y + 1);
    }

    private void DrawPreview(Graphics g)
    {
        var rect = RectangleF.FromLTRB(
            Math.Min(_dragStart.X, _dragCurrent.X),
            Math.Min(_dragStart.Y, _dragCurrent.Y),
            Math.Max(_dragStart.X, _dragCurrent.X),
            Math.Max(_dragStart.Y, _dragCurrent.Y));

        var color = ClassColorProvider?.Invoke(CurrentClass) ?? Color.OrangeRed;
        using var pen = new Pen(color, 1.6f) { DashStyle = DashStyle.Dot };
        g.DrawRectangle(pen, rect.X, rect.Y, rect.Width, rect.Height);

        if (_image is not null && _scale > 0)
        {
            var info = $"{(int)(rect.Width / _scale)} × {(int)(rect.Height / _scale)} px";
            TextRenderer.DrawText(g, info, Font ?? SystemFonts.DefaultFont,
                new Point((int)(rect.Right + 6), (int)(rect.Bottom + 4)), Color.White,
                TextFormatFlags.NoPadding);
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) _image?.Dispose();
        base.Dispose(disposing);
    }
}
