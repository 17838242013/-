using System.Drawing.Drawing2D;

namespace VisionTrainer.App.UI;

/// <summary>
/// 视觉规范。集中管理颜色/字号/圆角，避免每个窗体各写一套导致界面不统一。
/// </summary>
public static class Theme
{
    public static readonly Color Background = Color.FromArgb(247, 248, 250);
    public static readonly Color Surface = Color.White;
    public static readonly Color Border = Color.FromArgb(226, 230, 236);
    public static readonly Color Primary = Color.FromArgb(0, 122, 255);
    public static readonly Color PrimaryHover = Color.FromArgb(0, 100, 220);
    public static readonly Color PrimaryDisabled = Color.FromArgb(178, 205, 240);
    public static readonly Color TextPrimary = Color.FromArgb(28, 30, 34);
    public static readonly Color TextSecondary = Color.FromArgb(110, 118, 130);
    public static readonly Color Success = Color.FromArgb(45, 178, 92);
    public static readonly Color Warning = Color.FromArgb(230, 145, 20);
    public static readonly Color Danger = Color.FromArgb(220, 55, 55);

    public const int Radius = 8;
    public const int Gap = 12;

    private static readonly string[] FontCandidates = { "Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI" };

    public static readonly Font BaseFont = CreateFont(9.5f, FontStyle.Regular);
    public static readonly Font SmallFont = CreateFont(8.5f, FontStyle.Regular);
    public static readonly Font BodyFont = CreateFont(10f, FontStyle.Regular);
    public static readonly Font H1 = CreateFont(20f, FontStyle.Bold);
    public static readonly Font H2 = CreateFont(13f, FontStyle.Bold);
    public static readonly Font H3 = CreateFont(10.5f, FontStyle.Bold);
    public static readonly Font MonoFont = new("Consolas", 8.5f);

    private static Font CreateFont(float size, FontStyle style)
    {
        var installed = FontFamily.Families.Select(f => f.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var name = FontCandidates.FirstOrDefault(c => installed.Contains(c)) ?? FontFamily.GenericSansSerif.Name;
        return new Font(name, size, style, GraphicsUnit.Point);
    }

    public static GraphicsPath RoundedRect(Rectangle bounds, int radius)
    {
        var path = new GraphicsPath();
        if (radius <= 0)
        {
            path.AddRectangle(bounds);
            return path;
        }
        int d = radius * 2;
        path.AddArc(bounds.X, bounds.Y, d, d, 180, 90);
        path.AddArc(bounds.Right - d, bounds.Y, d, d, 270, 90);
        path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }

    /// <summary>把窗口居中到屏幕，避免多显示器下出现在屏幕外。</summary>
    public static void CenterOnScreen(Form form)
    {
        var screen = Screen.FromPoint(Cursor.Position).WorkingArea;
        form.StartPosition = FormStartPosition.Manual;
        form.Location = new Point(
            screen.X + (screen.Width - form.Width) / 2,
            screen.Y + (screen.Height - form.Height) / 2);
    }
}

/// <summary>扁平主按钮，带圆角与悬停态。客户对"看起来专业"很敏感。</summary>
public sealed class PrimaryButton : Button
{
    private bool _hover;
    private bool _pressed;

    public PrimaryButton()
    {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        FlatStyle = FlatStyle.Flat;
        FlatAppearance.BorderSize = 0;
        Font = Theme.BodyFont;
        ForeColor = Color.White;
        Cursor = Cursors.Hand;
        Height = 38;
        BackColor = Theme.Primary;
    }

    public bool IsSecondary { get; set; }

    protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { _hover = false; _pressed = false; Invalidate(); base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { _pressed = true; Invalidate(); base.OnMouseDown(e); }
    protected override void OnMouseUp(MouseEventArgs e) { _pressed = false; Invalidate(); base.OnMouseUp(e); }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;

        var color = !Enabled ? Theme.PrimaryDisabled
            : IsSecondary ? (_hover ? Color.FromArgb(240, 242, 246) : Theme.Surface)
            : _pressed ? Theme.PrimaryHover
            : _hover ? Color.FromArgb(20, 110, 235)
            : Theme.Primary;

        var rect = new Rectangle(0, 0, Width - 1, Height - 1);
        using var path = Theme.RoundedRect(rect, Theme.Radius);
        using var brush = new SolidBrush(color);
        g.FillPath(brush, path);

        if (IsSecondary)
        {
            using var pen = new Pen(Theme.Border);
            g.DrawPath(pen, path);
        }

        var textColor = IsSecondary ? Theme.TextPrimary : ForeColor;
        if (!Enabled) textColor = Theme.TextSecondary;
        TextRenderer.DrawText(g, Text, Font, rect,
            textColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
    }
}

/// <summary>卡片容器：白底圆角 + 细边框 + 可选标题。</summary>
public sealed class CardPanel : Panel
{
    public CardPanel()
    {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        BackColor = Theme.Background;
        Padding = new Padding(16);
    }

    public string? Title { get; set; }
    public string? Subtitle { get; set; }

    /// <summary>标题占用的顶部高度，子控件排版要从这之下开始。</summary>
    private int TitleInset =>
        string.IsNullOrEmpty(Title) ? 0
        : string.IsNullOrEmpty(Subtitle) ? 30 : 46;

    protected override void OnResize(EventArgs eventargs)
    {
        base.OnResize(eventargs);
        UpdateInsets();
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        UpdateInsets();
    }

    private void UpdateInsets()
    {
        // 子控件（尤其 Dock.Top 的）必须从标题下方开始，否则盖住标题文字
        int top = TitleInset + 12;
        var desired = new Padding(16, top, 16, 12);
        if (Padding != desired) Padding = desired;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;

        int top = 0;
        if (!string.IsNullOrEmpty(Title))
        {
            // 标题画在白卡上方的灰色区域，白卡从标题下方开始
            var titleRect = new Rectangle(Padding.Left, Math.Max(8, Padding.Top - TitleInset), Width - Padding.Horizontal, 26);
            TextRenderer.DrawText(g, Title, Theme.H2, titleRect, Theme.TextPrimary,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter);

            if (!string.IsNullOrEmpty(Subtitle))
            {
                var subRect = new Rectangle(Padding.Left, titleRect.Bottom + 2, Width - Padding.Horizontal, 20);
                TextRenderer.DrawText(g, Subtitle, Theme.SmallFont, subRect, Theme.TextSecondary,
                    TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
            }
            top = Padding.Top;
        }

        var rect = new Rectangle(0, top, Width - 1, Height - top - 1);
        using var path = Theme.RoundedRect(rect, Theme.Radius);
        using var brush = new SolidBrush(Theme.Surface);
        using var pen = new Pen(Theme.Border);
        g.FillPath(brush, path);
        g.DrawPath(pen, path);

        base.OnPaint(e);
    }
}

/// <summary>左侧导航项。</summary>
public sealed class NavItem : Control
{
    private bool _hover;

    public NavItem(string text)
    {
        Text = text;
        Height = 42;
        Dock = DockStyle.Top;
        Cursor = Cursors.Hand;
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        Font = Theme.BodyFont;
    }

    public bool Selected { get; set; }

    protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }
    protected override void OnClick(EventArgs e) { base.OnClick(e); }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;

        var rect = new Rectangle(8, 4, Width - 16, Height - 8);
        Color bg = Selected ? Color.FromArgb(232, 241, 254)
            : _hover ? Color.FromArgb(240, 242, 246)
            : Color.Transparent;

        if (bg != Color.Transparent)
        {
            using var path = Theme.RoundedRect(rect, 6);
            using var brush = new SolidBrush(bg);
            g.FillPath(brush, path);
        }

        if (Selected)
        {
            using var accent = new SolidBrush(Theme.Primary);
            using var accentPath = Theme.RoundedRect(new Rectangle(0, 10, 3, Height - 20), 2);
            g.FillPath(accent, accentPath);
        }

        var color = Selected ? Theme.Primary : Theme.TextPrimary;
        var textRect = new Rectangle(rect.X + 14, rect.Y, rect.Width - 20, rect.Height);
        TextRenderer.DrawText(g, Text, Font, textRect, color,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
    }
}

/// <summary>
/// 统一风格的输入框。.NET 8 的 TextBox 已内置 PlaceholderText，
/// 这里只做样式统一，不再重复实现占位符绘制。
/// </summary>
public sealed class StyledTextBox : TextBox
{
    public StyledTextBox()
    {
        BorderStyle = BorderStyle.FixedSingle;
        Font = Theme.BodyFont;
    }
}
