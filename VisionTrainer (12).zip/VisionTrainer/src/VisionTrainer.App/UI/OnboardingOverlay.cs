using System.Drawing.Drawing2D;

namespace VisionTrainer.App.UI;

/// <summary>引导步骤。</summary>
public sealed record OnboardingStep(string Title, string Body, string Tip);

/// <summary>
/// 分步操作引导浮层。半透明遮罩 + 居中的步骤卡片。
///
/// 为什么不用 MessageBox：客户会一路点"确定"关掉，而浮层需要"上一步/下一步"
/// 的节奏感，且视觉上明显是"教程"而不是"警告"。
/// </summary>
public sealed class OnboardingOverlay : Panel
{
    private readonly List<OnboardingStep> _steps;
    private int _index;
    private readonly Action? _onFinished;

    private readonly Button _prevBtn = new();
    private readonly Button _nextBtn = new();
    private readonly Button _skipBtn = new();
    private readonly Label _stepLabel = new();

    /// <summary>卡片区域，供外部做"高亮挖洞"用。</summary>
    public Rectangle CardBounds => new(
        ClientSize.Width / 2 - 300, ClientSize.Height / 2 - 150, 600, 300);

    public OnboardingOverlay(IEnumerable<OnboardingStep> steps, Action? onFinished = null)
    {
        _steps = steps.ToList();
        _onFinished = onFinished;

        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        BackColor = Color.FromArgb(20, 22, 26);
        Visible = false;
        Dock = DockStyle.Fill;

        _stepLabel.AutoSize = false;
        _stepLabel.TextAlign = ContentAlignment.MiddleCenter;
        _stepLabel.Font = Theme.SmallFont;
        _stepLabel.ForeColor = Theme.TextSecondary;
        _stepLabel.BackColor = Color.Transparent;

        ConfigureNavButton(_prevBtn, "上一步", secondary: true);
        ConfigureNavButton(_nextBtn, "下一步", secondary: false);
        ConfigureNavButton(_skipBtn, "跳过引导", secondary: true);

        _prevBtn.Click += (_, _) => { if (_index > 0) { _index--; Render(); } };
        _nextBtn.Click += (_, _) =>
        {
            if (_index < _steps.Count - 1) { _index++; Render(); }
            else Finish();
        };
        _skipBtn.Click += (_, _) => Finish();

        Controls.AddRange(new Control[] { _stepLabel, _prevBtn, _nextBtn, _skipBtn });
    }

    private static void ConfigureNavButton(Button b, string text, bool secondary)
    {
        b.Text = text;
        b.Size = new Size(110, 34);
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = 0;
        b.Font = Theme.BaseFont;
        b.Cursor = Cursors.Hand;
        b.BackColor = secondary ? Color.FromArgb(245, 246, 248) : Theme.Primary;
        b.ForeColor = secondary ? Theme.TextPrimary : Color.White;
    }

    public void Start()
    {
        _index = 0;
        Visible = true;
        BringToFront();
        Render();
    }

    private void Finish()
    {
        Visible = false;
        _onFinished?.Invoke();
    }

    private void Render()
    {
        var step = _steps[_index];
        _stepLabel.Text = $"第 {_index + 1} / {_steps.Count} 步";

        _prevBtn.Visible = _index > 0;
        _nextBtn.Text = _index == _steps.Count - 1 ? "开始标注" : "下一步";
        _skipBtn.Visible = _index < _steps.Count - 1;

        LayoutChildren();
        Invalidate();
    }

    private void LayoutChildren()
    {
        var card = CardBounds;
        _stepLabel.SetBounds(card.X + 32, card.Bottom - 74, card.Width - 64, 20);

        _nextBtn.Location = new Point(card.Right - 32 - _nextBtn.Width, card.Bottom - 46);
        _prevBtn.Location = new Point(_nextBtn.Left - 12 - _prevBtn.Width, card.Bottom - 46);
        _skipBtn.Location = new Point(card.X + 32, card.Bottom - 46);
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        LayoutChildren();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        if (_steps.Count == 0) return;
        var g = e.Graphics;

        // 半透明遮罩，让底下的界面变暗但仍可辨认
        using (var mask = new SolidBrush(Color.FromArgb(150, 16, 18, 22)))
            g.FillRectangle(mask, ClientRectangle);

        g.SmoothingMode = SmoothingMode.AntiAlias;
        var card = CardBounds;

        using (var path = Theme.RoundedRect(card, 12))
        using (var brush = new SolidBrush(Color.White))
        using (var shadow = new SolidBrush(Color.FromArgb(50, 0, 0, 0)))
        {
            var shadowRect = new Rectangle(card.X + 2, card.Y + 6, card.Width, card.Height);
            using var shadowPath = Theme.RoundedRect(shadowRect, 12);
            g.FillPath(shadow, shadowPath);
            g.FillPath(brush, path);
        }

        var step = _steps[_index];

        // 步骤序号徽标
        var badge = new Rectangle(card.X + 32, card.Y + 28, 40, 40);
        using (var badgeBrush = new SolidBrush(Color.FromArgb(232, 241, 254)))
            g.FillEllipse(badgeBrush, badge);
        TextRenderer.DrawText(g, (_index + 1).ToString(), new Font(Theme.BaseFont.FontFamily, 15f, FontStyle.Bold),
            badge, Theme.Primary, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);

        TextRenderer.DrawText(g, step.Title, Theme.H1,
            new Rectangle(card.X + 86, card.Y + 30, card.Width - 120, 38),
            Theme.TextPrimary, TextFormatFlags.Left | TextFormatFlags.VerticalCenter);

        TextRenderer.DrawText(g, step.Body, Theme.BodyFont,
            new Rectangle(card.X + 32, card.Y + 86, card.Width - 64, 96),
            Theme.TextPrimary,
            TextFormatFlags.Left | TextFormatFlags.WordBreak | TextFormatFlags.NoPadding);

        // 提示条
        var tipRect = new Rectangle(card.X + 32, card.Bottom - 122, card.Width - 64, 34);
        using (var tipPath = Theme.RoundedRect(tipRect, 6))
        using (var tipBrush = new SolidBrush(Color.FromArgb(255, 249, 235)))
            g.FillPath(tipBrush, tipPath);
        TextRenderer.DrawText(g, "提示：" + step.Tip, Theme.SmallFont,
            new Rectangle(tipRect.X + 10, tipRect.Y, tipRect.Width - 20, tipRect.Height),
            Color.FromArgb(150, 105, 20),
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);

        // 底部进度圆点
        var dotY = card.Bottom - 62;
        var totalW = _steps.Count * 14;
        var startX = card.X + (card.Width - totalW) / 2;
        for (int i = 0; i < _steps.Count; i++)
        {
            var r = new Rectangle(startX + i * 14, dotY, 7, 7);
            using var b = new SolidBrush(i == _index ? Theme.Primary : Color.FromArgb(210, 214, 220));
            g.FillEllipse(b, r);
        }
    }
}
