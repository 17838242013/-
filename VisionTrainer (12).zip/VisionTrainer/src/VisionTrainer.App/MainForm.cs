using VisionTrainer.App.Pages;
using VisionTrainer.App.UI;
using VisionTrainer.Core;
using VisionTrainer.Pipeline;

namespace VisionTrainer.App;

public sealed class MainForm : Form
{
    private readonly AppSettings _settings;
    private readonly Panel _content;
    private readonly Panel _nav;
    private readonly Label _statusLabel;
    private readonly List<NavItem> _navItems = new();
    private readonly Dictionary<string, UserControl> _pages = new();

    public MainForm()
    {
        _settings = SettingsStore.Load();
        JobRunner.BootstrapPipelines();

        Text = "VisionTrainer · 视觉模型训练工坊";
        MinimumSize = new Size(1120, 720);
        Size = new Size(1240, 800);
        BackColor = Theme.Background;
        Font = Theme.BaseFont;
        StartPosition = FormStartPosition.CenterScreen;

        // ---------- 左侧导航 ----------
        _nav = new Panel
        {
            Dock = DockStyle.Left,
            Width = 210,
            BackColor = Color.FromArgb(252, 253, 254),
            Padding = new Padding(0, 8, 0, 0),
        };
        _nav.Paint += (_, e) =>
        {
            using var pen = new Pen(Theme.Border);
            e.Graphics.DrawLine(pen, _nav.Width - 1, 0, _nav.Width - 1, _nav.Height);
        };

        var brand = new Panel { Dock = DockStyle.Top, Height = 64 };
        brand.Paint += (_, e) =>
        {
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using var path = Theme.RoundedRect(new Rectangle(20, 20, 26, 26), 7);
            using var brush = new SolidBrush(Theme.Primary);
            g.FillPath(brush, path);
            TextRenderer.DrawText(g, "VT", new Font(Theme.BaseFont.FontFamily, 9f, FontStyle.Bold),
                new Rectangle(20, 20, 26, 26), Color.White,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            TextRenderer.DrawText(g, "VisionTrainer", Theme.H3,
                new Rectangle(54, 22, 140, 24), Theme.TextPrimary,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
        };
        _nav.Controls.Add(brand);

        var footer = new Label
        {
            Dock = DockStyle.Bottom,
            Height = 36,
            Text = $"v{typeof(MainForm).Assembly.GetName().Version?.ToString(3)}",
            ForeColor = Theme.TextSecondary,
            Font = Theme.SmallFont,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(20, 0, 0, 8),
        };
        _nav.Controls.Add(footer);

        AddNav("home", "开始", built: false);
        AddNav("annotate", "标注", built: false);
        AddNav("dataset", "数据集", built: false);
        AddNav("train", "训练", built: false);
        AddNav("verify", "检测验证", built: false);
        AddNav("history", "历史任务", built: false);
        AddNav("settings", "环境与设置", built: false);

        // Dock 顺序：后加的先停靠，需要反转
        for (int i = _nav.Controls.Count - 1; i >= 0; i--)
        {
            var c = _nav.Controls[i];
            if (c is NavItem ni) ni.BringToFront();
        }

        // ---------- 内容区 ----------
        _content = new Panel { Dock = DockStyle.Fill, Padding = new Padding(20, 16, 20, 8) };

        // ---------- 状态栏 ----------
        var statusBar = new Panel { Dock = DockStyle.Bottom, Height = 28, BackColor = Theme.Surface };
        statusBar.Paint += (_, e) =>
        {
            using var pen = new Pen(Theme.Border);
            e.Graphics.DrawLine(pen, 0, 0, statusBar.Width, 0);
        };
        _statusLabel = new Label
        {
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(22, 0, 0, 0),
            ForeColor = Theme.TextSecondary,
            Font = Theme.SmallFont,
            Text = BuildStatusText(),
        };
        statusBar.Controls.Add(_statusLabel);

        Controls.Add(_content);
        Controls.Add(statusBar);
        Controls.Add(_nav);

        Navigate("home");
        Load += (_, _) => Theme.CenterOnScreen(this);
    }

    private string BuildStatusText()
    {
        var gpus = GpuDetector.Detect();
        var device = gpus.Count > 0
            ? $"GPU · {gpus[0].Name}"
            : "CPU 模式";
        var env = File.Exists(AppPaths.PythonExe) ? "运行环境已就绪" : "运行环境未安装（首次训练自动安装）";
        return $"{device}    |    {env}";
    }

    public void RefreshStatus()
    {
        _statusLabel.Text = BuildStatusText();
    }

    private void AddNav(string key, string text, bool built)
    {
        var item = new NavItem(text);
        item.Click += (_, _) => Navigate(key);
        _navItems.Add(item);
        _nav.Controls.Add(item);
    }

    public void Navigate(string key)
    {
        foreach (var item in _navItems)
        {
            var target = PropFor(item.Text);
            item.Selected = target == key;
            item.Invalidate();
        }

        if (!_pages.TryGetValue(key, out var page))
        {
            page = CreatePage(key);
            page.Dock = DockStyle.Fill;
            _pages[key] = page;
        }

        _content.SuspendLayout();
        _content.Controls.Clear();
        _content.Controls.Add(page);
        _content.ResumeLayout();

        if (page is INavigablePage np) np.OnNavigatedTo();
    }

    private static string PropFor(string navText) => navText switch
    {
        "开始" => "home",
        "标注" => "annotate",
        "数据集" => "dataset",
        "训练" => "train",
        "检测验证" => "verify",
        "历史任务" => "history",
        "环境与设置" => "settings",
        _ => "home",
    };

    private UserControl CreatePage(string key) => key switch
    {
        "home" => new HomePage(this),
        "annotate" => new AnnotatePage(this, _settings),
        "dataset" => new DatasetPage(this, _settings),
        "train" => new TrainPage(this, _settings),
        "verify" => new VerifyPage(this, _settings),
        "history" => new HistoryPage(this),
        "settings" => new SettingsPage(this, _settings),
        _ => new HomePage(this),
    };

    public AppSettings Settings => _settings;

    /// <summary>数据集 → 训练 的跨页传递。</summary>
    public DatasetSummary? CurrentDataset { get; set; }

    /// <summary>标注页当前打开的工程，供跨页复用。</summary>
    public Data.AnnotationProject? AnnotationProject { get; set; }

    /// <summary>导航到指定页面（供其他页面内部跳转用）。</summary>
    public void NavigateTo(string key) => Navigate(key);

    public void GoToTrainingWithDataset(DatasetSummary dataset)
    {
        CurrentDataset = dataset;
        Navigate("train");
    }
}

public interface INavigablePage
{
    void OnNavigatedTo();
}
