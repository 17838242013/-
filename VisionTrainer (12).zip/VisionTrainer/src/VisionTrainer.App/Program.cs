using VisionTrainer.Core;
using VisionTrainer.Engine;

namespace VisionTrainer.App;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();

        // 全局异常兜底：客户现场最怕"点了没反应"或"闪退无提示"
        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, e) => ReportFatal(e.Exception);
        AppDomain.CurrentDomain.UnhandledException += (_, e) => ReportFatal(e.ExceptionObject as Exception);

        AppPaths.EnsureCreated();

        var settings = SettingsStore.Load();

        // 首次启动自动检测硬件并确定 PyTorch 档位
        if (!settings.GpuAutoDetectDone)
        {
            var gpus = GpuDetector.Detect();
            settings.Profile = GpuDetector.RecommendProfile(gpus);
            settings.GpuAutoDetectDone = true;
            SettingsStore.Save(settings);
        }

        try
        {
            Application.Run(new MainForm());
        }
        catch (Exception ex)
        {
            ReportFatal(ex);
        }
    }

    private static void ReportFatal(Exception? ex)
    {
        if (ex is null) return;

        try
        {
            AppPaths.EnsureCreated();
            var logFile = Path.Combine(AppPaths.LogsRoot, $"crash_{DateTime.Now:yyyyMMdd_HHmmss}.log");
            File.WriteAllText(logFile, DateTime.Now + Environment.NewLine + ex + Environment.NewLine + SystemProbe.Describe());
        }
        catch
        {
            // 写日志失败时仍要弹出提示
        }

        MessageBox.Show(
            "程序遇到意外错误，已记录日志，可把「环境与设置 → 诊断信息」发给技术支持。\n\n" + ex.Message,
            "出错了",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error);
    }
}
