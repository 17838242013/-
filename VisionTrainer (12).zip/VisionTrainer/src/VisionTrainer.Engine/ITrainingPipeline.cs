using VisionTrainer.Core;

namespace VisionTrainer.Engine;

/// <summary>
/// 训练流程抽象。新增任务类型（OCR / 大模型微调）时只需实现本接口并注册，
/// 主流程（环境检查 → 数据准备 → 训练 → 导出）完全不用改。
/// 这是本项目的可扩展性核心，务必保持接口精简。
/// </summary>
public interface ITrainingPipeline
{
    TaskKind Kind { get; }
    string DisplayName { get; }

    /// <summary>该任务暴露给用户的超参定义，UI 据此自动生成表单，不硬编码控件。</summary>
    IReadOnlyList<ParameterSpec> Parameters { get; }

    /// <summary>训练前校验，返回空列表表示可训练。</summary>
    IReadOnlyList<string> Validate(DatasetSummary dataset, TrainingOptions options);

    /// <summary>
    /// 执行训练。实现方负责：
    ///  - 准备数据到 workDir
    ///  - 拉起 Python 进程并解析进度
    ///  - 把产物模型路径写入 job.Exports
    /// </summary>
    Task RunAsync(
        TrainingJob job,
        PythonEnvironment env,
        TrainingContext ctx,
        CancellationToken ct);
}

/// <summary>超参描述，用于自动生成 UI 表单。</summary>
public sealed record ParameterSpec(
    string Key,
    string Label,
    ParameterKind Kind,
    object? Default,
    string? Unit = null,
    double Min = 0,
    double Max = 0,
    string? Help = null);

public enum ParameterKind
{
    Int = 0,
    Double = 1,
    Bool = 2,
    Choice = 3,
    Text = 4,
}

/// <summary>流程与 UI 之间的通信通道。</summary>
public sealed class TrainingContext
{
    public required Action<string> Log { get; init; }
    public required Action<EpochMetrics> OnEpoch { get; init; }
    public required Action<double, string> OnStage { get; init; }
    public required Action<string> OnRawProgress { get; init; }
    public required Action<string> OnArtifact { get; init; }
}

/// <summary>流程注册表。</summary>
public static class PipelineRegistry
{
    private static readonly Dictionary<TaskKind, ITrainingPipeline> Map = new();

    public static void Register(ITrainingPipeline pipeline) => Map[pipeline.Kind] = pipeline;

    public static ITrainingPipeline Get(TaskKind kind) =>
        Map.TryGetValue(kind, out var p)
            ? p
            : throw new NotSupportedException($"任务类型 {kind} 尚未实现，请先在 PipelineRegistry 中注册对应流程。");

    public static bool IsSupported(TaskKind kind) => Map.ContainsKey(kind);

    public static IReadOnlyCollection<ITrainingPipeline> All => Map.Values;
}
