using System.Text.RegularExpressions;
using VisionTrainer.Core;
using VisionTrainer.Data;

namespace VisionTrainer.Engine.Pipelines;

/// <summary>
/// 目标检测训练流程（YOLO11）。
/// 用 ultralytics 而不是自己写训练循环：它的预训练权重、数据增强、mosaic、EMA
/// 都是经过大规模验证的，自研循环在客户数据上大概率更差。
/// 我们只负责把"客户数据 + 傻瓜参数"翻译成正确的 ultralytics 调用。
/// </summary>
public sealed class DetectionPipeline : ITrainingPipeline
{
    public TaskKind Kind => TaskKind.Detection;
    public string DisplayName => "目标检测（YOLO11）";

    public IReadOnlyList<ParameterSpec> Parameters { get; } = new ParameterSpec[]
    {
        new("BaseModel", "基础模型", ParameterKind.Choice, "yolo11n", Help: "n 最快/s 平衡/m 更准，数据量少时用 n 或 s"),
        new("ImageSize", "输入尺寸", ParameterKind.Int, 640, "px", 320, 1280, "必须是 32 的倍数；越大越准也越慢"),
        new("Epochs", "训练轮数", ParameterKind.Int, 100, "轮", 10, 1000, "数据少时 100~300 足够"),
        new("BatchSize", "批大小", ParameterKind.Int, 16, null, 1, 128, "显存不够会自动减半重试"),
        new("LearningRate", "学习率", ParameterKind.Double, 0.01, null, 0.0001, 0.1),
        new("Patience", "早停耐心值", ParameterKind.Int, 30, "轮", 0, 200, "连续 N 轮无提升则停止，0 表示不早停"),
        new("UseAugmentation", "启用数据增强", ParameterKind.Bool, true),
    };

    public IReadOnlyList<string> Validate(DatasetSummary dataset, TrainingOptions options)
    {
        var errors = new List<string>();

        if (dataset.TrainImages < 10)
            errors.Add($"训练图只有 {dataset.TrainImages} 张，太少。目标检测建议每个类别至少 100 张标注图。");

        if (dataset.Classes.Count == 0)
            errors.Add("未识别到任何类别，请检查 data.yaml 或标注文件。");

        var emptyNames = dataset.Classes.Where(c => string.IsNullOrWhiteSpace(c.Name) || c.Name.StartsWith("class_")).ToList();
        if (emptyNames.Count > 0)
            errors.Add($"有 {emptyNames.Count} 个类别名称未填写，请先在类别列表中补全（会影响导出模型的可读性）。");

        var dup = dataset.Classes.GroupBy(c => c.Name).Where(g => g.Count() > 1).Select(g => g.Key).ToList();
        if (dup.Count > 0)
            errors.Add("存在重复的类别名：" + string.Join("、", dup));

        if (options.ImageSize % 32 != 0)
            errors.Add("输入尺寸必须是 32 的倍数（例如 416 / 512 / 640）。");

        if (options.Epochs < 1) errors.Add("训练轮数必须大于 0。");
        if (options.BatchSize < 1) errors.Add("批大小必须大于 0。");

        return errors;
    }

    public async Task RunAsync(TrainingJob job, PythonEnvironment env, TrainingContext ctx, CancellationToken ct)
    {
        var options = job.Options;
        var dataset = job.Dataset ?? throw new InvalidOperationException("数据集为空");

        // ---------- 1. 数据准备 ----------
        ctx.OnStage(2, "准备数据集");
        ctx.Log($"数据集格式：{dataset.Layout}，训练图 {dataset.TrainImages} 张，类别 {dataset.Classes.Count} 个");

        var preparer = new DatasetPreparer(ctx.Log);
        var prepared = await preparer.PrepareAsync(dataset, options, job.WorkDirectory, ct);
        foreach (var note in prepared.Notes) ctx.Log(note);
        ctx.Log($"data.yaml 已生成：{prepared.DataYamlPath}");

        // ---------- 2. 组织训练参数 ----------
        var script = Path.Combine(AppContext.BaseDirectory, "resources", "python", "train_detect.py");
        if (!File.Exists(script))
            throw new FileNotFoundException("训练脚本缺失，安装包可能不完整。", script);

        var args = new List<string>
        {
            script,
            "--data", prepared.DataYamlPath,
            "--workdir", job.WorkDirectory,
            "--model", job.Options.BaseModel,
            "--epochs", options.Epochs.ToString(),
            "--batch", options.BatchSize.ToString(),
            "--imgsz", options.ImageSize.ToString(),
            "--lr0", options.LearningRate.ToString(System.Globalization.CultureInfo.InvariantCulture),
            "--patience", options.Patience.ToString(),
            "--workers", options.Workers.ToString(),
            "--augment", options.UseAugmentation ? "1" : "0",
            "--pretrained", options.UsePretrained ? "1" : "0",
            "--seed", options.Seed.ToString(),
        };

        // 显式传 classes，避免 ultralytics 读 yaml 时把中文类别名搞乱
        var namesJson = System.Text.Json.JsonSerializer.Serialize(
            dataset.Classes.OrderBy(c => c.Index).ToDictionary(c => c.Index, c => c.Name));
        args.Add("--names-json");
        args.Add(namesJson);

        // 环境安装时已把 yolo11n.pt 下载到 WeightsDir，训练前就位（5.4MB）。
        // 不传这个参数脚本也能跑，但会退回 ultralytics 联网下载——内网必卡死。
        args.Add("--weights-dir");
        args.Add(AppPaths.WeightsDir);

        if (options.Resume) args.Add("--resume");

        foreach (var kv in options.ExtraArgs)
        {
            args.Add("--set");
            args.Add($"{kv.Key}={kv.Value}");
        }

        // ---------- 3. 拉起训练进程 ----------
        ctx.OnStage(5, "启动训练进程");
        var runner = new ProcessRunner();
        var parser = new DetectionProgressParser(job, ctx.OnEpoch);

        runner.Output += line =>
        {
            ctx.Log(line);
            parser.Feed(line);
            var pct = parser.OverallPercent();
            if (pct > 0) ctx.OnRawProgress(line);
            if (pct > 0) ctx.OnStage(Math.Max(5, pct), "训练中");
        };
        runner.ErrorOutput += line =>
        {
            // ultralytics 把大量正常输出打到 stderr，不能直接当错误弹窗
            ctx.Log(line);
        };

        var envVars = env.BuildEnvironment();
        var exitCode = await runner.RunAsync(env.PythonExe, args, job.WorkDirectory, envVars, ct);

        if (exitCode != 0)
        {
            var tail = string.Join('\n', runner.RecentLines.TakeLast(40));
            throw new InvalidOperationException(ExplainFailure(exitCode, tail));
        }

        // ---------- 4. 收集产物 ----------
        ctx.OnStage(96, "收集模型产物");
        CollectOutputs(job, ctx);
        ctx.OnStage(100, "完成");
    }

    /// <summary>把 ultralytics 的报错翻译成客户能看懂的话。这一步能挡掉大量售后电话。</summary>
    private static string ExplainFailure(int exitCode, string output)
    {
        if (output.Contains("CUDA out of memory", StringComparison.OrdinalIgnoreCase))
            return "显存不足。请把批大小调小（如 8 或 4），或把输入尺寸从 640 降到 512。\n\n" + output;

        if (output.Contains("No such file", StringComparison.OrdinalIgnoreCase) &&
            output.Contains("data.yaml", StringComparison.OrdinalIgnoreCase))
            return "数据集配置文件丢失，请重新导入数据集。\n\n" + output;

        if (output.Contains("ModuleNotFoundError", StringComparison.OrdinalIgnoreCase))
            return "运行环境缺少依赖。请在「设置 → 修复运行环境」中重试安装。\n\n" + output;

        if (output.Contains("DLL load failed", StringComparison.OrdinalIgnoreCase))
            return "系统缺少 Visual C++ 运行库（VC++ 2015-2022 x64）。请联系管理员安装后重试。\n\n" + output;

        if (output.Contains("images not found", StringComparison.OrdinalIgnoreCase) ||
            output.Contains("No images found", StringComparison.OrdinalIgnoreCase))
            return "没有找到可用的训练图片，请检查数据集路径是否正确、图片格式是否受支持。\n\n" + output;

        return $"训练进程异常退出（退出码 {exitCode}）。详细日志见任务目录。\n\n{output}";
    }

    private static void CollectOutputs(TrainingJob job, TrainingContext ctx)
    {
        var weightsDir = Path.Combine(job.WorkDirectory, "runs", "detect", "train", "weights");
        if (!Directory.Exists(weightsDir))
            weightsDir = Directory.GetDirectories(job.WorkDirectory, "weights", SearchOption.AllDirectories).FirstOrDefault() ?? "";

        if (string.IsNullOrEmpty(weightsDir) || !Directory.Exists(weightsDir)) return;

        foreach (var pt in Directory.GetFiles(weightsDir, "*.pt"))
        {
            job.Exports.Add(new ExportedModel
            {
                Name = Path.GetFileNameWithoutExtension(pt),
                Format = "pytorch",
                FilePath = pt,
                SizeBytes = new FileInfo(pt).Length,
            });
            ctx.OnArtifact(pt);
        }
    }
}

/// <summary>
/// 解析 ultralytics 训练输出为结构化指标。
/// 依赖它打印的进度表行，形如：
/// <code>
///       1/100      1.234      1.567      0.891        120       640: 100%|...| 50/50 [00:30&lt;00:00]
///                  Class     Images  Instances      Box(P          R      mAP50  mAP50-95): 100%|...|
///                    all        100        300      0.801      0.712      0.789      0.612
/// </code>
/// 表头的位置在不同版本会变，所以用"列名 → 索引"动态映射，而不是死写列号。
/// </summary>
public sealed class DetectionProgressParser
{
    private readonly TrainingJob _job;
    private readonly Action<EpochMetrics> _onEpoch;
    private readonly Dictionary<string, int> _columns = new(StringComparer.OrdinalIgnoreCase);
    private int _totalEpochs;
    private int _currentEpoch = -1;
    private EpochMetrics? _pending;

    private static readonly Regex EpochRow = new(@"^\s*(\d+)/(\d+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)", RegexOptions.Compiled);
    private static readonly Regex ColumnHeader = new(@"Class\s+Images\s+Instances\s+Box\(", RegexOptions.Compiled);
    private static readonly string[] MetricKeys = { "Box(P", "R", "mAP50", "mAP50-95" };

    public DetectionProgressParser(TrainingJob job, Action<EpochMetrics> onEpoch)
    {
        _job = job;
        _onEpoch = onEpoch;
        _totalEpochs = job.Options.Epochs;
    }

    public void Feed(string line)
    {
        var epochMatch = EpochRow.Match(line);
        if (epochMatch.Success)
        {
            _currentEpoch = int.Parse(epochMatch.Groups[1].Value);
            _totalEpochs = int.Parse(epochMatch.Groups[2].Value);
            return;
        }

        if (ColumnHeader.IsMatch(line))
        {
            _columns.Clear();
            for (int i = 0; i < MetricKeys.Length; i++)
                _columns[MetricKeys[i]] = i; // 顺序固定，见 ultralytics validator 输出
            return;
        }

        // 汇总行：前几列是类别名 + 样本数，最后一组是四个指标
        var trimmed = line.Trim();
        if (!trimmed.StartsWith("all ", StringComparison.OrdinalIgnoreCase)) return;

        var parts = trimmed.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length < 7) return;

        // 倒数 4 个是 Box(P) R mAP50 mAP50-95
        // 注意：不要写 parts.Reverse()，数组上的 Reverse() 会歧义匹配到
        // MemoryExtensions.Reverse(Span<T>)（返回 void），导致 CS0030 编译错误。
        var nums = parts.Skip(parts.Length - 4)
            .Select(s => double.TryParse(s, out var v) ? (double?)v : null)
            .ToArray();
        if (nums.Any(n => n is null)) return;

        var m = _pending ??= new EpochMetrics { Epoch = _currentEpoch > 0 ? _currentEpoch : _job.History.Count + 1 };
        m.TotalEpochs = _totalEpochs;
        m.Precision = nums[0];
        m.Recall = nums[1];
        m.Map50 = nums[2];
        m.Map50_95 = nums[3];

        _job.History.Add(m);
        if (_job.Best is null || (m.Map50_95 ?? 0) > (_job.Best.Map50_95 ?? 0)) _job.Best = m;
        _pending = null;
        _onEpoch(m);
    }

    public double OverallPercent()
    {
        if (_totalEpochs <= 0) return 0;
        return Math.Clamp(_job.History.Count / (double)_totalEpochs * 100, 0, 100);
    }
}
