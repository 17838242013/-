using System.IO.Compression;
using VisionTrainer.Core;

namespace VisionTrainer.Engine;

/// <summary>
/// Python 环境自举管理器 —— "客户不需要装环境"的核心。
///
/// 两种交付形态：
///  A. 联网首次启动（推荐给有网的客户）：下载 embeddable zip（约 11MB）→ 解压 → 装 pip → 装依赖。
///  B. 完全离线（内网/断网机器）：把打包好的 <c>runtime/python</c> 目录随安装包一起发布，
///     本类检测到已存在则全部跳过，实现"零下载、零配置"。
///
/// 为什么用 embeddable 而不是安装版 Python：
///  - 不写注册表、不污染 PATH、不需要管理员权限
///  - 整个目录可拷贝、可卸载干净，客户 IT 部门最容易接受
/// </summary>
public sealed class PythonEnvironment
{
    private readonly AppSettings _settings;
    private readonly Action<string>? _log;
    private readonly string _pythonRoot;

    public PythonEnvironment(AppSettings settings, string? pythonRoot = null, Action<string>? log = null)
    {
        _settings = settings;
        _log = log;
        _pythonRoot = pythonRoot ?? AppPaths.PythonRoot;
    }

    public string PythonExe => Path.Combine(_pythonRoot, "python.exe");
    public bool IsReady => File.Exists(PythonExe) && File.Exists(MarkerFile);

    /// <summary>依赖装完后写的标记文件，版本号变化会触发重装。</summary>
    public string MarkerFile => Path.Combine(_pythonRoot, "env.version");

    /// <summary>
    /// 当前依赖集合的版本签名，改 requirements 时必须同步改这里。
    /// v2：opencv-headless → 完整版 opencv-python（摄像头实时检测需要 cv2.imshow）。
    /// 注意：换签名只会触发 pip 重装缺的包，torch 已装好不会重新下载 2.5GB。
    /// </summary>
    public const string EnvSignature = "ultralytics==8.4.*|torch2.6|v2";

    public sealed class ProgressReport
    {
        public string Stage { get; init; } = "";
        public double Percent { get; init; }
        public string? Detail { get; init; }
    }

    public async Task<bool> EnsureReadyAsync(
        ComputeProfile profile,
        IProgress<ProgressReport>? progress,
        CancellationToken ct)
    {
        AppPaths.EnsureCreated();

        // 权重检查放在 marker 判断之前：已装好环境的用户不会再走安装流程，
        // 若放后面，权重缺失就永远没机会补。文件已存在时这一步瞬间完成。
        // 失败不阻断：有网的机器 ultralytics 训练时自己也能下。
        try
        {
            await EnsureBaseWeightsAsync("yolo11n.pt", ct);
        }
        catch (Exception ex)
        {
            _log?.Invoke($"预训练权重下载失败（训练时会再试）：{ex.Message}");
        }

        if (IsReady && await File.ReadAllTextAsync(MarkerFile, ct) == $"{EnvSignature}|{profile}")
        {
            _log?.Invoke("Python 环境已就绪，跳过安装。");
            progress?.Report(new ProgressReport { Stage = "环境就绪", Percent = 100 });
            return true;
        }

        // 1) 备选：程序目录自带完整 runtime（离线安装包形态）
        foreach (var bundled in new[]
                 {
                     Path.Combine(AppContext.BaseDirectory, "runtime", "python"),
                     Path.Combine(AppContext.BaseDirectory, "offline", "python"),
                 })
        {
            if (File.Exists(PythonExe) || !File.Exists(Path.Combine(bundled, "python.exe"))) continue;
            _log?.Invoke("检测到随包分发的离线运行时，直接使用：" + bundled);
            progress?.Report(new ProgressReport { Stage = "使用内置运行时", Percent = 100 });
            CopyDirectory(bundled, _pythonRoot);
            if (File.Exists(Path.Combine(bundled, "env.version")))
                File.Copy(Path.Combine(bundled, "env.version"), MarkerFile, overwrite: true);
            return true;
        }

        // 2) 下载 embeddable 发行版
        // 注意：离线包里可能已经带了 python 目录，但 wheel 还没装；
        // 这时不该再下载一遍 Python，直接复用现成的。
        var localRuntime = LocalWheelDirs()
            .Select(d => Path.Combine(Path.GetDirectoryName(d)!, "python"))
            .FirstOrDefault(p => File.Exists(Path.Combine(p, "python.exe")));
        if (!File.Exists(PythonExe) && localRuntime is not null)
        {
            _log?.Invoke("离线包内含 Python 运行时，跳过下载：" + localRuntime);
            CopyDirectory(localRuntime, _pythonRoot);
        }

        if (!File.Exists(PythonExe))
        {
            progress?.Report(new ProgressReport { Stage = "下载 Python 运行时", Percent = 3 });
            await DownloadWithFallbackAsync(
                RuntimeMirrors.PythonAll.Select(m => string.Format(m.Pattern, _settings.PythonVersion)),
                _pythonRoot,
                p => progress?.Report(new ProgressReport { Stage = "下载 Python 运行时", Percent = 3 + p * 0.35 }), ct);

            EnableSitePackages();
        }

        // 3) 装 pip
        progress?.Report(new ProgressReport { Stage = "安装 pip", Percent = 40 });
        await EnsurePipAsync(ct);

        // 4) 装 PyTorch（按硬件档位选轮子源和版本）
        // 注意：PipArgs() 已包含 "install"，这里不能再加，
        // 否则 pip 会把多余的 "install" 当成包名，报
        // "No matching distribution found for install"
        //
        // 版本必须与 CUDA 档位严格对应，否则 pip 找不到轮子：
        //   torch 2.6+ 只发布 cu124/cu126 轮子，cu121 源里最高只有 2.5.1
        //   （报错 "No matching distribution found for torch==2.6.*" 就是这个原因）
        progress?.Report(new ProgressReport { Stage = "安装 PyTorch（约 2.5GB，首次较慢）", Percent = 50 });
        var cudaTag = profile switch
        {
            ComputeProfile.Cuda118 => "cu118",
            ComputeProfile.Cuda121 => "cu121",
            ComputeProfile.Cuda124 => "cu124",
            _ => "cpu",
        };
        // 优先走国内镜像（默认南大 15.8MB/s，官方源仅 0.7MB/s）；
        // 用户在设置里清空 TorchIndexPattern 则回退到 TorchIndexBase
        var torchIndex = string.IsNullOrWhiteSpace(_settings.TorchIndexPattern)
            ? GpuDetector.TorchIndexUrl(profile, _settings.TorchIndexBase)
            : string.Format(_settings.TorchIndexPattern, cudaTag);
        var (torchVer, tvVer) = TorchVersions(profile);
        var pipBase = PipArgs();
        var torchArgs = pipBase.Concat(new[]
        {
            $"torch=={torchVer}", $"torchvision=={tvVer}",
            "--index-url", torchIndex,
        }).ToList();

        // 镜像没同步到指定版本、或网络被拦截时，自动退一步重试：
        //   1) 先试南大；2) 再试交大；3) 最后回官方源
        // 之前只配了一个源，镜像缺版本就直接失败，客户只会看到一句
        // "No matching distribution found"，根本不知道能换源。
        var torchOk = false;

        // 4a) 优先用本地 wheel：用户手动下好的 whl 目录，或随包分发的 wheels 目录。
        //     这一条必须排在联网之前——国内 2.5GB 联网下载本身就是最大痛点，
        //     只要能本地拿到就绝不走网络。
        var localDirs = LocalWheelDirs();
        foreach (var dir in localDirs)
        {
            if (!HasTorchWheel(dir)) continue;
            _log?.Invoke("检测到本地 wheel 目录，跳过下载直接安装：" + dir);
            progress?.Report(new ProgressReport { Stage = "从本地 wheel 安装 PyTorch", Percent = 50 });
            await InstallLocalWheelsAsync(dir, ct, p =>
                progress?.Report(new ProgressReport { Stage = "从本地 wheel 安装 PyTorch", Percent = 50 + p * 0.3 }));
            torchOk = true;
            break;
        }

        // 4b) 没有本地 wheel 才联网，失败自动换源
        if (!torchOk)
        foreach (var index in TorchIndexCandidates(cudaTag, torchIndex))
        {
            var args = torchArgs.ToList();
            args[args.IndexOf("--index-url") + 1] = index;
            try
            {
                await RunPipAsync(args, ct, p =>
                    progress?.Report(new ProgressReport { Stage = "安装 PyTorch", Percent = 50 + p * 0.3 }));
                torchOk = true;
                break;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                _log?.Invoke($"PyTorch 从 {index} 安装失败：{ex.Message}");
                _log?.Invoke("切换下一个下载源重试…");
            }
        }
        if (!torchOk)
            throw new InvalidOperationException(
                "PyTorch 安装失败：所有下载源都不可用。\n\n" +
                "最快的解决办法：在能上网的电脑上用浏览器下载 torch 的 whl 文件（2.3GB 那种），\n" +
                "放到一个文件夹里，然后在「设置 → 安装 / 修复运行环境」选「从本地 whl 安装」。");

        // 5) 装其余依赖
        progress?.Report(new ProgressReport { Stage = "安装训练依赖", Percent = 82 });
        var req = Path.Combine(AppContext.BaseDirectory, "resources", "python", "requirements.txt");
        if (File.Exists(req))
        {
            await RunPipAsync(pipBase.Concat(new[] { "-r", req }),
                ct, p => progress?.Report(new ProgressReport { Stage = "安装训练依赖", Percent = 82 + p * 0.15 }));
        }
        else
        {
            await RunPipAsync(pipBase.Concat(new[] { "ultralytics" }), ct);
        }

        // 6) 权重已在流程开头补过（EnsureBaseWeightsAsync），这里不再重复

        await File.WriteAllTextAsync(MarkerFile, $"{EnvSignature}|{profile}", ct);
        progress?.Report(new ProgressReport { Stage = "环境准备完成", Percent = 100 });
        return true;
    }

    /// <summary>GitHub 直链在国内基本不通，前两个是实测可用的加速代理。</summary>
    public static readonly string[] WeightMirrorPatterns =
    {
        "https://gh-proxy.com/https://github.com/ultralytics/assets/releases/download/v8.3.0/{0}",
        "https://ghproxy.net/https://github.com/ultralytics/assets/releases/download/v8.3.0/{0}",
        "https://github.com/ultralytics/assets/releases/download/v8.3.0/{0}",
    };

    /// <summary>确保指定预训练权重存在于 AppPaths.WeightsDir，返回本地路径。</summary>
    public async Task<string> EnsureBaseWeightsAsync(string fileName, CancellationToken ct)
    {
        AppPaths.EnsureCreated();
        var dest = Path.Combine(AppPaths.WeightsDir, fileName);

        // exe 旁边若带了权重（发布包内置），直接复用，连 5MB 都不用下
        var bundled = Path.Combine(AppContext.BaseDirectory, "resources", "weights", fileName);
        if (!File.Exists(dest))
        {
            if (File.Exists(bundled))
            {
                File.Copy(bundled, dest);
                _log?.Invoke($"使用随包分发的权重：{dest}");
            }
            else
            {
                await DownloadDirectAsync(
                    WeightMirrorPatterns.Select(p => string.Format(p, fileName)), dest, ct);
                _log?.Invoke($"预训练权重已下载：{dest}");
            }
        }
        return dest;
    }

    /// <summary>
    /// embeddable 版默认把 site-packages 关掉了，且 _pth 里没有 Lib\site-packages。
    /// 不打开这个开关，pip 装的东西 import 不到——这是新手最容易踩的坑。
    /// </summary>
    private void EnableSitePackages()
    {
        var pth = Directory.GetFiles(_pythonRoot, "python*._pth").FirstOrDefault();
        if (pth is null)
        {
            pth = Path.Combine(_pythonRoot, "python311._pth");
            File.WriteAllText(pth, "python311.zip\r\n.\r\n\r\n# Uncomment to run site.main() automatically\r\nimport site\r\n");
            return;
        }

        var lines = File.ReadAllLines(pth).ToList();
        var zipLine = lines.FirstOrDefault(l => l.TrimEnd().EndsWith(".zip", StringComparison.OrdinalIgnoreCase));
        // 必须把 zip 放第一行，否则标准库都找不到
        if (zipLine is not null)
        {
            if (!lines.Remove(zipLine)) { /* 未找到 */ }
            lines.Insert(0, zipLine);
        }
        if (!lines.Any(l => l.Trim() == "import site")) lines.Add("import site");
        if (!lines.Any(l => l.Trim() == "Lib\\site-packages")) lines.Insert(1, "Lib\\site-packages");
        File.WriteAllLines(pth, lines.Distinct(StringComparer.OrdinalIgnoreCase));
    }

    /// <summary>
    /// 可能存放本地 wheel 的目录，按优先级排列：
    ///   1. 用户在设置里指定的目录（手动下载的 whl，或用「从本地 whl 安装」选的）
    ///   2. exe 同目录的 offline\wheels\（make-offline.bat 生成的离线包）
    ///   3. exe 同目录的 wheels\（简易形态，手动扔进去即可）
    /// 只要目录里能找到 torch 的 whl，就认为这是一套完整的离线包。
    /// </summary>
    public IReadOnlyList<string> LocalWheelDirs()
        => LocalWheelDirs(_settings, AppContext.BaseDirectory);

    /// <summary>
    /// baseDir 显式传入而不是直接读 AppContext.BaseDirectory，是为了能测：
    /// 离线包探测错一个层级，客户的离线包放进去也不会生效，且完全没有任何报错。
    /// </summary>
    public static IReadOnlyList<string> LocalWheelDirs(AppSettings settings, string baseDir)
    {
        var list = new List<string>();
        if (!string.IsNullOrWhiteSpace(settings.LocalWheelDir))
            list.Add(settings.LocalWheelDir!);
        list.Add(Path.Combine(baseDir, "offline", "wheels"));
        list.Add(Path.Combine(baseDir, "wheels"));
        return list.Where(Directory.Exists).ToList();
    }

    /// <summary>目录里是否有 torch 的 wheel（判定"这是一套可用离线包"的最低标准）。</summary>
    public static bool HasTorchWheel(string dir)
    {
        try
        {
            return Directory.EnumerateFiles(dir, "torch-*.whl", SearchOption.TopDirectoryOnly).Any();
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// 从本地目录装 wheel。核心是 --no-index：完全断网，绝不访问 PyPI，
    /// 否则 pip 会因为没有 --find-links 里找不到的依赖而卡在网络上重试很久。
    /// 用 --find-links 指向目录后，pip 会自己解决依赖顺序，不需要按顺序装。
    ///
    /// --no-deps 是有意不加的：torch 依赖 filelock/sympy/networkx/jinja2 等，
    /// 离线包里应该一起提供；缺了就直接报错比装个半残的 torch 更好。
    /// </summary>
    public async Task InstallLocalWheelsAsync(string dir, CancellationToken ct, Action<double>? progress = null)
    {
        if (!File.Exists(PythonExe))
            throw new InvalidOperationException("运行环境尚未准备好，无法安装本地 wheel。");

        var args = new List<string>
        {
            "-m", "pip", "install",
            "--no-index",                    // 彻底断网，只认本地目录
            "--find-links", dir,
            "--no-warn-script-location",
            "--disable-pip-version-check",
        };

        // 指定具体包名而不是交给 pip 猜：目录里可能同时有 cpu 和 cu121 两套 whl，
        // pip 会挑版本号最高的，但用户想要的往往是特定 CUDA 档位那套。
        if (HasTorchWheel(dir))
        {
            args.Add("torch");
            if (Directory.EnumerateFiles(dir, "torchvision-*.whl").Any()) args.Add("torchvision");
        }
        args.Add("ultralytics");

        await RunPipAsync(args, ct, progress);
        _log?.Invoke($"已从 {dir} 安装完成。");
    }

    /// <summary>
    /// PyTorch 下载源回退序列：用户选的源打头，之后依次是南大 → 交大 → 官方。
    /// 去重后返回，避免用户已经选了南大时重复尝试同一个地址。
    /// </summary>
    private static IEnumerable<string> TorchIndexCandidates(string cudaTag, string preferred)
    {
        var list = new List<string> { preferred };
        list.Add(string.Format(TorchMirrors.Nju, cudaTag));
        list.Add(string.Format(TorchMirrors.Sjtu, cudaTag));
        list.Add(string.Format(TorchMirrors.Official, cudaTag));
        return list.Distinct(StringComparer.OrdinalIgnoreCase);
    }

    /// <summary>按顺序尝试多个下载地址，前一个失败了自动换下一个。</summary>
    private async Task DownloadWithFallbackAsync(
        IEnumerable<string> urls, string? targetDir, Action<double>? progress, CancellationToken ct)
    {
        Exception? last = null;
        foreach (var url in urls)
        {
            try
            {
                await DownloadAndExtractAsync(url, targetDir, progress, ct);
                return;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                last = ex;
                _log?.Invoke($"下载失败（{new Uri(url).Host}）：{ex.Message}，换下一个源重试…");
            }
        }
        throw new InvalidOperationException("运行时下载失败：所有下载源均不可用。" + last?.Message, last);
    }

    /// <summary>按顺序尝试多个直链下载地址，前一个失败自动换下一个。</summary>
    private async Task DownloadDirectAsync(IEnumerable<string> urls, string destFile, CancellationToken ct)
    {
        Exception? last = null;
        foreach (var url in urls)
        {
            try
            {
                await DownloadAndExtractAsync(url, null, null, ct, directFile: destFile);
                return;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                last = ex;
                _log?.Invoke($"下载失败（{new Uri(url).Host}）：{ex.Message}，换下一个源重试…");
            }
        }
        throw new InvalidOperationException("下载失败：所有下载源均不可用。" + last?.Message, last);
    }

    private async Task EnsurePipAsync(CancellationToken ct)
    {
        var runner = new ProcessRunner();
        runner.Output += l => _log?.Invoke(l);
        var code = await runner.RunAsync(PythonExe, new[] { "-m", "pip", "--version" },
            _pythonRoot, null, ct, TimeSpan.FromSeconds(60));
        if (code == 0) return;

        var getPip = Path.Combine(_pythonRoot, "get-pip.py");
        // get-pip.py 只有 2MB，但 bootstrap.pypa.io 在国内经常超时，先走阿里云镜像
        await DownloadDirectAsync(
            new[] { RuntimeMirrors.GetPipAliyun, RuntimeMirrors.GetPipOfficial }, getPip, ct);
        var r2 = new ProcessRunner();
        r2.Output += l => _log?.Invoke(l);
        var rc = await r2.RunAsync(PythonExe, new[] { getPip }, _pythonRoot, null, ct, TimeSpan.FromMinutes(3));
        if (rc != 0) throw new InvalidOperationException("pip 安装失败：" + string.Join('\n', r2.RecentLines.TakeLast(20)));
    }

    /// <summary>
    /// 各 CUDA 档位可用的 torch / torchvision 版本组合。
    /// 对照表（轮子是否存在于对应 index）：
    ///   cu118 → torch ≤ 2.5.1（2.6 起官方不再发 cu118）
    ///   cu121 → torch ≤ 2.5.1（2.6 起官方不再发 cu121）
    ///   cu124 → torch 2.6.x
    ///   cpu   → 全版本可用
    /// 升级 torch 版本时必须核对这个表，并在真机跑一遍安装。
    /// </summary>
    private static (string Torch, string TorchVision) TorchVersions(ComputeProfile profile) => profile switch
    {
        ComputeProfile.Cuda118 => ("2.5.1", "0.20.1"),
        ComputeProfile.Cuda121 => ("2.5.1", "0.20.1"),
        ComputeProfile.Cuda124 => ("2.6.*", "0.21.*"),
        _ => ("2.6.*", "0.21.*"),
    };

    private List<string> PipArgs()
    {
        var args = new List<string> { "-m", "pip", "install", "--no-warn-script-location", "--disable-pip-version-check" };
        if (!string.IsNullOrWhiteSpace(_settings.PipIndexUrl))
        {
            args.Add("-i");
            args.Add(_settings.PipIndexUrl);
        }
        return args;
    }

    /// <summary>pip 的进度在 stdout 里以 "xx%" 出现，解析出来喂给 UI 进度条。</summary>
    private async Task RunPipAsync(
        IEnumerable<string> args, CancellationToken ct, Action<double>? progress = null)
    {
        var runner = new ProcessRunner();
        runner.Output += line =>
        {
            _log?.Invoke(line);
            var pct = ParsePercent(line);
            if (pct.HasValue) progress?.Invoke(pct.Value / 100.0);
        };
        runner.ErrorOutput += _log;

        var code = await runner.RunAsync(PythonExe, args, _pythonRoot, null, ct);
        if (code != 0)
            throw new InvalidOperationException(
                "依赖安装失败（pip 退出码 " + code + "）：" + string.Join('\n', runner.RecentLines.TakeLast(25)));
        progress?.Invoke(1.0);
    }

    private static double? ParsePercent(string line)
    {
        var idx = line.IndexOf('%');
        if (idx <= 0) return null;
        int start = idx - 1;
        while (start >= 0 && (char.IsDigit(line[start]) || line[start] == '.')) start--;
        var token = line[(start + 1)..idx];
        return double.TryParse(token, out var v) ? v : null;
    }

    private static async Task DownloadAndExtractAsync(
        string url, string? targetDir, Action<double>? progress, CancellationToken ct, string? directFile = null)
    {
        using var http = new HttpClient { Timeout = TimeSpan.FromMinutes(30) };
        using var resp = await http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct);
        resp.EnsureSuccessStatusCode();
        var total = resp.Content.Headers.ContentLength ?? -1;

        var temp = directFile ?? Path.Combine(Path.GetTempPath(), Path.GetRandomFileName() + ".zip");
        await using (var fs = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None, 81920, true))
        await using (var src = await resp.Content.ReadAsStreamAsync(ct))
        {
            var buffer = new byte[81920];
            long read = 0;
            int n;
            while ((n = await src.ReadAsync(buffer, ct)) > 0)
            {
                await fs.WriteAsync(buffer.AsMemory(0, n), ct);
                read += n;
                if (total > 0) progress?.Invoke(read / (double)total);
            }
        }

        if (targetDir is null) return;
        Directory.CreateDirectory(targetDir);
        // embeddable zip 解压要求目录为空，先清掉半成品
        foreach (var f in Directory.GetFiles(targetDir)) File.Delete(f);
        ZipFile.ExtractToDirectory(temp, targetDir, overwriteFiles: true);
        File.Delete(temp);
    }

    private static void CopyDirectory(string source, string target)
    {
        Directory.CreateDirectory(target);
        foreach (var dir in Directory.GetDirectories(source, "*", SearchOption.AllDirectories))
            Directory.CreateDirectory(dir.Replace(source, target));
        foreach (var file in Directory.GetFiles(source, "*", SearchOption.AllDirectories))
            File.Copy(file, file.Replace(source, target), overwrite: true);
    }

    /// <summary>启动训练的 python 进程时需要的环境变量。cv2/torch 缺了这几个会报 DLL 错误。</summary>
    public Dictionary<string, string> BuildEnvironment()
    {
        var sitePackages = Path.Combine(_pythonRoot, "Lib", "site-packages");
        var pyDlls = Path.Combine(sitePackages, "torch", "lib");
        var cv2Dir = Path.Combine(sitePackages, "cv2");

        var extra = new[] { _pythonRoot, sitePackages, pyDlls, cv2Dir }
            .Where(Directory.Exists);

        return new Dictionary<string, string>
        {
            ["PATH"] = string.Join(';', extra.Append(Environment.GetEnvironmentVariable("PATH") ?? "")),
            ["PYTHONPATH"] = sitePackages,
            ["PYTHONHOME"] = _pythonRoot,
            ["PYTHONUTF8"] = "1",
            ["PYTHONIOENCODING"] = "utf-8",
            // 关掉 ultralytics 的联网检查与遥测：客户内网机器会卡在这里超时
            ["YOLO_OFFLINE"] = "1",
            ["ULTRALYTICS_OFFLINE"] = "1",
            ["YOLO_VERBOSE"] = "true",
            ["MPLCONFIGDIR"] = Path.Combine(AppPaths.DataRoot, "mpl"),
        };
    }
}
