using System.Runtime.InteropServices;

namespace VisionTrainer.Core;

public sealed record GpuInfo(string Name, int MemoryMb, string DriverVersion)
{
    public override string ToString() => $"{Name} ({MemoryMb} MB)";
}

/// <summary>
/// 通过 nvidia-smi 检测显卡。之所以不用 WMI 查 Win32_VideoController：
/// 它拿不到 CUDA 驱动版本，也无法区分集显/独显是否可用。
/// </summary>
public static class GpuDetector
{
    public static IReadOnlyList<GpuInfo> Detect()
    {
        var list = new List<GpuInfo>();
        if (!OperatingSystem.IsWindows()) return list;

        var smi = LocateNvSmi();
        if (smi is null) return list;

        try
        {
            var psi = new System.Diagnostics.ProcessStartInfo(smi)
            {
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
            };
            psi.ArgumentList.Add("--query-gpu=name,memory.total,driver_version");
            psi.ArgumentList.Add("--format=csv,noheader,nounits");

            using var p = System.Diagnostics.Process.Start(psi);
            if (p is null) return list;
            var output = p.StandardOutput.ReadToEnd();
            p.WaitForExit(5000);

            foreach (var raw in output.Split('\n', StringSplitOptions.RemoveEmptyEntries))
            {
                var parts = raw.Split(',', StringSplitOptions.TrimEntries);
                if (parts.Length < 3) continue;
                if (!int.TryParse(parts[1], out var mem)) mem = 0;
                list.Add(new GpuInfo(parts[0], mem, parts[2]));
            }
        }
        catch
        {
            // 无驱动或无权限，视为无 GPU
        }
        return list;
    }

    /// <summary>根据检测结果选择要安装的 PyTorch 轮子档位。</summary>
    public static ComputeProfile RecommendProfile(IReadOnlyList<GpuInfo> gpus)
    {
        if (gpus.Count == 0) return ComputeProfile.Cpu;
        // cu121 / cu124 向下兼容老驱动；显存过小（<2GB）训练基本无意义，退回 CPU 反而更稳定
        var best = gpus.OrderByDescending(g => g.MemoryMb).First();
        if (best.MemoryMb < 2048) return ComputeProfile.Cpu;
        return ComputeProfile.Cuda121;
    }

    public static string TorchIndexUrl(ComputeProfile profile, string baseUrl) => profile switch
    {
        ComputeProfile.Cuda118 => $"{baseUrl}/cu118",
        ComputeProfile.Cuda121 => $"{baseUrl}/cu121",
        ComputeProfile.Cuda124 => $"{baseUrl}/cu124",
        _ => $"{baseUrl}/cpu",
    };

    public static string Describe(ComputeProfile profile) => profile switch
    {
        ComputeProfile.Cuda118 => "NVIDIA GPU · CUDA 11.8",
        ComputeProfile.Cuda121 => "NVIDIA GPU · CUDA 12.1",
        ComputeProfile.Cuda124 => "NVIDIA GPU · CUDA 12.4",
        _ => "CPU 模式（速度较慢）",
    };

    private static string? LocateNvSmi()
    {
        var direct = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "nvidia-smi.exe");
        if (File.Exists(direct)) return direct;

        const string fallback = @"C:\Program Files\NVIDIA Corporation\NVSMI\nvidia-smi.exe";
        if (File.Exists(fallback)) return fallback;

        var pathEnv = Environment.GetEnvironmentVariable("PATH") ?? "";
        foreach (var dir in pathEnv.Split(Path.PathSeparator))
        {
            if (string.IsNullOrWhiteSpace(dir)) continue;
            var candidate = Path.Combine(dir.Trim(), "nvidia-smi.exe");
            if (File.Exists(candidate)) return candidate;
        }
        return null;
    }
}

/// <summary>
/// 系统信息采集，用于生成"环境诊断报告"，让售后不用远程也能判断故障原因。
/// </summary>
public static class SystemProbe
{
    public static string Describe()
    {
        var sb = new System.Text.StringBuilder();
        sb.AppendLine($"OS           : {RuntimeInformation.OSDescription}");
        sb.AppendLine($"Arch         : {RuntimeInformation.OSArchitecture}");
        sb.AppendLine($"CLR          : {RuntimeInformation.FrameworkDescription}");
        sb.AppendLine($"CPU          : {Environment.ProcessorCount} logical cores");
        sb.AppendLine($"RAM          : {GC.GetGCMemoryInfo().TotalAvailableMemoryBytes / 1024 / 1024} MB");
        sb.AppendLine($"DataRoot     : {AppPaths.DataRoot}");
        sb.AppendLine($"Portable     : {AppPaths.IsPortable}");
        sb.AppendLine($"PythonExe    : {AppPaths.PythonExe} (exists={File.Exists(AppPaths.PythonExe)})");
        var gpus = GpuDetector.Detect();
        sb.AppendLine($"GPU          : {(gpus.Count == 0 ? "none detected" : string.Join("; ", gpus))}");
        return sb.ToString();
    }
}
