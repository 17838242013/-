using System.Text.Json.Serialization;

namespace VisionTrainer.Core;

/// <summary>任务类型。新增任务类型只需在此枚举 + 注册一个训练流程实现。</summary>
public enum TaskKind
{
    Detection = 0,
    Classification = 1,
    Ocr = 2,
    LlmFinetune = 3,
}

/// <summary>硬件档位，决定安装哪个 PyTorch 轮子包。</summary>
public enum ComputeProfile
{
    Cpu = 0,
    Cuda118 = 1,
    Cuda121 = 2,
    Cuda124 = 3,
}

public sealed class TrainingOptions
{
    public TaskKind Task { get; set; } = TaskKind.Detection;

    /// <summary>基础模型标识，例如 yolo11n / yolo11s。</summary>
    public string BaseModel { get; set; } = "yolo11n";

    public int Epochs { get; set; } = 100;
    public int BatchSize { get; set; } = 16;
    public int ImageSize { get; set; } = 640;
    public double LearningRate { get; set; } = 0.01;
    public int Workers { get; set; } = 0;
    public int Patience { get; set; } = 30;
    /// <summary>抽出来做验证集的比例，0 表示沿用数据集自带划分。</summary>
    public double ValSplit { get; set; } = 0.2;

    public bool UseAugmentation { get; set; } = true;
    public bool UsePretrained { get; set; } = true;
    public bool Resume { get; set; } = false;
    /// <summary>可断点续训的随机种子，0 表示不固定。</summary>
    public int Seed { get; set; } = 0;

    /// <summary>用户自定义的超参覆盖，透传给训练脚本（key 为 ultralytics 参数名）。</summary>
    public Dictionary<string, string> ExtraArgs { get; set; } = new();
}

public sealed class ClassDef
{
    public int Index { get; set; }
    public string Name { get; set; } = "";
    public string ColorHex { get; set; } = "#FF3B30";
}

public sealed class DatasetSummary
{
    public string RootPath { get; set; } = "";
    public TaskKind Task { get; set; }
    /// <summary>DataLayout 的字符串标识，例如 "YoloDetection" / "ImageFolder"。</summary>
    public string Layout { get; set; } = "";
    public int TrainImages { get; set; }
    public int ValImages { get; set; }
    public List<ClassDef> Classes { get; set; } = new();
    /// <summary>非致命问题，展示给用户但不阻止训练。</summary>
    public List<string> Warnings { get; set; } = new();
    /// <summary>致命问题，阻止训练。</summary>
    public List<string> Errors { get; set; } = new();

    [JsonIgnore]
    public bool IsUsable => Errors.Count == 0 && TrainImages > 0;
}

public enum JobState
{
    Queued = 0,
    Preparing = 1,
    Running = 2,
    Succeeded = 3,
    Failed = 4,
    Canceled = 5,
}

/// <summary>一个 Epoch 级别的指标快照，用于实时曲线。</summary>
public sealed class EpochMetrics
{
    public int Epoch { get; set; }
    /// <summary>总轮数，用于画进度；未知时为 0。</summary>
    public int TotalEpochs { get; set; }
    public double? BoxLoss { get; set; }
    public double? ClsLoss { get; set; }
    public double? DflLoss { get; set; }
    /// <summary>mAP50-95，目标检测主指标。</summary>
    public double? Map50_95 { get; set; }
    public double? Map50 { get; set; }
    /// <summary>分类任务的 top-1 准确率。</summary>
    public double? Top1 { get; set; }
    public double? Precision { get; set; }
    public double? Recall { get; set; }
    public double Lr { get; set; }
    public double ElapsedSeconds { get; set; }
}

public sealed class ExportedModel
{
    public string Name { get; set; } = "";
    public string Format { get; set; } = "";
    public string FilePath { get; set; } = "";
    public long SizeBytes { get; set; }
}

public sealed class TrainingJob
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime? FinishedAt { get; set; }
    public TrainingOptions Options { get; set; } = new();
    public DatasetSummary? Dataset { get; set; }
    public ComputeProfile Profile { get; set; }

    public JobState State { get; set; } = JobState.Queued;
    public string? ErrorMessage { get; set; }
    public string WorkDirectory { get; set; } = "";

    public List<EpochMetrics> History { get; set; } = new();
    public EpochMetrics? Best { get; set; }
    public List<ExportedModel> Exports { get; set; } = new();

    [JsonIgnore]
    public double Progress
    {
        get
        {
            var total = History.Count > 0 ? History[^1].TotalEpochs : 0;
            if (total <= 0) return 0;
            return Math.Clamp(History.Count / (double)total, 0, 1);
        }
    }
}
