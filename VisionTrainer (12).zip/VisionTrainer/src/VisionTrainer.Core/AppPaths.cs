using System.Text.Json;
using System.Text.Json.Serialization;

namespace VisionTrainer.Core;

public static class AppPaths
{
    /// <summary>便携模式：exe 同目录下有 portable.txt 时，所有数据都写在程序目录下，U 盘可带走。</summary>
    public static bool IsPortable { get; } =
        File.Exists(Path.Combine(AppContext.BaseDirectory, "portable.txt"));

    public static string DataRoot { get; } = IsPortable
        ? Path.Combine(AppContext.BaseDirectory, "data")
        : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "VisionTrainer");

    /// <summary>Python 运行时（嵌入式发行版）所在目录。</summary>
    public static string PythonRoot => Path.Combine(DataRoot, "python");
    public static string PythonExe => Path.Combine(PythonRoot, "python.exe");

    /// <summary>每条训练任务的产物目录。</summary>
    public static string ProjectsRoot => Path.Combine(DataRoot, "projects");
    /// <summary>标注工程目录。</summary>
    public static string AnnotationRoot => Path.Combine(DataRoot, "annotations");
    public static string LogsRoot => Path.Combine(DataRoot, "logs");
    public static string SettingsFile => Path.Combine(DataRoot, "settings.json");
    /// <summary>
    /// 预训练权重（yolo11n.pt 等）。装环境时自动下载，训练/预标注共用。
    /// 放 DataRoot 而不是 exe 目录：publish 目录可能没写权限。
    /// </summary>
    public static string WeightsDir => Path.Combine(DataRoot, "weights");

    public static void EnsureCreated()
    {
        Directory.CreateDirectory(DataRoot);
        Directory.CreateDirectory(ProjectsRoot);
        Directory.CreateDirectory(AnnotationRoot);
        Directory.CreateDirectory(LogsRoot);
        Directory.CreateDirectory(WeightsDir);
    }

    public static string NewProjectDir(string jobName)
    {
        var safe = string.Concat(jobName.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
        var dir = Path.Combine(ProjectsRoot, $"{DateTime.Now:yyyyMMdd_HHmmss}_{safe}");
        Directory.CreateDirectory(dir);
        return dir;
    }
}

/// <summary>
/// pip（PyPI）镜像候选。装 ultralytics 及其依赖时用，量不大但源选错照样卡住。
/// 实测清华与阿里云都在 10MB/s 以上，官方 pypi.org 在国内常低于 100KB/s。
/// </summary>
public static class PipMirrors
{
    public const string Tsinghua = "https://pypi.tuna.tsinghua.edu.cn/simple";
    public const string Aliyun = "https://mirrors.aliyun.com/pypi/simple";
    public const string Ustc = "https://mirrors.ustc.edu.cn/pypi/simple";
    public const string Official = "https://pypi.org/simple";

    public static IReadOnlyList<(string Name, string Url)> All { get; } = new[]
    {
        ("清华（推荐）", Tsinghua),
        ("阿里云", Aliyun),
        ("中科大", Ustc),
        ("官方源（慢）", Official),
    };
}

/// <summary>
/// 除 PyTorch 之外、首次安装还要下载的两样东西，官方域名在国内同样很慢。
/// {0} 在 Python 上会替换为版本号（如 3.11.9）。
/// </summary>
public static class RuntimeMirrors
{
    /// <summary>Python embeddable 压缩包。华为云同步最及时，实测比 python.org 快一个数量级。</summary>
    public const string PythonNju = "https://mirrors.nju.edu.cn/python/{0}/python-{0}-embed-amd64.zip";
    public const string PythonHuawei = "https://mirrors.huaweicloud.com/python/{0}/python-{0}-embed-amd64.zip";
    public const string PythonOfficial = "https://www.python.org/ftp/python/{0}/python-{0}-embed-amd64.zip";

    public static IReadOnlyList<(string Name, string Pattern)> PythonAll { get; } = new[]
    {
        ("南京大学（推荐）", PythonNju),
        ("华为云", PythonHuawei),
        ("官方源（慢）", PythonOfficial),
    };

    /// <summary>get-pip.py 很小（约 2MB），但仍走镜像避免超时。</summary>
    public const string GetPipAliyun = "https://mirrors.aliyun.com/pypi/get-pip.py";
    public const string GetPipOfficial = "https://bootstrap.pypa.io/get-pip.py";
}

/// <summary>
/// PyTorch 轮子镜像候选。{0} 占位 cu118/cu121/cu124/cpu。
///
/// 2026-10 实测（取 torch-2.5.1+cu121-cp311-win_amd64.whl 前 4MB，同一台机器）：
///   南大   15.8 MB/s   ← 默认，同步最及时
///   交大   12.6 MB/s
///   官方源  0.7 MB/s   （2.5GB 要下约 1 小时；国内实际常低到 0.2~0.3 MB/s）
///   阿里云 目录是网页版镜像站，pip 的 -i 用不了，已移除
///   清华   无此镜像（404，网上流传的说法是错的）
///
/// 注意：各镜像的 URL 结构不同，不能简单替换域名：
///   南大   /pytorch/whl/{0}          （文件平铺在 cuXXX 目录下，无 torch/ 子目录）
///   交大   /pytorch-wheels/{0}       （同上，平铺）
/// 目录页里既有相对路径也有指向 download-r2.pytorch.org 的绝对链接，
/// pip 解析时都能正确落到镜像站，不用特殊处理。
/// </summary>
public static class TorchMirrors
{
    public const string Nju = "https://mirrors.nju.edu.cn/pytorch/whl/{0}";
    public const string Sjtu = "https://mirror.sjtu.edu.cn/pytorch-wheels/{0}";
    /// <summary>官方源，速度慢但最稳，也是国内下不动时的唯一兜底。</summary>
    public const string Official = "https://download.pytorch.org/whl/{0}";

    public static IReadOnlyList<(string Name, string Pattern)> All { get; } = new[]
    {
        ("南京大学（推荐，约 16MB/s）", Nju),
        ("上海交大（约 13MB/s）", Sjtu),
        ("官方源（慢，约 0.7MB/s）", Official),
    };

    /// <summary>
    /// 把用户填的 TorchIndexBase（如 https://download.pytorch.org/whl）转成 {0} 模板。
    /// 设置页只让用户在预设里选，但老版本 settings.json 里可能只剩 Base，
    /// 升级后要能自动迁到镜像，否则用户会一直在慢源上打转。
    /// </summary>
    public static string? FromBase(string? baseUrl)
    {
        if (string.IsNullOrWhiteSpace(baseUrl)) return null;
        foreach (var (_, pattern) in All)
        {
            // 去掉 {0} 后比较前缀，兼容 http/https 与末尾斜杠差异
            var stem = pattern.Replace("/{0}", "");
            if (baseUrl.TrimEnd('/').Equals(stem, StringComparison.OrdinalIgnoreCase))
                return pattern;
        }
        // 用户自己填的企业私服：原样生成模板
        return baseUrl.TrimEnd('/') + "/{0}";
    }
}

public sealed class AppSettings
{    /// <summary>pip 镜像源，国内用户必须；留空走官方源。</summary>
    public string PipIndexUrl { get; set; } = "https://pypi.tuna.tsinghua.edu.cn/simple";
    public string TorchIndexBase { get; set; } = "https://download.pytorch.org/whl";
    /// <summary>
    /// PyTorch 轮子镜像，{0} 会被替换为 cu118/cu121/cu124/cpu。
    /// 默认南京大学镜像（实测 15.8MB/s，官方源 0.7MB/s），留空则回退到 TorchIndexBase。
    /// 备选见 TorchMirrors 常量。
    /// 旧配置里的官方源会被 SettingsStore.Load 自动迁到镜像，见 MigrateTorchMirror。
    /// </summary>
    public string TorchIndexPattern { get; set; } = TorchMirrors.Nju;

    /// <summary>
    /// 本地 wheel 目录。填了就用它离线安装（--no-index），完全不走网络。
    /// 这是国内环境下最可靠的安装方式：在能上网的机器上下好 whl 拷过来即可。
    /// 留空则自动探测 exe 同目录的 wheels\ 与 offline\wheels\。
    /// </summary>
    public string? LocalWheelDir { get; set; }

    /// <summary>
    /// 把历史遗留的官方源配置迁到国内镜像。
    /// 0.1.0 的缺省值是官方源，用户升级后哪怕代码改了默认值，读到的仍是旧 JSON。
    /// 只在 pattern 指向 download.pytorch.org 时才改，用户自填的私服 URL 原样保留。
    /// </summary>
    public void MigrateTorchMirror()
    {
        if (string.IsNullOrWhiteSpace(TorchIndexPattern)
            || TorchIndexPattern.Contains("download.pytorch.org", StringComparison.OrdinalIgnoreCase))
        {
            TorchIndexPattern = TorchMirrors.Nju;
        }
    }

    /// <summary>自动检测到的硬件档位，安装 PyTorch 时使用。</summary>
    public ComputeProfile Profile { get; set; } = ComputeProfile.Cpu;
    public string PythonVersion { get; set; } = "3.11.9";
    public bool GpuAutoDetectDone { get; set; }
    /// <summary>首次启动时是否已经问过用户训练码等设置。</summary>
    public bool FirstRunCompleted { get; set; }
    /// <summary>标注页的分布引导是否已看过。看过之后仍可通过「?」重看。</summary>
    public bool AnnotationGuideSeen { get; set; }
    /// <summary>最近打开的标注工程目录。</summary>
    public string? LastAnnotationProject { get; set; }
    /// <summary>验证页手动浏览过的模型路径，下次打开自动恢复。</summary>
    public string? LastVerifyModel { get; set; }
}

/// <summary>标注工程访问记录，用于在「打开已有工程」列表里按使用时间排序。</summary>
public static class AnnotationProjectRegistry
{
    private const string FileName = "annotation-recent.txt";

    public static void Touch(string rootPath)
    {
        try
        {
            AppPaths.EnsureCreated();
            var file = Path.Combine(AppPaths.DataRoot, FileName);
            var lines = File.Exists(file) ? File.ReadAllLines(file).ToList() : new List<string>();
            lines.RemoveAll(l => string.Equals(l, rootPath, StringComparison.OrdinalIgnoreCase));
            lines.Insert(0, rootPath);
            File.WriteAllLines(file, lines.Take(20));
        }
        catch
        {
            // 记录失败不影响主流程
        }
    }

    public static IReadOnlyList<string> Recent()
    {
        try
        {
            var file = Path.Combine(AppPaths.DataRoot, FileName);
            if (!File.Exists(file)) return Array.Empty<string>();
            return File.ReadAllLines(file).Where(Directory.Exists).Take(20).ToArray();
        }
        catch
        {
            return Array.Empty<string>();
        }
    }
}

public static class SettingsStore
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() },
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    };

    public static JsonSerializerOptions Options => JsonOptions;

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(AppPaths.SettingsFile))
            {
                var json = File.ReadAllText(AppPaths.SettingsFile);
                var loaded = JsonSerializer.Deserialize<AppSettings>(json, JsonOptions) ?? new AppSettings();
                // 老版本 JSON 里存的是官方源，升级后自动迁到国内镜像，否则用户会一直慢
                loaded.MigrateTorchMirror();
                return loaded;
            }
        }
        catch
        {
            // 配置文件损坏不应导致程序无法启动
        }
        return new AppSettings();
    }

    public static void Save(AppSettings settings)
    {
        AppPaths.EnsureCreated();
        File.WriteAllText(AppPaths.SettingsFile, JsonSerializer.Serialize(settings, JsonOptions));
    }
}
