using System.Diagnostics;

namespace VisionTrainer.Core;

/// <summary>
/// 子进程封装。深度学习训练是长任务，必须：可取消、多路输出、超时可查。
/// 注意：不使用 Kill 之外的优雅关闭，因为 ultralytics 捕获 SIGTERM 行为不可靠。
/// </summary>
public sealed class ProcessRunner
{
    private readonly List<string> _recentLines = new();

    /// <summary>整个进程树被杀掉后触发，便于 UI 更新状态。</summary>
    public event Action<string>? Output;
    /// <summary>stderr 行。很多库把普通进度打到 stderr，不能当成错误。</summary>
    public event Action<string>? ErrorOutput;

    public int? ExitCode { get; private set; }

    public IReadOnlyList<string> RecentLines
    {
        get { lock (_recentLines) return _recentLines.ToArray(); }
    }

    public async Task<int> RunAsync(
        string fileName,
        IEnumerable<string> arguments,
        string workingDirectory,
        IDictionary<string, string>? environment,
        CancellationToken ct,
        TimeSpan? timeout = null)
    {
        var psi = new ProcessStartInfo(fileName)
        {
            WorkingDirectory = workingDirectory,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            RedirectStandardInput = true,
            UseShellExecute = false,
            CreateNoWindow = true,
            StandardOutputEncoding = System.Text.Encoding.UTF8,
            StandardErrorEncoding = System.Text.Encoding.UTF8,
        };
        foreach (var a in arguments) psi.ArgumentList.Add(a);
        psi.Environment["PYTHONUNBUFFERED"] = "1";
        psi.Environment["PYTHONIOENCODING"] = "utf-8";
        if (environment is not null)
            foreach (var kv in environment) psi.Environment[kv.Key] = kv.Value;

        using var process = new Process { StartInfo = psi, EnableRaisingEvents = true };
        process.OutputDataReceived += (_, e) => Append(e.Data, isError: false);
        process.ErrorDataReceived += (_, e) => Append(e.Data, isError: true);

        process.Start();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        // 关闭 stdin，某些库会等待输入
        try { process.StandardInput.Close(); } catch { /* ignore */ }

        using var timeoutCts = timeout.HasValue
            ? new CancellationTokenSource(timeout.Value)
            : new CancellationTokenSource();
        using var linked = CancellationTokenSource.CreateLinkedTokenSource(ct, timeoutCts.Token);

        try
        {
            await process.WaitForExitAsync(linked.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            KillTree(process);
            throw;
        }

        ExitCode = process.ExitCode;
        return process.ExitCode;
    }

    public static void KillTree(Process process)
    {
        try
        {
            if (!process.HasExited) process.Kill(entireProcessTree: true);
        }
        catch
        {
            // 进程可能已退出或权限不足，忽略
        }
    }

    private void Append(string? line, bool isError)
    {
        if (line is null) return;
        lock (_recentLines)
        {
            _recentLines.Add((isError ? "[stderr] " : "") + line);
            if (_recentLines.Count > 400) _recentLines.RemoveRange(0, 100);
        }
        if (isError) ErrorOutput?.Invoke(line);
        else Output?.Invoke(line);
    }
}
