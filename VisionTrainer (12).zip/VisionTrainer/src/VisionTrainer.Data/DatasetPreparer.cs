using System.Globalization;
using System.Text;
using VisionTrainer.Core;

namespace VisionTrainer.Data;

/// <summary>
/// 把各种来源的数据集统一转换成 YOLO 训练可直接消费的目录结构 + data.yaml。
/// 转换结果写到任务工作目录，绝不修改用户原始数据（很多客户的数据是不可再生的）。
/// </summary>
public sealed class DatasetPreparer
{
    private readonly Action<string>? _log;
    public DatasetPreparer(Action<string>? log = null) => _log = log;

    public sealed class Result
    {
        public string DataYamlPath { get; set; } = "";
        public int TrainImages { get; set; }
        public int ValImages { get; set; }
        public List<string> Notes { get; } = new();
    }

    /// <summary>
    /// 主入口。返回可直接传给 ultralytics 的 data.yaml 路径。
    /// </summary>
    public async Task<Result> PrepareAsync(
        DatasetSummary source,
        TrainingOptions options,
        string workDir,
        CancellationToken ct)
    {
        var result = new Result();
        var yoloRoot = Path.Combine(workDir, "dataset");
        Directory.CreateDirectory(yoloRoot);

        switch (source.Layout)
        {
            case nameof(DataLayout.YoloDetection):
                // 已经是 YOLO 结构：只生成 data.yaml 指向原目录，零拷贝，最快
                await WriteYamlFromExistingAsync(source, options, yoloRoot, result, ct);
                break;

            case nameof(DataLayout.ImageFolder):
                await ConvertImageFolderAsync(source, options, yoloRoot, result, ct);
                break;

            case nameof(DataLayout.CocoDetection):
                await ConvertCocoAsync(source, options, yoloRoot, result, ct);
                break;

            case nameof(DataLayout.VocDetection):
                await ConvertVocAsync(source, options, yoloRoot, result, ct);
                break;

            default:
                throw new InvalidOperationException($"不支持的数据集布局：{source.Layout}");
        }

        result.DataYamlPath = Path.Combine(yoloRoot, "data.yaml");
        return result;
    }

    // ---------------- YOLO 直通 ----------------
    private async Task WriteYamlFromExistingAsync(
        DatasetSummary source, TrainingOptions options, string yoloRoot, Result result, CancellationToken ct)
    {
        var root = source.RootPath;
        var trainDir = FindDir(root, "images", "train") ?? FindDir(root, "train", "images") ?? FindDir(root, "images") ?? root;
        var valDir = FindDir(root, "images", "val") ?? FindDir(root, "val", "images") ?? FindDir(root, "valid", "images");

        result.TrainImages = source.TrainImages > 0 ? source.TrainImages : CountImages(trainDir);

        if (valDir is null || CountImages(valDir) == 0)
        {
            // 没有验证集就按比例切分，切分用符号链接不现实（Windows 需管理员），改为生成 split 清单
            _log?.Invoke("未发现验证集，按比例从训练集切分。");
            valDir = await SplitTrainValAsync(root, trainDir, options.ValSplit, yoloRoot, result, ct);
        }
        else
        {
            result.ValImages = CountImages(valDir);
        }

        await WriteDataYamlAsync(yoloRoot, trainDir, valDir, source.Classes, ct);
    }

    private async Task<string> SplitTrainValAsync(
        string root, string trainDir, double valSplit, string yoloRoot, Result result, CancellationToken ct)
    {
        valSplit = Math.Clamp(valSplit <= 0 ? 0.2 : valSplit, 0.05, 0.5);
        var images = Directory.EnumerateFiles(trainDir, "*.*", SearchOption.TopDirectoryOnly)
            .Where(DatasetScanner.IsImage)
            .OrderBy(f => f, StringComparer.OrdinalIgnoreCase)
            .ToList();

        var valCount = Math.Max(1, (int)(images.Count * valSplit));
        // 固定步长抽取，保证每次切分结果一致（客户重跑训练不会因为数据集划分不同而指标跳变）
        var stride = Math.Max(1, images.Count / valCount);
        var trainList = Path.Combine(yoloRoot, "train.txt");
        var valList = Path.Combine(yoloRoot, "val.txt");

        await using (var tw = new StreamWriter(trainList, false, Encoding.UTF8))
        await using (var vw = new StreamWriter(valList, false, Encoding.UTF8))
        {
            for (int i = 0; i < images.Count; i++)
            {
                ct.ThrowIfCancellationRequested();
                if (i % stride == 0 && valCount-- > 0) await vw.WriteLineAsync(images[i]);
                else await tw.WriteLineAsync(images[i]);
            }
        }

        result.TrainImages = images.Count - (int)(images.Count * valSplit);
        result.ValImages = images.Count - result.TrainImages;
        result.Notes.Add($"训练集/验证集按 {1 - valSplit:P0}/{valSplit:P0} 自动切分。");
        return valList; // ultralytics 支持直接用 txt 清单作为 val 路径
    }

    // ---------------- 分类 ----------------
    private async Task ConvertImageFolderAsync(
        DatasetSummary source, TrainingOptions options, string yoloRoot, Result result, CancellationToken ct)
    {
        // ultralytics 的分类任务直接吃 ImageFolder 结构，不需要转换
        var trainDir = FindDir(source.RootPath, "train") ?? source.RootPath;
        var valDir = FindDir(source.RootPath, "valid") ?? FindDir(source.RootPath, "val");

        if (valDir is null)
        {
            _log?.Invoke("未发现验证集，按比例从训练集切分。");
            valDir = await SplitClassificationAsync(trainDir, yoloRoot, options.ValSplit, ct);
        }

        result.TrainImages = CountImages(trainDir);
        result.ValImages = CountImages(valDir);
        var yaml = Path.Combine(yoloRoot, "data.yaml");
        var sb = new StringBuilder();
        sb.AppendLine($"path: {yoloRoot.Replace('\\', '/')}");
        sb.AppendLine($"train: {trainDir.Replace('\\', '/')}");
        sb.AppendLine($"val: {valDir.Replace('\\', '/')}");
        sb.AppendLine($"nc: {source.Classes.Count}");
        sb.AppendLine("names:");
        foreach (var c in source.Classes.OrderBy(c => c.Index))
            sb.AppendLine($"  {c.Index}: \"{c.Name}\"");
        await File.WriteAllTextAsync(yaml, sb.ToString(), Encoding.UTF8, ct);
    }

    private async Task<string> SplitClassificationAsync(string trainDir, string yoloRoot, double valSplit, CancellationToken ct)
    {
        var valDir = Path.Combine(yoloRoot, "val");
        Directory.CreateDirectory(valDir);
        foreach (var classDir in Directory.GetDirectories(trainDir))
        {
            var name = Path.GetFileName(classDir);
            var target = Path.Combine(valDir, name);
            Directory.CreateDirectory(target);
            var images = Directory.EnumerateFiles(classDir, "*.*", SearchOption.TopDirectoryOnly)
                .Where(DatasetScanner.IsImage).OrderBy(f => f).ToList();
            var take = Math.Max(1, (int)(images.Count * valSplit));
            for (int i = 0; i < take; i++)
            {
                ct.ThrowIfCancellationRequested();
                var dest = Path.Combine(target, Path.GetFileName(images[i]));
                try { File.Copy(images[i], dest, overwrite: true); } catch { /* 重名或占用，跳过 */ }
            }
        }
        await Task.CompletedTask;
        return valDir;
    }

    // ---------------- COCO ----------------
    private async Task ConvertCocoAsync(
        DatasetSummary source, TrainingOptions options, string yoloRoot, Result result, CancellationToken ct)
    {
        var imgOut = Path.Combine(yoloRoot, "images");
        var lblOut = Path.Combine(yoloRoot, "labels");
        Directory.CreateDirectory(imgOut);
        Directory.CreateDirectory(lblOut);

        var jsonPath = new[]
            {
                Path.Combine(source.RootPath, "annotations.json"),
                Path.Combine(source.RootPath, "_annotations.coco.json"),
                Path.Combine(source.RootPath, "annotations", "instances_train.json"),
            }.First(File.Exists);

        var doc = System.Text.Json.JsonDocument.Parse(await File.ReadAllTextAsync(jsonPath, ct));
        var root = doc.RootElement;

        var idToIndex = new Dictionary<int, int>();
        var categories = root.GetProperty("categories").EnumerateArray().ToArray();
        for (int i = 0; i < categories.Length; i++)
            idToIndex[categories[i].GetProperty("id").GetInt32()] = i;

        var imageById = new Dictionary<int, (string file, int w, int h)>();
        foreach (var img in root.GetProperty("images").EnumerateArray())
        {
            imageById[img.GetProperty("id").GetInt32()] = (
                img.GetProperty("file_name").GetString() ?? "",
                img.GetProperty("width").GetInt32(),
                img.GetProperty("height").GetInt32());
        }

        var grouped = new Dictionary<int, List<string>>();
        foreach (var ann in root.GetProperty("annotations").EnumerateArray())
        {
            var imageId = ann.GetProperty("image_id").GetInt32();
            if (!imageById.TryGetValue(imageId, out var meta)) continue;
            var catId = ann.GetProperty("category_id").GetInt32();
            if (!idToIndex.TryGetValue(catId, out var cls)) continue;
            var bbox = ann.GetProperty("bbox");
            double x = bbox[0].GetDouble(), y = bbox[1].GetDouble();
            double w = bbox[2].GetDouble(), h = bbox[3].GetDouble();
            if (meta.w <= 0 || meta.h <= 0) continue;

            var cx = (x + w / 2) / meta.w;
            var cy = (y + h / 2) / meta.h;
            var nw = w / meta.w;
            var nh = h / meta.h;
            if (nw <= 0 || nh <= 0) continue;

            if (!grouped.TryGetValue(imageId, out var lines)) grouped[imageId] = lines = new List<string>();
            lines.Add(string.Create(CultureInfo.InvariantCulture,
                $"{cls} {Clamp01(cx):F6} {Clamp01(cy):F6} {Clamp01(nw):F6} {Clamp01(nh):F6}"));
        }

        int count = 0;
        foreach (var (imageId, meta) in imageById)
        {
            ct.ThrowIfCancellationRequested();
            var src = ResolveImage(source.RootPath, meta.file);
            if (src is null) continue;

            var stem = Path.GetFileNameWithoutExtension(meta.file);
            var dstImg = Path.Combine(imgOut, Path.GetFileName(meta.file));
            var dstLbl = Path.Combine(lblOut, stem + ".txt");

            try { File.Copy(src, dstImg, overwrite: true); } catch { continue; }
            await File.WriteAllLinesAsync(dstLbl,
                grouped.TryGetValue(imageId, out var ls) ? ls : new List<string>(), ct);
            count++;
        }

        result.TrainImages = count;
        result.Notes.Add($"COCO → YOLO 转换完成，共 {count} 张图片。");
        // 转换后必然没有验证集，走切分
        var valList = await SplitTrainValAsync(source.RootPath, imgOut, options.ValSplit, yoloRoot, result, ct);
        await WriteDataYamlAsync(yoloRoot, imgOut, valList, source.Classes, ct);
    }

    private static string? ResolveImage(string root, string fileName)
    {
        var direct = Path.Combine(root, fileName);
        if (File.Exists(direct)) return direct;
        var nested = Directory.EnumerateFiles(root, Path.GetFileName(fileName), SearchOption.AllDirectories).FirstOrDefault();
        return nested;
    }

    // ---------------- VOC ----------------
    private async Task ConvertVocAsync(
        DatasetSummary source, TrainingOptions options, string yoloRoot, Result result, CancellationToken ct)
    {
        var imgOut = Path.Combine(yoloRoot, "images");
        var lblOut = Path.Combine(yoloRoot, "labels");
        Directory.CreateDirectory(imgOut);
        Directory.CreateDirectory(lblOut);

        var annoDir = FindDir(source.RootPath, "Annotations")!;
        var jpegDir = FindDir(source.RootPath, "JPEGImages") ?? FindDir(source.RootPath, "images") ?? source.RootPath;

        var classIndex = source.Classes
            .OrderBy(c => c.Index)
            .Select((c, i) => (c.Name, i))
            .ToDictionary(t => t.Name, t => t.i, StringComparer.Ordinal);

        int count = 0;
        foreach (var xml in Directory.GetFiles(annoDir, "*.xml"))
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                var doc = System.Xml.Linq.XDocument.Load(xml);
                var root = doc.Root!;
                var fileName = root.Element("filename")?.Value;
                int w = int.Parse(root.Element("size")?.Element("width")?.Value ?? "0");
                int h = int.Parse(root.Element("size")?.Element("height")?.Value ?? "0");
                if (w <= 0 || h <= 0) continue;

                var src = Directory.EnumerateFiles(jpegDir, Path.GetFileNameWithoutExtension(xml) + ".*",
                        SearchOption.TopDirectoryOnly)
                    .FirstOrDefault(DatasetScanner.IsImage);
                if (src is null) continue;

                var lines = new List<string>();
                foreach (var obj in root.Descendants("object"))
                {
                    var name = obj.Element("name")?.Value ?? "";
                    if (!classIndex.TryGetValue(name, out var cls)) continue;
                    var bb = obj.Element("bndbox");
                    if (bb is null) continue;
                    double xmin = double.Parse(bb.Element("xmin")!.Value);
                    double ymin = double.Parse(bb.Element("ymin")!.Value);
                    double xmax = double.Parse(bb.Element("xmax")!.Value);
                    double ymax = double.Parse(bb.Element("ymax")!.Value);

                    var cx = ((xmin + xmax) / 2) / w;
                    var cy = ((ymin + ymax) / 2) / h;
                    var bw = (xmax - xmin) / w;
                    var bh = (ymax - ymin) / h;
                    lines.Add(string.Create(CultureInfo.InvariantCulture,
                        $"{cls} {Clamp01(cx):F6} {Clamp01(cy):F6} {Clamp01(bw):F6} {Clamp01(bh):F6}"));
                }

                var stem = Path.GetFileNameWithoutExtension(xml);
                File.Copy(src, Path.Combine(imgOut, Path.GetFileName(src)), overwrite: true);
                await File.WriteAllLinesAsync(Path.Combine(lblOut, stem + ".txt"), lines, ct);
                count++;
            }
            catch
            {
                // 单个标注文件损坏时跳过，最后通过计数提示用户
            }
        }

        result.TrainImages = count;
        result.Notes.Add($"VOC → YOLO 转换完成，共处理 {count} 个标注文件（应为 {source.TrainImages}）。");
        var valList = await SplitTrainValAsync(source.RootPath, imgOut, options.ValSplit, yoloRoot, result, ct);
        await WriteDataYamlAsync(yoloRoot, imgOut, valList, source.Classes, ct);
    }

    // ---------------- 公共 ----------------
    private async Task WriteDataYamlAsync(
        string yoloRoot, string trainPath, string valPath, List<ClassDef> classes, CancellationToken ct)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"path: {yoloRoot.Replace('\\', '/')}");
        sb.AppendLine($"train: {trainPath.Replace('\\', '/')}");
        sb.AppendLine($"val: {valPath.Replace('\\', '/')}");
        sb.AppendLine($"nc: {classes.Count}");
        sb.AppendLine("names:");
        foreach (var c in classes.OrderBy(c => c.Index))
            sb.AppendLine($"  {c.Index}: \"{c.Name.Replace("\"", "\\\"")}\"");
        await File.WriteAllTextAsync(Path.Combine(yoloRoot, "data.yaml"), sb.ToString(), Encoding.UTF8, ct);
    }

    private static double Clamp01(double v) => v < 0 ? 0 : v > 1 ? 1 : v;

    private static string? FindDir(string root, params string[] segments)
    {
        var cur = root;
        foreach (var seg in segments)
        {
            if (!Directory.Exists(cur)) return null;
            var m = Directory.GetDirectories(cur)
                .FirstOrDefault(d => Path.GetFileName(d).Equals(seg, StringComparison.OrdinalIgnoreCase));
            if (m is null) return null;
            cur = m;
        }
        return cur;
    }

    private static int CountImages(string dir) =>
        Directory.Exists(dir)
            ? Directory.EnumerateFiles(dir, "*.*", SearchOption.AllDirectories).Count(DatasetScanner.IsImage)
            : 0;
}
