using System.Globalization;
using System.Text;
using VisionTrainer.Core;

namespace VisionTrainer.Data;

/// <summary>图片上的一个矩形标注。坐标一律用归一化值（0~1），与 YOLO 格式一致。</summary>
public sealed class BoundingBox
{
    public int ClassIndex { get; set; }
    /// <summary>中心点 X（0~1）</summary>
    public double Cx { get; set; }
    /// <summary>中心点 Y（0~1）</summary>
    public double Cy { get; set; }
    public double W { get; set; }
    public double H { get; set; }
    /// <summary>是否由 AI 预标注产生（UI 上用虚线区分，提醒客户复核）</summary>
    public bool FromAi { get; set; }

    public double Left => Cx - W / 2;
    public double Top => Cy - H / 2;
    public double Right => Cx + W / 2;
    public double Bottom => Cy + H / 2;

    public BoundingBox Clone() => new()
    {
        ClassIndex = ClassIndex, Cx = Cx, Cy = Cy, W = W, H = H, FromAi = FromAi,
    };

    /// <summary>像素坐标（左上右下）→ 归一化框。</summary>
    public static BoundingBox FromPixels(double x1, double y1, double x2, double y2, int imgW, int imgH, int cls)
    {
        if (imgW <= 0 || imgH <= 0) return new BoundingBox { ClassIndex = cls };
        var left = Math.Min(x1, x2);
        var top = Math.Min(y1, y2);
        var right = Math.Max(x1, x2);
        var bottom = Math.Max(y1, y2);

        return new BoundingBox
        {
            ClassIndex = cls,
            Cx = ((left + right) / 2) / imgW,
            Cy = ((top + bottom) / 2) / imgH,
            W = (right - left) / imgW,
            H = (bottom - top) / imgH,
        };
    }

    public bool IsValid => W > 1e-4 && H > 1e-4;

    public string ToYoloLine() => string.Create(CultureInfo.InvariantCulture,
        $"{ClassIndex} {Cx:F6} {Cy:F6} {W:F6} {H:F6}");

    public static BoundingBox? ParseYoloLine(string line)
    {
        var p = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        // 只接受标准 5 列检测标注；6 列以上是分割/姿态标注，这里不支持
        if (p.Length != 5) return null;
        if (!int.TryParse(p[0], out var cls)) return null;
        if (!double.TryParse(p[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var cx)) return null;
        if (!double.TryParse(p[2], NumberStyles.Float, CultureInfo.InvariantCulture, out var cy)) return null;
        if (!double.TryParse(p[3], NumberStyles.Float, CultureInfo.InvariantCulture, out var w)) return null;
        if (!double.TryParse(p[4], NumberStyles.Float, CultureInfo.InvariantCulture, out var h)) return null;

        return new BoundingBox { ClassIndex = cls, Cx = cx, Cy = cy, W = w, H = h };
    }
}

/// <summary>标注工程里的一张图片。</summary>
public sealed class AnnotationImage
{
    public string FilePath { get; set; } = "";
    public int Width { get; set; }
    public int Height { get; set; }
    public List<BoundingBox> Boxes { get; set; } = new();
    /// <summary>是否有脏数据待保存。</summary>
    public bool IsDirty { get; set; }

    public string FileName => Path.GetFileName(FilePath);
    public bool HasAnnotations => Boxes.Count > 0;
}

/// <summary>
/// 标注工程。落盘结构刻意与 YOLO 训练格式完全一致，这样"标完就能训练"，
/// 不需要再做一次格式转换：
/// <code>
/// &lt;工程目录&gt;\
///   project.json          ← 工程元信息（类别表）
///   images\               ← 原图（复制进来，不引用外部路径）
///   labels\               ← 与图片同名的 .txt，YOLO 格式
/// </code>
/// </summary>
public sealed class AnnotationProject
{
    public string Name { get; set; } = "";
    public string RootPath { get; set; } = "";
    public List<ClassDef> Classes { get; set; } = new();
    public List<AnnotationImage> Images { get; set; } = new();
    public DateTime UpdatedAt { get; set; } = DateTime.Now;

    public string ImagesDir => Path.Combine(RootPath, "images");
    public string LabelsDir => Path.Combine(RootPath, "labels");
    public string MetaFile => Path.Combine(RootPath, "project.json");

    public int AnnotatedCount => Images.Count(i => i.HasAnnotations);
    public int TotalBoxes => Images.Sum(i => i.Boxes.Count);

    public ClassDef? ClassOf(int index) => Classes.FirstOrDefault(c => c.Index == index);

    /// <summary>新建工程：复制图片进来，生成类别表。</summary>
    public static AnnotationProject Create(
        string rootPath, string name, IEnumerable<string> sourceImages,
        IEnumerable<string> classNames, Action<string>? log = null)
    {
        var project = new AnnotationProject { Name = name, RootPath = rootPath };
        Directory.CreateDirectory(project.ImagesDir);
        Directory.CreateDirectory(project.LabelsDir);

        int idx = 0;
        foreach (var n in classNames.Select(s => s.Trim()).Where(s => s.Length > 0))
            project.Classes.Add(new ClassDef { Index = idx, Name = n, ColorHex = Palette.ColorFor(idx++) });

        foreach (var src in sourceImages)
        {
            var dest = Path.Combine(project.ImagesDir, Path.GetFileName(src));
            // 同名文件加后缀，避免覆盖
            int dup = 1;
            while (File.Exists(dest))
            {
                var stem = Path.GetFileNameWithoutExtension(src);
                var ext = Path.GetExtension(src);
                dest = Path.Combine(project.ImagesDir, $"{stem}_{dup++}{ext}");
            }
            try
            {
                File.Copy(src, dest, overwrite: false);
                project.Images.Add(new AnnotationImage { FilePath = dest });
            }
            catch (Exception ex)
            {
                log?.Invoke($"跳过 {Path.GetFileName(src)}：{ex.Message}");
            }
        }

        project.ProbeImageSizes();
        project.Save();
        return project;
    }

    public static AnnotationProject? Load(string rootPath)
    {
        var meta = Path.Combine(rootPath, "project.json");
        if (!File.Exists(meta)) return null;
        try
        {
            var project = System.Text.Json.JsonSerializer.Deserialize<AnnotationProject>(
                File.ReadAllText(meta), SettingsStore.Options);
            if (project is null) return null;
            project.RootPath = rootPath;
            project.ProbeImageSizes();
            project.LoadAllLabels();
            return project;
        }
        catch
        {
            return null;
        }
    }

    /// <summary>扫描 images 目录，补齐工程里缺失的图片条目（支持往目录里手工丢图）。</summary>
    public void Rescan()
    {
        if (!Directory.Exists(ImagesDir)) return;
        var known = Images.Select(i => Path.GetFullPath(i.FilePath)).ToHashSet(StringComparer.OrdinalIgnoreCase);

        foreach (var f in Directory.EnumerateFiles(ImagesDir).Where(DatasetScanner.IsImage))
        {
            if (known.Contains(Path.GetFullPath(f))) continue;
            Images.Add(new AnnotationImage { FilePath = f });
        }

        // 移除已被手工删掉的图片
        Images.RemoveAll(i => !File.Exists(i.FilePath));
        ProbeImageSizes();
    }

    private void ProbeImageSizes()
    {
        foreach (var img in Images.Where(i => i.Width <= 0 || i.Height <= 0))
        {
            var (w, h) = ImageSizeReader.Read(img.FilePath);
            img.Width = w;
            img.Height = h;
        }
    }

    public string LabelPathOf(AnnotationImage image) =>
        Path.Combine(LabelsDir, Path.GetFileNameWithoutExtension(image.FilePath) + ".txt");

    public void LoadAllLabels()
    {
        foreach (var img in Images)
        {
            img.Boxes.Clear();
            var lp = LabelPathOf(img);
            if (!File.Exists(lp)) continue;
            foreach (var line in File.ReadLines(lp))
            {
                var box = BoundingBox.ParseYoloLine(line.Trim());
                if (box is not null) img.Boxes.Add(box);
            }
            img.IsDirty = false;
        }
    }

    /// <summary>保存单张图的标注。空标注会写空文件——这是 YOLO 的"负样本"约定，不能删文件。</summary>
    public void SaveImage(AnnotationImage image)
    {
        Directory.CreateDirectory(LabelsDir);
        var lines = image.Boxes.Where(b => b.IsValid).Select(b => b.ToYoloLine());
        File.WriteAllLines(LabelPathOf(image), lines, new UTF8Encoding(false));
        image.IsDirty = false;
        UpdatedAt = DateTime.Now;
    }

    public void SaveAll()
    {
        foreach (var img in Images) SaveImage(img);
        Save();
    }

    public void Save()
    {
        Directory.CreateDirectory(RootPath);
        UpdatedAt = DateTime.Now;
        // 序列化时排除运行时字段，避免把绝对路径写死到工程文件里
        var dto = new
        {
            Name,
            Classes,
            UpdatedAt,
            Images = Images.Select(i => new { i.FilePath, i.Width, i.Height }),
        };
        File.WriteAllText(MetaFile,
            System.Text.Json.JsonSerializer.Serialize(dto, SettingsStore.Options),
            new UTF8Encoding(false));
    }

    /// <summary>
    /// 导出为训练可直接消费的 YOLO 数据集结构。
    /// 与 DatasetPreparer 的 YOLO 分支对接：images/labels 平行目录 + data.yaml。
    /// </summary>
    public string ExportForTraining(string workDir)
    {
        var root = Path.Combine(workDir, "dataset");
        var imgOut = Path.Combine(root, "images", "train");
        var lblOut = Path.Combine(root, "labels", "train");
        Directory.CreateDirectory(imgOut);
        Directory.CreateDirectory(lblOut);

        // 只导出已经标过的图：没标过的图会被当成"全部是背景"，反而污染训练
        foreach (var img in Images.Where(i => i.HasAnnotations))
        {
            var destImg = Path.Combine(imgOut, Path.GetFileName(img.FilePath));
            if (!string.Equals(Path.GetFullPath(destImg), Path.GetFullPath(img.FilePath), StringComparison.OrdinalIgnoreCase))
                File.Copy(img.FilePath, destImg, overwrite: true);

            var destLbl = Path.Combine(lblOut, Path.GetFileNameWithoutExtension(img.FilePath) + ".txt");
            File.WriteAllLines(destLbl,
                img.Boxes.Where(b => b.IsValid).Select(b => b.ToYoloLine()),
                new UTF8Encoding(false));
        }

        var sb = new StringBuilder();
        sb.AppendLine($"path: {root.Replace('\\', '/')}");
        sb.AppendLine($"train: {imgOut.Replace('\\', '/')}");
        sb.AppendLine($"val: {imgOut.Replace('\\', '/')}");
        sb.AppendLine($"nc: {Classes.Count}");
        sb.AppendLine("names:");
        foreach (var c in Classes.OrderBy(c => c.Index))
            sb.AppendLine($"  {c.Index}: \"{c.Name.Replace("\"", "\\\"")}\"");
        var yaml = Path.Combine(root, "data.yaml");
        File.WriteAllText(yaml, sb.ToString(), new UTF8Encoding(false));

        return yaml;
    }
}

/// <summary>
/// 只读图片头部拿尺寸，不把整张图加载进内存。
/// 客户一次导入几千张图时，全量加载会直接 OOM。
/// </summary>
public static class ImageSizeReader
{
    public static (int Width, int Height) Read(string path)
    {
        try
        {
            using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using var br = new BinaryReader(fs);

            if (fs.Length < 24) return (0, 0);
            var b = br.ReadBytes((int)Math.Min(32, fs.Length));

            // PNG: 89 50 4E 47
            if (b[0] == 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47)
            {
                int w = (b[16] << 24) | (b[17] << 16) | (b[18] << 8) | b[19];
                int h = (b[20] << 24) | (b[21] << 16) | (b[22] << 8) | b[23];
                return (w, h);
            }

            // BMP
            if (b[0] == 0x42 && b[1] == 0x4D)
            {
                int w = BitConverter.ToInt32(b, 18);
                int h = Math.Abs(BitConverter.ToInt32(b, 22));
                return (w, h);
            }

            // JPEG: 扫 SOFn 段
            if (b[0] == 0xFF && b[1] == 0xD8)
            {
                fs.Position = 2;
                while (fs.Position < fs.Length - 9)
                {
                    int marker = br.ReadByte();
                    if (marker != 0xFF) continue;
                    int type = br.ReadByte();
                    // SOF0..SOF15，排除 C4(DHT) C8(JPG) CC(DAC)
                    if (type is >= 0xC0 and <= 0xCF && type != 0xC4 && type != 0xC8 && type != 0xCC)
                    {
                        br.ReadBytes(3);
                        int h = (br.ReadByte() << 8) | br.ReadByte();
                        int w = (br.ReadByte() << 8) | br.ReadByte();
                        return (w, h);
                    }
                    if (type is 0xD8 or 0xD9 or 0x01) continue;
                    int len = (br.ReadByte() << 8) | br.ReadByte();
                    if (len < 2) break;
                    fs.Position += len - 2;
                }
            }
            return (0, 0);
        }
        catch
        {
            return (0, 0);
        }
    }
}
