using VisionTrainer.Core;

namespace VisionTrainer.Data;

public enum DataLayout
{
    Unknown = 0,
    /// <summary>已规范的 YOLO 结构：images/ + labels/ 平行目录。</summary>
    YoloDetection = 1,
    /// <summary>COCO 标注：annotations.json + 图片目录。</summary>
    CocoDetection = 2,
    /// <summary>分类数据集：每个子文件夹一个类别。</summary>
    ImageFolder = 3,
    /// <summary>VOC 结构：Annotations/*.xml + JPEGImages/。</summary>
    VocDetection = 4,
}

/// <summary>
/// 数据集自动识别。设计原则：用户把文件夹拖进来就能用，不要求他懂 YOLO 目录规范，
/// 也不要求他手写 data.yaml。所有"规范化"动作在导入阶段一次性做完。
/// </summary>
public static class DatasetScanner
{
    private static readonly string[] ImageExtensions =
        { ".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff" };

    public static bool IsImage(string path) =>
        ImageExtensions.Contains(Path.GetExtension(path).ToLowerInvariant());

    public static DatasetSummary Scan(string root, TaskKind task)
    {
        var summary = new DatasetSummary { RootPath = root, Task = task };

        if (!Directory.Exists(root))
        {
            summary.Errors.Add($"目录不存在：{root}");
            summary.Layout = nameof(DataLayout.Unknown);
            return summary;
        }

        if (task == TaskKind.Classification)
        {
            ScanImageFolder(root, summary);
            return summary;
        }

        // 按优先级尝试各种检测格式，命中的第一个即确定布局
        if (TryScanYoloSplit(root, summary)) return summary;
        if (TryScanCoco(root, summary)) return summary;
        if (TryScanVoc(root, summary)) return summary;
        if (TryScanFlatYolo(root, summary)) return summary;

        summary.Layout = nameof(DataLayout.Unknown);
        summary.Errors.Add("无法识别数据集格式。支持：YOLO（images/labels）、COCO（annotations.json）、VOC（Annotations/*.xml）、分类（按类名分文件夹）。");
        return summary;
    }

    // ---------- 分类 ----------
    private static void ScanImageFolder(string root, DatasetSummary summary)
    {
        summary.Layout = nameof(DataLayout.ImageFolder);

        var classes = Directory.GetDirectories(root)
            .OrderBy(d => d, StringComparer.OrdinalIgnoreCase)
            .ToList();

        // 兼容 train/val 分层：root/train/class_a/...
        var trainRoot = FindSubDir(root, "train") ?? root;
        var valRoot = FindSubDir(root, "valid") ?? FindSubDir(root, "val");
        if (trainRoot != root)
        {
            classes = Directory.GetDirectories(trainRoot)
                .OrderBy(d => d, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        if (classes.Count < 2)
        {
            summary.Errors.Add("分类数据集至少需要 2 个类别文件夹，当前找到 " + classes.Count + " 个。");
        }

        int index = 0;
        foreach (var dir in classes)
        {
            summary.Classes.Add(new ClassDef
            {
                Index = index++,
                Name = Path.GetFileName(dir),
                ColorHex = Palette.ColorFor(index),
            });
            summary.TrainImages += CountImages(dir, recursive: false);
        }

        if (valRoot is not null)
            summary.ValImages = CountImages(valRoot, recursive: true);

        var thumb = classes
            .SelectMany(d => Directory.EnumerateFiles(d, "*.*", SearchOption.TopDirectoryOnly))
            .FirstOrDefault(IsImage);
        if (thumb is null) summary.Errors.Add("类别文件夹里没有找到图片。");
    }

    // ---------- YOLO：images/labels 平行结构 ----------
    private static bool TryScanYoloSplit(string root, DatasetSummary summary)
    {
        var imagesTrain = FindSubDir(root, "images", "train") ?? FindSubDir(root, "train", "images");
        var labelsTrain = FindSubDir(root, "labels", "train") ?? FindSubDir(root, "train", "labels");
        if (imagesTrain is null || labelsTrain is null) return false;

        summary.Layout = nameof(DataLayout.YoloDetection);
        summary.TrainImages = CountImages(imagesTrain, recursive: true);

        var imagesVal = FindSubDir(root, "images", "val") ?? FindSubDir(root, "val", "images");
        if (imagesVal is not null) summary.ValImages = CountImages(imagesVal, recursive: true);

        var labelFiles = Directory.EnumerateFiles(labelsTrain, "*.txt", SearchOption.TopDirectoryOnly).ToList();
        ReadClassNamesFromDataYaml(root, summary);

        // 没有 data.yaml 时，从标注文件的 class id 反推类别数量
        int maxId = ReadMaxClassId(labelFiles);

        if (summary.Classes.Count == 0 && maxId >= 0)
        {
            summary.Warnings.Add("未找到 data.yaml，类别名将使用占位符 class_0..class_N，请在下一步手动填写。");
            for (int i = 0; i <= maxId; i++)
                summary.Classes.Add(new ClassDef { Index = i, Name = $"class_{i}", ColorHex = Palette.ColorFor(i) });
        }

        ValidatePairing(imagesTrain, labelsTrain, summary);
        return true;
    }

    /// <summary>精简版：label 和 image 同目录的 txt 标注（Roboflow 导出常见）。</summary>
    private static bool TryScanFlatYolo(string root, DatasetSummary summary)
    {
        var imgDir = FindSubDir(root, "images") ?? root;
        var images = Directory.EnumerateFiles(imgDir, "*.*", SearchOption.TopDirectoryOnly)
            .Where(IsImage).ToList();
        if (images.Count == 0) return false;

        var labelsDir = FindSubDir(root, "labels") ?? imgDir;
        var labelFiles = images
            .Select(img => Path.Combine(labelsDir, Path.GetFileNameWithoutExtension(img) + ".txt"))
            .Where(File.Exists)
            .ToList();
        if (labelFiles.Count == 0) return false;

        summary.Layout = nameof(DataLayout.YoloDetection);
        summary.TrainImages = images.Count;
        ReadClassNamesFromDataYaml(root, summary);

        // 没有 data.yaml 时同样要从标注反推类别，否则 Classes 为空，
        // 下游 Pipeline.Validate 会直接判定"未识别到任何类别"，用户看到的就是
        // "明明导进来了却训练不了"。
        if (summary.Classes.Count == 0)
        {
            var maxId = ReadMaxClassId(labelFiles);
            if (maxId >= 0)
            {
                summary.Warnings.Add("未找到 data.yaml，类别名将使用占位符 class_0..class_N，请在下一步手动填写。");
                for (int i = 0; i <= maxId; i++)
                    summary.Classes.Add(new ClassDef { Index = i, Name = $"class_{i}", ColorHex = Palette.ColorFor(i) });
            }
            else
            {
                summary.Warnings.Add("未找到 data.yaml，请在下一步手动填写类别名称。");
            }
        }
        return true;
    }

    /// <summary>扫描标注文件，取出最大的 class id。无有效行时返回 -1。</summary>
    private static int ReadMaxClassId(IEnumerable<string> labelFiles)
    {
        int max = -1;
        foreach (var f in labelFiles)
        {
            try
            {
                foreach (var line in File.ReadLines(f))
                {
                    var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    // 合法的 YOLO 检测标注至少 5 列：class cx cy w h
                    if (parts.Length < 5) continue;
                    if (int.TryParse(parts[0], out var id) && id > max) max = id;
                }
            }
            catch
            {
                // 单个文件损坏（编码异常/被占用）不应中断整个扫描
            }
        }
        return max;
    }

    // ---------- COCO ----------
    private static bool TryScanCoco(string root, DatasetSummary summary)
    {
        var json = new[]
            {
                Path.Combine(root, "annotations.json"),
                Path.Combine(root, "_annotations.coco.json"),
                Path.Combine(root, "annotations", "instances_train.json"),
            }
            .FirstOrDefault(File.Exists);
        if (json is null) return false;

        summary.Layout = nameof(DataLayout.CocoDetection);
        try
        {
            using var doc = System.Text.Json.JsonDocument.Parse(File.ReadAllText(json));
            if (doc.RootElement.TryGetProperty("images", out var images))
                summary.TrainImages = images.GetArrayLength();

            if (doc.RootElement.TryGetProperty("categories", out var cats))
            {
                foreach (var c in cats.EnumerateArray())
                {
                    var id = c.TryGetProperty("id", out var i) ? i.GetInt32() : 0;
                    var name = c.TryGetProperty("name", out var n) ? n.GetString() ?? "" : "";
                    summary.Classes.Add(new ClassDef
                    {
                        Index = id,
                        Name = name,
                        ColorHex = Palette.ColorFor(id),
                    });
                }
            }
            summary.Warnings.Add("检测到 COCO 格式，导入时将自动转换为 YOLO 格式（一次性，不改动原始数据）。");
        }
        catch (Exception ex)
        {
            summary.Errors.Add("COCO 标注解析失败：" + ex.Message);
        }
        return true;
    }

    // ---------- Pascal VOC ----------
    private static bool TryScanVoc(string root, DatasetSummary summary)
    {
        var anno = FindSubDir(root, "Annotations");
        if (anno is null) return false;
        var xmls = Directory.GetFiles(anno, "*.xml", SearchOption.TopDirectoryOnly);
        if (xmls.Length == 0) return false;

        summary.Layout = nameof(DataLayout.VocDetection);
        summary.TrainImages = xmls.Length;
        var names = new HashSet<string>(StringComparer.Ordinal);
        foreach (var x in xmls.Take(50))
        {
            try
            {
                var doc = System.Xml.Linq.XDocument.Load(x);
                foreach (var obj in doc.Descendants("object"))
                {
                    var name = obj.Element("name")?.Value;
                    if (!string.IsNullOrWhiteSpace(name)) names.Add(name);
                }
            }
            catch { /* 单个坏文件不影响整体 */ }
        }
        int idx = 0;
        foreach (var n in names.OrderBy(n => n, StringComparer.Ordinal))
            summary.Classes.Add(new ClassDef { Index = idx, Name = n, ColorHex = Palette.ColorFor(idx++) });

        summary.Warnings.Add("检测到 VOC 格式，导入时将自动转换为 YOLO 格式。");
        return true;
    }

    // ---------- 工具方法 ----------
    private static void ValidatePairing(string imagesDir, string labelsDir, DatasetSummary summary)
    {
        var images = Directory.EnumerateFiles(imagesDir, "*.*", SearchOption.TopDirectoryOnly)
            .Where(IsImage).ToList();
        if (images.Count == 0)
        {
            summary.Errors.Add($"图片目录为空：{imagesDir}");
            return;
        }

        int missing = images.Count(img =>
            !File.Exists(Path.Combine(labelsDir, Path.GetFileNameWithoutExtension(img) + ".txt")));
        if (missing > 0)
            summary.Warnings.Add($"有 {missing} 张图片没有对应标注文件，训练时会作为负样本（背景图）参与，通常没问题。");
    }

    private static void ReadClassNamesFromDataYaml(string root, DatasetSummary summary)
    {
        var yaml = Directory.EnumerateFiles(root, "*.yaml", SearchOption.TopDirectoryOnly)
            .Concat(Directory.EnumerateFiles(root, "*.yml", SearchOption.TopDirectoryOnly))
            .FirstOrDefault(f => Path.GetFileName(f).Contains("data", StringComparison.OrdinalIgnoreCase))
            ?? Directory.EnumerateFiles(root, "*.yaml", SearchOption.TopDirectoryOnly).FirstOrDefault();
        if (yaml is null) return;

        string[]? names = null;
        var inNames = false;
        var pending = new List<string>();

        foreach (var raw in File.ReadLines(yaml))
        {
            var line = raw.TrimEnd();
            if (line.TrimStart().StartsWith("names:"))
            {
                inNames = true;
                var inline = line[(line.IndexOf(':') + 1)..].Trim();
                if (inline.StartsWith('[') && inline.EndsWith(']'))
                {
                    names = inline.Trim('[', ']')
                        .Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
                        .Select(s => s.Trim('\'', '"'))
                        .ToArray();
                    inNames = false;
                }
                continue;
            }
            if (inNames)
            {
                if (string.IsNullOrWhiteSpace(line) || !char.IsWhiteSpace(raw, 0))
                {
                    inNames = false;
                    continue;
                }
                // 形如 "  0: person" 或 "  - person"
                var text = line.Trim();
                if (text.StartsWith("- ")) pending.Add(text[2..].Trim('\'', '"'));
                else if (text.Contains(':')) pending.Add(text[(text.IndexOf(':') + 1)..].Trim().Trim('\'', '"'));
            }
        }

        var list = names ?? pending.ToArray();
        for (int i = 0; i < list.Length; i++)
        {
            if (string.IsNullOrWhiteSpace(list[i])) continue;
            summary.Classes.Add(new ClassDef { Index = i, Name = list[i], ColorHex = Palette.ColorFor(i) });
        }
    }

    private static string? FindSubDir(string root, params string[] segments)
    {
        var current = root;
        foreach (var seg in segments)
        {
            if (!Directory.Exists(current)) return null;
            var match = Directory.GetDirectories(current)
                .FirstOrDefault(d => Path.GetFileName(d).Equals(seg, StringComparison.OrdinalIgnoreCase));
            if (match is null) return null;
            current = match;
        }
        return current;
    }

    private static int CountImages(string dir, bool recursive) =>
        Directory.Exists(dir)
            ? Directory.EnumerateFiles(dir, "*.*", recursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly)
                .Count(IsImage)
            : 0;
}

public static class Palette
{
    private static readonly string[] Colors =
    {
        "#FF3B30", "#34C759", "#007AFF", "#FF9500", "#AF52DE",
        "#5AC8FA", "#FFCC00", "#FF2D55", "#5856D6", "#FF6B22",
        "#00C7BE", "#A2845E", "#1C1C1E", "#8E8E93", "#D63384",
    };

    public static string ColorFor(int index) => Colors[Math.Abs(index) % Colors.Length];
}
