@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

REM ============================================================
REM  VisionTrainer 离线包生成工具
REM
REM  在【能正常上网】的 Windows 机器上运行，产出可直接发给客户的
REM  offline 目录（含 Python 运行时 + 全部 wheel）。
REM  客户机器无需联网、无需装 Python，放进程序目录就能用。
REM
REM  用法：
REM    make-offline.bat             生成 CUDA 12.1 版（有 NVIDIA 显卡时用）
REM    make-offline.bat cpu         生成 CPU 版（体积小，无独显机器用）
REM    make-offline.bat cu118       生成 CUDA 11.8 版（老驱动用）
REM    make-offline.bat cu124       生成 CUDA 12.4 版
REM ============================================================

set PROFILE=%1
if "%PROFILE%"=="" set PROFILE=cu121

set PYVER=3.11.9
set OUT=%~dp0offline
set PYDIR=%OUT%\python
set WHEELS=%OUT%\wheels

echo.
echo ============================================================
echo   VisionTrainer 离线包生成
echo   档位: %PROFILE%     Python: %PYVER%
echo   输出: %OUT%
echo ============================================================
echo.

if exist "%OUT%" (
    echo 目录已存在，先删除旧的...
    rmdir /s /q "%OUT%"
)
mkdir "%WHEELS%" 2>nul
mkdir "%PYDIR%" 2>nul

REM ---------- 1. 下载 Python embeddable ----------
echo [1/4] 下载 Python %PYVER% embeddable...
set PYURL=https://mirrors.nju.edu.cn/python/%PYVER%/python-%PYVER%-embed-amd64.zip
curl -L --fail --progress-bar -o "%OUT%\python.zip" "%PYURL%"
if errorlevel 1 (
    echo 南大镜像失败，改用官方源...
    curl -L --fail --progress-bar -o "%OUT%\python.zip" "https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-embed-amd64.zip"
)
echo 解压...
powershell -NoProfile -Command "Expand-Archive -Path '%OUT%\python.zip' -DestinationPath '%PYDIR%' -Force"
del "%OUT%\python.zip"

REM ---------- 2. 让 embeddable 能加载 site-packages ----------
echo [2/4] 启用 site-packages...
powershell -NoProfile -Command ^
  "$p = Join-Path '%PYDIR%' 'python311._pth';" ^
  "$lines = @('python311.zip','.','Lib\site-packages','import site');" ^
  "Set-Content -Path $p -Value $lines -Encoding ascii"

REM ---------- 3. 装 pip ----------
echo [3/4] 安装 pip...
curl -L --fail --progress-bar -o "%PYDIR%\get-pip.py" "https://mirrors.aliyun.com/pypi/get-pip.py"
"%PYDIR%\python.exe" "%PYDIR%\get-pip.py" --no-warn-script-location
if errorlevel 1 (
    echo pip 安装失败，终止。
    exit /b 1
)

REM ---------- 4. 下载全部 wheel 到本地 ----------
echo.
echo [4/4] 下载 wheel（PyTorch 约 2.4GB，耐心等）...

REM PyTorch 版本必须与档位严格对应，否则 pip 找不到 wheel
if /i "%PROFILE%"=="cu118" (
    set TORCH=torch==2.5.1 torchvision==0.20.1
    set TORCHURL=https://mirrors.nju.edu.cn/pytorch/whl/cu118
)
if /i "%PROFILE%"=="cu121" (
    set TORCH=torch==2.5.1 torchvision==0.20.1
    set TORCHURL=https://mirrors.nju.edu.cn/pytorch/whl/cu121
)
if /i "%PROFILE%"=="cu124" (
    set TORCH=torch==2.6.0 torchvision==0.21.0
    set TORCHURL=https://mirrors.nju.edu.cn/pytorch/whl/cu124
)
if /i "%PROFILE%"=="cpu" (
    set TORCH=torch==2.6.0 torchvision==0.21.0
    set TORCHURL=https://mirrors.nju.edu.cn/pytorch/whl/cpu
)

echo   源: !TORCHURL!
"%PYDIR%\python.exe" -m pip download %TORCH% ^
    --index-url !TORCHURL! ^
    --only-binary=:all: ^
    -d "%WHEELS%" ^
    --no-warn-script-location --disable-pip-version-check
if errorlevel 1 (
    echo PyTorch 下载失败，终止。
    exit /b 1
)

REM 其余依赖从清华 pypi 下（含 ultralytics 及其全部依赖）
echo   下载 ultralytics 及依赖...
"%PYDIR%\python.exe" -m pip download ultralytics ^
    -i https://pypi.tuna.tsinghua.edu.cn/simple ^
    --only-binary=:all: ^
    --find-links "%WHEELS%" ^
    -d "%WHEELS%" ^
    --no-warn-script-location --disable-pip-version-check
if errorlevel 1 (
    echo ultralytics 依赖下载失败，终止。
    exit /b 1
)

REM ---------- 5. 清理与打包 ----------
echo.
echo 清理临时文件...
for /d /r "%PYDIR%" %%d in (__pycache__) do @if exist "%%d" rmdir /s /q "%%d"
del /q "%PYDIR%\get-pip.py" 2>nul

echo.
echo ============================================================
echo   完成！
echo.
echo   离线包位置: %OUT%
echo   目录大小:
powershell -NoProfile -Command "$s=(Get-ChildItem -Recurse '%OUT%' | Measure-Object -Property Length -Sum).Sum; '{0:N0} MB' -f ($s/1MB)"
echo.
echo   发给客户时：
echo     1. 把整个 offline 文件夹放进 VisionTrainer.exe 同目录
echo     2. 启动程序，首次训练会自动检测并安装，全程不联网
echo ============================================================
echo.
pause
