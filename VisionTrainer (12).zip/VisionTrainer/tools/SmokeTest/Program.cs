using VisionTrainer.Core;
using VisionTrainer.Data;
using VisionTrainer.Engine;
using VisionTrainer.Engine.Pipelines;
using VisionTrainer.Vision;

// 这个冒烟测试只验证"没有 UI 也能验证的核心逻辑"：
//   1. 数据集自动识别（YOLO / 分类 / 无 data.yaml 反推类别）
//   2. 训练进度解析（正则对 ultralytics 真实输出格式是否成立）
// 运行方式：dotnet run --project tools/SmokeTest

int passed = 0, failed = 0;

void Check(string name, bool condition, string? detail = null)
{
    if (condition)
    {
        Console.WriteLine($"  PASS  {name}");
        passed++;
    }
    else
    {
        Console.WriteLine($"  FAIL  {name}{(detail is null ? "" : "  → " + detail)}");
        failed++;
    }
}

var tmp = Path.Combine(Path.GetTempPath(), "vt_smoke_" + Guid.NewGuid().ToString("N")[..8]);
Directory.CreateDirectory(tmp);

try
{
    // ================= 1. YOLO 结构 =================
    Console.WriteLine("[1] YOLO images/labels 结构识别");
    var yoloRoot = Path.Combine(tmp, "yolo");
    var imgTrain = Path.Combine(yoloRoot, "images", "train");
    var lblTrain = Path.Combine(yoloRoot, "labels", "train");
    var imgVal = Path.Combine(yoloRoot, "images", "val");
    var lblVal = Path.Combine(yoloRoot, "labels", "val");
    foreach (var d in new[] { imgTrain, lblTrain, imgVal, lblVal }) Directory.CreateDirectory(d);

    for (int i = 0; i < 20; i++)
    {
        File.WriteAllBytes(Path.Combine(imgTrain, $"t{i}.jpg"), new byte[] { 0xFF, 0xD8 });
        var cls = i % 3;
        File.WriteAllText(Path.Combine(lblTrain, $"t{i}.txt"), $"{cls} 0.5 0.5 0.2 0.2\n{cls} 0.3 0.3 0.1 0.1");
        File.WriteAllBytes(Path.Combine(imgVal, $"v{i}.jpg"), new byte[] { 0xFF, 0xD8 });
        File.WriteAllText(Path.Combine(lblVal, $"v{i}.txt"), $"{cls} 0.5 0.5 0.2 0.2");
    }
    File.WriteAllText(Path.Combine(yoloRoot, "data.yaml"),
        "path: .\ntrain: images/train\nval: images/val\nnc: 3\nnames:\n  0: \"scratch\"\n  1: \"dent\"\n  2: \"stain\"\n");

    var s1 = DatasetScanner.Scan(yoloRoot, TaskKind.Detection);
    Check("layout = YoloDetection", s1.Layout == nameof(DataLayout.YoloDetection), s1.Layout);
    Check("train 图数 = 20", s1.TrainImages == 20, s1.TrainImages.ToString());
    Check("val 图数 = 20", s1.ValImages == 20, s1.ValImages.ToString());
    Check("类名从 data.yaml 读出", s1.Classes.Select(c => c.Name).SequenceEqual(new[] { "scratch", "dent", "stain" }),
        string.Join(",", s1.Classes.Select(c => c.Name)));
    Check("数据集可用", s1.IsUsable, string.Join(";", s1.Errors));

    // ================= 2. 无 data.yaml 时从标注反推 =================
    Console.WriteLine("[2] 无 data.yaml 时从标注 class id 反推类别");
    var flatRoot = Path.Combine(tmp, "flat");
    var fImg = Path.Combine(flatRoot, "images");
    var fLbl = Path.Combine(flatRoot, "labels");
    Directory.CreateDirectory(fImg);
    Directory.CreateDirectory(fLbl);
    for (int i = 0; i < 12; i++)
    {
        File.WriteAllBytes(Path.Combine(fImg, $"a{i}.png"), new byte[] { 0x89, 0x50 });
        File.WriteAllText(Path.Combine(fLbl, $"a{i}.txt"), $"{(i % 5)} 0.5 0.5 0.1 0.1");
    }
    var s2 = DatasetScanner.Scan(flatRoot, TaskKind.Detection);
    Check("识别为 YOLO", s2.Layout == nameof(DataLayout.YoloDetection), s2.Layout);
    Check("反推出 5 个类别", s2.Classes.Count == 5, s2.Classes.Count.ToString());
    Check("给出缺 data.yaml 的警告", s2.Warnings.Any(w => w.Contains("data.yaml")),
        string.Join(";", s2.Warnings));

    // ================= 3. 分类数据集 =================
    Console.WriteLine("[3] 图像分类（按文件夹）识别");
    var clsRoot = Path.Combine(tmp, "cls");
    foreach (var c in new[] { "ok", "ng" })
    {
        var d = Path.Combine(clsRoot, "train", c);
        Directory.CreateDirectory(d);
        for (int i = 0; i < 6; i++) File.WriteAllBytes(Path.Combine(d, $"{c}{i}.jpg"), new byte[] { 0xFF, 0xD8 });
    }
    var s3 = DatasetScanner.Scan(clsRoot, TaskKind.Classification);
    Check("layout = ImageFolder", s3.Layout == nameof(DataLayout.ImageFolder), s3.Layout);
    Check("2 个类别", s3.Classes.Count == 2, s3.Classes.Count.ToString());
    Check("训练图 12 张", s3.TrainImages == 12, s3.TrainImages.ToString());
    Check("数据集可用", s3.IsUsable, string.Join(";", s3.Errors));

    // ================= 4. 空目录应友好报错 =================
    Console.WriteLine("[4] 空目录应给出明确错误而非崩溃");
    var emptyRoot = Path.Combine(tmp, "empty");
    Directory.CreateDirectory(emptyRoot);
    var s4 = DatasetScanner.Scan(emptyRoot, TaskKind.Detection);
    Check("不可用", !s4.IsUsable);
    Check("有错误信息", s4.Errors.Count > 0, "无错误");
    Console.WriteLine("        实际提示: " + s4.Errors.FirstOrDefault());

    // ================= 5. 进度解析 =================
    Console.WriteLine("[5] ultralytics 输出解析");
    var job = new TrainingJob { Options = new TrainingOptions { Epochs = 100 } };
    var metrics = new List<EpochMetrics>();
    var parser = new DetectionProgressParser(job, metrics.Add);

    // 逐行喂入 ultralytics 真实格式的输出片段
    parser.Feed("      1/100      1.2340      1.5670      0.8910        120       640: 100%|##########| 50/50 [00:30<00:00]");
    parser.Feed("                  Class     Images  Instances      Box(P          R      mAP50  mAP50-95): 100%|##########|");
    parser.Feed("                    all         20         40      0.8010      0.7120      0.7890      0.6120");

    Check("解析出 1 轮", metrics.Count == 1, metrics.Count.ToString());
    if (metrics.Count == 1)
    {
        var m = metrics[0];
        Check("epoch = 1", m.Epoch == 1, m.Epoch.ToString());
        Check("total = 100", m.TotalEpochs == 100, m.TotalEpochs.ToString());
        Check($"mAP50-95 = 0.612 (实际 {m.Map50_95})", Math.Abs((m.Map50_95 ?? 0) - 0.612) < 1e-6);
        Check($"precision = 0.801 (实际 {m.Precision})", Math.Abs((m.Precision ?? 0) - 0.801) < 1e-6);
    }
    Check("job.History 同步", job.History.Count == 1, job.History.Count.ToString());
    Check("job.Best 已记录", job.Best is not null);
    Check("进度 = 1%", Math.Abs(parser.OverallPercent() - 1.0) < 0.01, parser.OverallPercent().ToString("F2"));

    // 第二轮验证 best 更新逻辑
    parser.Feed("      2/100      1.1000      1.4000      0.8000        120       640: 100%|##########|");
    parser.Feed("                  Class     Images  Instances      Box(P          R      mAP50  mAP50-95)");
    parser.Feed("                    all         20         40      0.8500      0.7600      0.8300      0.7000");
    Check("第 2 轮已记录", metrics.Count == 2, metrics.Count.ToString());
    Check($"best 更新为 0.700 (实际 {job.Best?.Map50_95})", Math.Abs((job.Best?.Map50_95 ?? 0) - 0.700) < 1e-6);

    // 无效行不应产生伪指标
    parser.Feed("Some random log line that is not a metric row");
    Check("垃圾行被忽略", metrics.Count == 2, metrics.Count.ToString());

    // ================= 6. 训练前校验 =================
    Console.WriteLine("[6] 训练前校验拦截");
    var pipeline = new DetectionPipeline();
    var badDataset = new DatasetSummary
    {
        Layout = nameof(DataLayout.YoloDetection),
        TrainImages = 3,
        Classes = { new ClassDef { Index = 0, Name = "class_0" } },
    };
    var errs = pipeline.Validate(badDataset, new TrainingOptions { ImageSize = 100 });
    Check("样本过少被拦", errs.Any(e => e.Contains("太少")), string.Join("|", errs));
    Check("占位类别名被拦", errs.Any(e => e.Contains("类别名称未填写")), string.Join("|", errs));
    Check("非 32 倍数被拦", errs.Any(e => e.Contains("32")), string.Join("|", errs));

    var goodDataset = new DatasetSummary
    {
        Layout = nameof(DataLayout.YoloDetection),
        TrainImages = 500,
        Classes = { new ClassDef { Index = 0, Name = "ok" } },
    };
    Check("正常数据集放行", pipeline.Validate(goodDataset, new TrainingOptions { ImageSize = 640 }).Count == 0);

    // ================= 7. 标注：像素坐标 → 归一化 =================
    Console.WriteLine("[7] 标注坐标换算");
    // 1000x500 的图上，从 (100,50) 拖到 (300,150)
    var nb = BoundingBox.FromPixels(100, 50, 300, 150, 1000, 500, 2);
    Check("中心 X = 0.2", Math.Abs(nb.Cx - 0.2) < 1e-9, nb.Cx.ToString());
    Check("中心 Y = 0.2", Math.Abs(nb.Cy - 0.2) < 1e-9, nb.Cy.ToString());
    Check("宽 = 0.2", Math.Abs(nb.W - 0.2) < 1e-9, nb.W.ToString());
    Check("高 = 0.2", Math.Abs(nb.H - 0.2) < 1e-9, nb.H.ToString());
    Check("类别 = 2", nb.ClassIndex == 2);

    // 反向拖拽（从右下拖到左上）结果必须一致——客户经常这么拖
    var nb2 = BoundingBox.FromPixels(300, 150, 100, 50, 1000, 500, 2);
    Check("反向拖拽结果一致",
        Math.Abs(nb2.Cx - nb.Cx) < 1e-9 && Math.Abs(nb2.W - nb.W) < 1e-9);

    // 边界值：整张图
    var full = BoundingBox.FromPixels(0, 0, 1000, 500, 1000, 500, 0);
    Check("整图框 = (0.5,0.5,1,1)",
        Math.Abs(full.Cx - 0.5) < 1e-9 && Math.Abs(full.W - 1) < 1e-9 && Math.Abs(full.H - 1) < 1e-9);

    // 退化框应被判无效（防止误点产生 0 面积框）
    var degenerate = BoundingBox.FromPixels(10, 10, 10, 10, 1000, 500, 0);
    Check("零面积框判为无效", !degenerate.IsValid);

    // ================= 8. 标注：YOLO 文本往返 =================
    Console.WriteLine("[8] YOLO 标注文本往返");
    var line = new BoundingBox { ClassIndex = 3, Cx = 0.123456, Cy = 0.654321, W = 0.25, H = 0.125 }.ToYoloLine();
    var parsed = BoundingBox.ParseYoloLine(line);
    Check("序列化格式正确（5 列）", line.Split(' ').Length == 5, line);
    Check("反解成功", parsed is not null);
    if (parsed is not null)
    {
        Check($"往返后 cx 一致 (0.123456 vs {parsed.Cx})", Math.Abs(parsed.Cx - 0.123456) < 1e-5);
        Check("往返后类别一致", parsed.ClassIndex == 3);
    }

    Check("6 列（分割格式）不被误解析", BoundingBox.ParseYoloLine("0 0.5 0.5 0.1 0.1 0.1") is null);
    Check("空行不崩", BoundingBox.ParseYoloLine("") is null);
    Check("垃圾文本不崩", BoundingBox.ParseYoloLine("abc def") is null);

    // ================= 9. 标注工程：创建 / 存盘 / 重载 =================
    Console.WriteLine("[9] 标注工程存取往返");
    var projRoot = Path.Combine(tmp, "proj");
    var srcDir = Path.Combine(tmp, "srcimg");
    Directory.CreateDirectory(srcDir);
    for (int i = 0; i < 5; i++)
        File.WriteAllBytes(Path.Combine(srcDir, $"p{i}.jpg"), new byte[] { 0xFF, 0xD8, 0xFF });

    var proj = AnnotationProject.Create(projRoot, "测试工程",
        Directory.GetFiles(srcDir), new[] { "划痕", "缺件" });
    Check("创建后图片数 = 5", proj.Images.Count == 5, proj.Images.Count.ToString());
    Check("类别数 = 2", proj.Classes.Count == 2);
    Check("类别名正确", proj.Classes[0].Name == "划痕" && proj.Classes[1].Name == "缺件");
    Check("图片已复制进工程",
        proj.Images.All(i => File.Exists(i.FilePath) && i.FilePath.StartsWith(projRoot)));
    Check("project.json 已生成", File.Exists(proj.MetaFile));

    // 给第一张图加标注并存盘
    proj.Images[0].Boxes.Add(new BoundingBox { ClassIndex = 0, Cx = 0.5, Cy = 0.5, W = 0.2, H = 0.3 });
    proj.Images[1].Boxes.Add(new BoundingBox { ClassIndex = 1, Cx = 0.25, Cy = 0.75, W = 0.1, H = 0.1 });
    proj.SaveAll();
    Check("已标注计数 = 2", proj.AnnotatedCount == 2, proj.AnnotatedCount.ToString());
    Check("总框数 = 2", proj.TotalBoxes == 2);

    var reloaded = AnnotationProject.Load(projRoot);
    Check("重载成功", reloaded is not null);
    if (reloaded is not null)
    {
        Check("重载后图片数 = 5", reloaded.Images.Count == 5, reloaded.Images.Count.ToString());
        Check("重载后框数保留", reloaded.TotalBoxes == 2, reloaded.TotalBoxes.ToString());
        Check("重载后类别保留", reloaded.Classes.Count == 2);
        Check("重载后坐标不丢精度",
            Math.Abs(reloaded.Images[0].Boxes[0].W - 0.2) < 1e-4,
            reloaded.Images[0].Boxes[0].W.ToString());
    }

    // ================= 10. 标注工程 → 训练数据集导出 =================
    Console.WriteLine("[10] 标注工程导出为训练数据集");
    var workDir = Path.Combine(tmp, "work");
    Directory.CreateDirectory(workDir);
    var yamlPath = proj.ExportForTraining(workDir);

    Check("data.yaml 生成", File.Exists(yamlPath));
    var yamlContent = File.ReadAllText(yamlPath);
    Check("yaml 含 nc: 2", yamlContent.Contains("nc: 2"), yamlContent);
    Check("yaml 含中文类别名", yamlContent.Contains("划痕") && yamlContent.Contains("缺件"));

    var exportedImages = Directory.GetFiles(Path.Combine(workDir, "dataset", "images", "train"));
    var exportedLabels = Directory.GetFiles(Path.Combine(workDir, "dataset", "labels", "train"), "*.txt");
    Check("只导出已标注的 2 张图", exportedImages.Length == 2, exportedImages.Length.ToString());
    Check("标签文件数 = 2", exportedLabels.Length == 2, exportedLabels.Length.ToString());

    // 导出的数据集应能被 DatasetScanner 正确识别（端到端闭环）
    var exportedScan = DatasetScanner.Scan(Path.Combine(workDir, "dataset"), TaskKind.Detection);
    Check("导出结果可被识别为 YOLO", exportedScan.Layout == nameof(DataLayout.YoloDetection), exportedScan.Layout);
    Check("导出的类别名被正确读回",
        exportedScan.Classes.Select(c => c.Name).SequenceEqual(new[] { "划痕", "缺件" }),
        string.Join(",", exportedScan.Classes.Select(c => c.Name)));

    // ================= 11. 图片尺寸读取（不加载整图） =================
    Console.WriteLine("[11] 图片尺寸读取健壮性");
    var fakeJpg = Path.Combine(tmp, "broken.jpg");
    File.WriteAllBytes(fakeJpg, new byte[] { 0xFF, 0xD8, 0x00, 0x01 });
    var (bw, bh) = ImageSizeReader.Read(fakeJpg);
    Check("损坏图片返回 0 而非抛异常", bw == 0 && bh == 0, $"{bw}x{bh}");
    Check("不存在的文件返回 0", ImageSizeReader.Read(Path.Combine(tmp, "nope.jpg")) == (0, 0));

    // ================= 11b. requirements.txt 格式合法性 =================
    // 真实事故：文件开头写了 Python 三引号文档字符串，pip 只认 # 注释，
    // 报 "Invalid requirement: '\"\"\"'"，所有依赖都装不上。
    Console.WriteLine("[11b] requirements.txt 格式");
    var reqPath = Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "..",
        "resources", "python", "requirements.txt");
    if (File.Exists(reqPath))
    {
        var reqLines = File.ReadAllLines(reqPath);
        Check("requirements 不含三引号", !reqLines.Any(l => l.Contains("\"\"\"")));
        var badLines = reqLines
            .Select((l, i) => (l.Trim(), i + 1))
            .Where(t => t.Item1.Length > 0 && !t.Item1.StartsWith("#"))
            .Where(t => !System.Text.RegularExpressions.Regex.IsMatch(
                t.Item1, @"^[A-Za-z0-9][A-Za-z0-9._-]*(\[[a-z0-9,]+\])?(\s*[<>=!~]=?\s*\S.*)?$"))
            .Select(t => $"第{t.Item2}行: {t.Item1}")
            .ToList();
        Check("每行都是注释或合法 requirement", badLines.Count == 0, string.Join("; ", badLines));
    }

    // ================= 12. 本地离线 wheel 安装 =================
    // 这是国内环境的主路径：不联网、不下载，直接 pip --no-index 装本地包。
    // 逻辑错了的表现是"装了个假的成功"，比报错更难查。
    Console.WriteLine("[12] 本地离线 wheel");

    var wheelDir = Path.Combine(tmp, "wheels");
    Directory.CreateDirectory(wheelDir);
    Check("空目录不算离线包", !PythonEnvironment.HasTorchWheel(wheelDir));

    // 只放 torchvision 不算——缺 torch 装了也是废的
    File.WriteAllText(Path.Combine(wheelDir, "torchvision-0.20.1+cu121-cp311-cp311-win_amd64.whl"), "");
    Check("只有 torchvision 不认作离线包", !PythonEnvironment.HasTorchWheel(wheelDir));

    File.WriteAllText(Path.Combine(wheelDir, "torch-2.5.1+cu121-cp311-cp311-win_amd64.whl"), "");
    Check("有 torch 即认作离线包", PythonEnvironment.HasTorchWheel(wheelDir));

    // 子目录里的不算：pip --find-links 只看一层，混进去会让检测与安装不一致
    var sub = Path.Combine(wheelDir, "sub");
    Directory.CreateDirectory(sub);
    File.WriteAllText(Path.Combine(sub, "torch-9.9.9+cu121-cp311-cp311-win_amd64.whl"), "");
    Check("子目录 wheel 不被误认", Directory.GetFiles(wheelDir, "torch-*.whl").Length == 1);

    // 不存在的目录不能让 HasTorchWheel 抛异常（用户可能删了目录）
    Check("不存在的目录返回 false", !PythonEnvironment.HasTorchWheel(Path.Combine(tmp, "no-such-dir")));

    // 设置里指定的目录优先级最高：用户手选的必须赢过自动探测
    var dirs = PythonEnvironment.LocalWheelDirs(new AppSettings { LocalWheelDir = wheelDir }, tmp);
    Check("用户指定目录排在首位", dirs.Count > 0 && dirs[0] == wheelDir,
        dirs.Count > 0 ? dirs[0] : "(空)");

    // 未指定时应自动探测 offline\wheels，否则离线包放进去也不生效
    var offlineDir = Path.Combine(tmp, "offline", "wheels");
    Directory.CreateDirectory(offlineDir);
    var autoDirs = PythonEnvironment.LocalWheelDirs(new AppSettings(), tmp);
    Check("自动探测包含 offline\\wheels",
        autoDirs.Any(d => d == offlineDir),
        string.Join("|", autoDirs));
    Check("不存在的 wheels 目录被过滤",
        autoDirs.All(d => Directory.Exists(d)));
    // 这几项错了 UI 上完全看不出来，只会表现为"pip 报 404"或"下了一小时还没完"
    // ================= 14. 验证页结果解析 =================
    Console.WriteLine("[14] 验证页结果解析");
    {
        // 与 verify.py 的 __RESULT__ JSON 结构严格对应，脚本改动必须同步改这里
        const string json = """
        {"model_classes":["划痕","缺件"],"results":[
          {"image":"C:/x/a.jpg","width":640,"height":480,"vis_path":"C:/x/a_det.jpg",
           "boxes":[{"class_id":0,"class_name":"划痕","cx":0.5,"cy":0.5,"w":0.3,"h":0.2,"score":0.87}]},
          {"image":"C:/x/b.jpg","width":100,"height":100,"vis_path":"","boxes":[]}]}
        """;
        var vout = ModelVerifier.Parse(json);
        Check("模型类别解析", vout.ModelClasses.SequenceEqual(new[] { "划痕", "缺件" }));
        Check("结果条数解析", vout.Results.Count == 2);
        var first = vout.Results[0];
        Check("图片尺寸解析", first.Width == 640 && first.Height == 480, $"{first.Width}x{first.Height}");
        Check("框字段解析",
            first.Boxes.Count == 1 && first.Boxes[0].ClassName == "划痕"
            && Math.Abs(first.Boxes[0].Score - 0.87) < 1e-9
            && Math.Abs(first.Boxes[0].Cx - 0.5) < 1e-9);
        Check("空结果不炸", vout.Results[1].Boxes.Count == 0);
        // 中文文件名的路径不能被 JSON 转义破坏
        const string cnJson = """{"model_classes":[],"results":[{"image":"C:/数据/划痕01.jpg","width":10,"height":10,"vis_path":"","boxes":[]}]}""";
        Check("中文路径解析", ModelVerifier.Parse(cnJson).Results[0].ImagePath.Contains("划痕01"));

        // 视频模式摘要
        const string videoJson = """{"model_classes":["划痕"],"video":{"video":120,"total_boxes":95,"saved":"C:/out/test_det.mp4","width":640,"height":480}}""";
        var vres = ModelVerifier.Parse(videoJson);
        Check("视频摘要解析", vres.Video is { Frames: 120, TotalBoxes: 95 }
            && vres.Video.SavedVideo.EndsWith("_det.mp4"));

        // 摄像头模式摘要
        const string camJson = """{"model_classes":[],"camera":{"camera":310,"total_boxes":42,"saved":"C:/out/camera_det.mp4"}}""";
        var cres = ModelVerifier.Parse(camJson);
        Check("摄像头摘要解析", cres.Camera is { Frames: 310, TotalBoxes: 42 }
            && cres.Camera.SavedVideo.EndsWith("camera_det.mp4"));
        Check("图片/视频/摄像头互不干扰",
            cres.Results.Count == 0 && cres.Video is null && vres.Camera is null);
    }

    // ================= 13. 下载源配置 =================
    // 这几项错了 UI 上完全看不出来，只会表现为"pip 报 404"或"下了一小时还没完"
    Console.WriteLine("[13] 下载源配置");

    // 默认必须是国内镜像，不能是官方源
    var defaults = new AppSettings();
    Check("PyTorch 默认源是国内镜像",
        defaults.TorchIndexPattern.Contains("mirrors."), defaults.TorchIndexPattern);
    Check("pip 默认源是国内镜像",
        defaults.PipIndexUrl.Contains("tuna") || defaults.PipIndexUrl.Contains("aliyun"), defaults.PipIndexUrl);

    // 各镜像的 URL 结构不同，替换错前缀就是 404，这里逐个核对
    Check("南大 cu121 地址结构正确",
        string.Format(TorchMirrors.Nju, "cu121") == "https://mirrors.nju.edu.cn/pytorch/whl/cu121",
        string.Format(TorchMirrors.Nju, "cu121"));
    Check("交大 cu124 地址结构正确",
        string.Format(TorchMirrors.Sjtu, "cu124") == "https://mirror.sjtu.edu.cn/pytorch-wheels/cu124",
        string.Format(TorchMirrors.Sjtu, "cu124"));
    Check("CPU 档位地址正确",
        string.Format(TorchMirrors.Nju, "cpu") == "https://mirrors.nju.edu.cn/pytorch/whl/cpu",
        string.Format(TorchMirrors.Nju, "cpu"));

    // 下拉框里不能再出现已知失效的源（阿里云 torch 目录不是 pip index）
    Check("候选源不含阿里云 PyTorch",
        TorchMirrors.All.All(m => !m.Pattern.Contains("aliyun")),
        string.Join(",", TorchMirrors.All.Select(m => m.Name)));

    // 旧配置迁移：0.1.0 的默认值是官方源，升级后必须自动切镜像
    var legacy = new AppSettings { TorchIndexPattern = "https://download.pytorch.org/whl/{0}" };
    legacy.MigrateTorchMirror();
    Check("旧配置官方源被迁到国内镜像",
        !legacy.TorchIndexPattern.Contains("download.pytorch.org"), legacy.TorchIndexPattern);

    // 用户自己填的企业私服不能被覆盖
    var custom = new AppSettings { TorchIndexPattern = "http://pypi.corp.local/pytorch/{0}" };
    custom.MigrateTorchMirror();
    Check("企业私服配置不被覆盖",
        custom.TorchIndexPattern == "http://pypi.corp.local/pytorch/{0}", custom.TorchIndexPattern);

    // 空值要回填默认，否则安装时会拼出 "/cu121" 这种残缺地址
    var empty = new AppSettings { TorchIndexPattern = "" };
    empty.MigrateTorchMirror();
    Check("空源被回填默认镜像", empty.TorchIndexPattern == TorchMirrors.Nju, empty.TorchIndexPattern);

    // 回退链：用户选官方源时，前面仍应排着国内镜像
    var candidates = TorchMirrors.All.Select(m => string.Format(m.Pattern, "cu121")).ToList();
    Check("回退链含南大与交大",
        candidates.Any(u => u.Contains("nju")) && candidates.Any(u => u.Contains("sjtu")));
    Check("回退链末位是官方源兜底",
        candidates.Last().Contains("download.pytorch.org"), candidates.Last());
    Check("回退链地址无重复", candidates.Distinct().Count() == candidates.Count);
}
finally
{
    try { Directory.Delete(tmp, true); } catch { }
}

Console.WriteLine();
Console.WriteLine($"结果：{passed} 通过，{failed} 失败");
return failed == 0 ? 0 : 1;
