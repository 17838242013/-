# VisionTrainer

面向非技术用户的视觉模型训练工具。客户双击 exe、导入图片、在界面上框出目标、点训练，就能得到自己的检测模型。**不需要安装 Python，不需要配置 CUDA，不需要敲命令。**

## 完整工作流

```
① 标注  →  ② 训练  →  ③ 用模型预标注剩下的图  →  ④ 再训练（精度提升）
   手画几个框      20~30 张就够                  AI 批量出框，人工微调
```

第一次总是要手工标 20~30 张；训练出第一版模型后，AI 预标注能把后续标注效率提升数倍。

## 目录结构

```
VisionTrainer/
├── VisionTrainer.sln
├── Directory.Build.props             # 统一目标框架与编译开关
├── src/
│   ├── VisionTrainer.App/            # WinForm 界面（net8.0-windows）
│   │   ├── Program.cs                # 入口 + 全局异常兜底
│   │   ├── MainForm.cs               # 主窗体 + 左侧导航
│   │   ├── app.manifest              # 高 DPI / 长路径 / asInvoker
│   │   ├── UI/
│   │   │   ├── Theme.cs              # 视觉规范与自绘控件
│   │   │   ├── AnnotationCanvas.cs   # 标注画布（画框/移动/删除）
│   │   │   └── OnboardingOverlay.cs  # 分步操作引导浮层
│   │   └── Pages/                    # 首页/标注/数据集/训练/历史/设置
│   ├── VisionTrainer.Pipeline/       # 任务编排（JobRunner）
│   ├── VisionTrainer.Engine/         # Python 环境自举 + 训练流程抽象
│   ├── VisionTrainer.Data/           # 数据集识别、格式转换、标注工程
│   ├── VisionTrainer.Core/           # 模型、路径、进程、硬件检测
│   └── VisionTrainer.Vision/         # AI 预标注推理桥接
├── resources/
│   ├── python/
│   │   ├── train_detect.py           # YOLO11 训练脚本
│   │   ├── predict.py                # 批量推理（预标注用）
│   │   └── requirements.txt          # 锁定版本的依赖清单
│   └── weights/README.md             # 预训练权重放置说明
├── tools/SmokeTest/                  # 核心逻辑冒烟测试（65 项）
└── docs/技术方案.md                   # 完整技术方案
```

## 快速开始

### 环境要求

- **开发**：Windows 10/11 + Visual Studio 2022 (17.8+) + .NET 8 SDK
- **运行**：Windows 10/11 x64，无需预装任何运行时

### 编译运行

```powershell
dotnet build src/VisionTrainer.App/VisionTrainer.App.csproj
dotnet run --project src/VisionTrainer.App
```

### 运行逻辑测试

```powershell
dotnet run --project tools/SmokeTest
```

覆盖数据集识别（4 种格式）、ultralytics 输出解析、训练前校验、标注坐标换算、标注工程存取、标注→训练端到端。当前 65/65 通过。

### 发布

```powershell
dotnet publish src/VisionTrainer.App/VisionTrainer.App.csproj -c Release
```

产物：`src/VisionTrainer.App/bin/Release/net8.0-windows/win-x64/publish/VisionTrainer.exe`（约 64 MB，单文件，含 .NET 运行时）。

## 分发前必做

1. 把 `yolo11n.pt`（约 5.4 MB）放到 `publish/resources/weights/`，避免客户内网下载失败
2. 内网客户：复制 `%LOCALAPPDATA%\VisionTrainer\python` 到 `publish/runtime/python`，实现完全离线
3. 在**干净的 Windows 机器**上测试一次完整流程（导入数据集 → 训练 → 查看结果）

详细说明见 [docs/技术方案.md](docs/技术方案.md) 第八节。

## 支持的数据集格式

| 格式 | 目录特征 |
|---|---|
| YOLO | `images/train` + `labels/train` 平行目录 |
| COCO | `annotations.json` 或 `_annotations.coco.json` |
| Pascal VOC | `Annotations/*.xml` + `JPEGImages/` |
| 图像分类 | 每个子文件夹一个类别名 |

缺 `data.yaml` 不会拒绝训练，会自动从标注反推类别。原始数据**只读不写**。

## 扩展新任务类型

实现 `ITrainingPipeline` 并注册即可，主流程无需改动：

```csharp
PipelineRegistry.Register(new ClassificationPipeline());
```

参数表单由 `ParameterSpec` 自动生成。详见技术方案第六节。

## 数据存放位置

| 路径 | 内容 |
|---|---|
| `%LOCALAPPDATA%\VisionTrainer\python\` | 嵌入式 Python 运行时与依赖 |
| `%LOCALAPPDATA%\VisionTrainer\projects\` | 每次训练的产物（模型、日志、数据集快照） |
| `%LOCALAPPDATA%\VisionTrainer\logs\` | 崩溃日志 |
| `%LOCALAPPDATA%\VisionTrainer\settings.json` | 用户设置 |

**便携模式**：在 exe 同目录放一个空的 `portable.txt`，所有数据改存到 `<exe目录>\data`，可随 U 盘携带。
