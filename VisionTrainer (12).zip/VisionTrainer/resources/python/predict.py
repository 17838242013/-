"""
批量推理脚本，用于标注页的「AI 预标注」。

输入：模型 .pt + 图片目录
输出：JSON，包含每张图的框（归一化坐标）+ 模型自带的类别名

约定（C# 侧 PreAnnotator.cs 依赖这些，改动必须同步）：
  - 每处理完一张图片打印 "[PROGRESS] n/total"
  - 最终结果写到 --out 指定的 JSON 文件
  - 失败时退出码非 0
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import traceback
import warnings

warnings.filterwarnings("ignore")

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}


def main() -> int:
    p = argparse.ArgumentParser(description="VisionTrainer pre-annotation inference")
    p.add_argument("--model", required=True, help=".pt 模型路径")
    p.add_argument("--images", required=True, help="图片目录")
    p.add_argument("--out", required=True, help="输出 JSON 路径")
    p.add_argument("--conf", type=float, default=0.25)
    p.add_argument("--imgsz", type=int, default=640)
    p.add_argument("--names-json", default="", help="工程类别名（保留参数，用于日志提示）")
    args = p.parse_args()

    try:
        import torch
        from ultralytics import YOLO
    except Exception as exc:  # noqa: BLE001
        print(f"[FATAL] 导入依赖失败: {exc}", file=sys.stderr, flush=True)
        traceback.print_exc()
        return 2

    if not os.path.isfile(args.model):
        print(f"[FATAL] 模型文件不存在: {args.model}", file=sys.stderr, flush=True)
        return 2

    if not os.path.isdir(args.images):
        print(f"[FATAL] 图片目录不存在: {args.images}", file=sys.stderr, flush=True)
        return 2

    files = sorted(
        f for f in os.listdir(args.images)
        if os.path.splitext(f)[1].lower() in IMAGE_EXTS
    )
    if not files:
        print("[FATAL] 目录里没有图片", file=sys.stderr, flush=True)
        return 2

    device = 0 if torch.cuda.is_available() else "cpu"
    print(f"[INFO] 设备: {'GPU' if device == 0 else 'CPU'}，共 {len(files)} 张图片", flush=True)

    try:
        model = YOLO(args.model)
    except Exception as exc:  # noqa: BLE001
        print(f"[FATAL] 加载模型失败: {exc}", file=sys.stderr, flush=True)
        traceback.print_exc()
        return 3

    # 取模型自带的类别名，C# 侧要拿它和工程类别做匹配
    model_names = []
    try:
        names = model.names
        if isinstance(names, dict):
            model_names = [names[k] for k in sorted(names.keys())]
        else:
            model_names = list(names)
    except Exception:  # noqa: BLE001
        model_names = []

    print(f"[INFO] 模型类别({len(model_names)}): {', '.join(map(str, model_names[:15]))}", flush=True)

    results_payload = []
    total = len(files)

    for i, fname in enumerate(files, start=1):
        path = os.path.join(args.images, fname)
        boxes_out = []
        try:
            # 逐张推理而不是批量：客户图片尺寸差异大，批量拼图反而更慢且容易 OOM
            preds = model.predict(path, conf=args.conf, imgsz=args.imgsz,
                                  device=device, verbose=False)
            for r in preds:
                if r.boxes is None:
                    continue
                h, w = r.orig_shape[0], r.orig_shape[1]
                if w <= 0 or h <= 0:
                    continue
                for box in r.boxes:
                    cls_id = int(box.cls[0].item())
                    # 模型用 xywh 且中心点格式，直接就是我们要的归一化值
                    cx, cy, bw, bh = [float(v) for v in box.xywhn[0].tolist()]
                    name = model_names[cls_id] if cls_id < len(model_names) else f"class_{cls_id}"
                    boxes_out.append({
                        "class_name": str(name),
                        "cx": round(cx, 6),
                        "cy": round(cy, 6),
                        "w": round(bw, 6),
                        "h": round(bh, 6),
                        "score": round(float(box.conf[0].item()), 4),
                    })
        except torch.cuda.OutOfMemoryError:
            print(f"[WARN] {fname} 显存不足，跳过", file=sys.stderr, flush=True)
            torch.cuda.empty_cache()
        except Exception as exc:  # noqa: BLE001
            print(f"[WARN] {fname} 处理失败: {exc}", file=sys.stderr, flush=True)

        results_payload.append({"file": fname, "boxes": boxes_out})
        print(f"[PROGRESS] {i}/{total}", flush=True)

    payload = {"model_classes": model_names, "images": results_payload}
    try:
        with open(args.out, "w", encoding="utf-8") as fp:
            json.dump(payload, fp, ensure_ascii=False, indent=1)
    except Exception as exc:  # noqa: BLE001
        print(f"[FATAL] 写入结果失败: {exc}", file=sys.stderr, flush=True)
        return 4

    total_boxes = sum(len(x["boxes"]) for x in results_payload)
    print(f"[INFO] 完成：{total} 张图，共 {total_boxes} 个框", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
