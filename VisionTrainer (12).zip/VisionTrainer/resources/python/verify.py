"""
模型验证推理：图片 / 视频文件 / 摄像头实时检测。

输入：模型 .pt + 图片路径列表，或 --video 视频文件，或 --camera 摄像头
输出：JSON（检测框 + 类别名 + 置信度）+ 可视化结果：
  - 图片：画好框存到 --save-dir
  - 视频：逐帧检测后用 VideoWriter 输出标注视频（无声音，编码 mp4v）
  - 摄像头：弹出实时检测窗口（按 Q 或关窗口结束），可选录制保存

约定（C# 侧 ModelVerifier.cs 依赖，改动必须同步）：
  - 成功时 stdout 最后一行以 __RESULT__ 开头，后跟 JSON
  - 失败退出码非 0，stderr 带可读原因
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import traceback
import warnings

warnings.filterwarnings("ignore")

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
VIDEO_EXTS = {".mp4", ".avi", ".mov", ".mkv", ".wmv"}


def collect_images(paths: list[str]) -> list[str]:
    out = []
    for p in paths:
        if os.path.isdir(p):
            out += sorted(
                os.path.join(p, f) for f in os.listdir(p)
                if os.path.splitext(f)[1].lower() in IMAGE_EXTS
            )
        elif os.path.isfile(p) and os.path.splitext(p)[1].lower() in IMAGE_EXTS:
            out.append(p)
    # 去重保序
    seen, uniq = set(), []
    for p in out:
        rp = os.path.abspath(p)
        if rp not in seen:
            seen.add(rp)
            uniq.append(rp)
    return uniq


def draw_boxes(img_path: str, boxes: list[dict], save_path: str, names: list[str]) -> None:
    """用 PIL 画框。不依赖 cv2（headless 版也行，但 PIL 一定在依赖里）。"""
    from PIL import Image, ImageDraw, ImageFont

    img = Image.open(img_path).convert("RGB")
    draw = ImageDraw.Draw(img)
    w, h = img.size
    try:
        font = ImageFont.truetype("arial.ttf", max(14, h // 40))
    except Exception:  # noqa: BLE001
        font = ImageFont.load_default()

    # 类别颜色表（足够的区分度即可）
    palette = ["#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4",
               "#46f0f0", "#f032e6", "#bcf60c", "#fabebe", "#008080"]

    for b in boxes:
        cx, cy, bw, bh = b["cx"] * w, b["cy"] * h, b["w"] * w, b["h"] * h
        x0, y0 = cx - bw / 2, cy - bh / 2
        x1, y1 = cx + bw / 2, cy + bh / 2
        color = palette[b.get("class_id", 0) % len(palette)]
        draw.rectangle([x0, y0, x1, y1], outline=color, width=max(2, h // 300))
        label = f"{b['class_name']} {b['score']:.2f}"
        tb = draw.textbbox((x0, y0), label, font=font)
        # 标签底色：框太靠上时标签放框内
        ty0 = y0 - (tb[3] - tb[1]) if y0 - (tb[3] - tb[1]) >= 0 else y0
        draw.rectangle([tb[0], ty0, tb[2], ty0 + (tb[3] - tb[1])], fill=color)
        draw.text((tb[0], ty0), label, fill="white", font=font)

    img.save(save_path)


def draw_boxes_cv(frame, boxes: list[dict], names: list[str]) -> None:
    """OpenCV 版画框（视频/摄像头用，性能优先，不用 PIL）。"""
    import cv2

    palette = [(75, 25, 230), (48, 180, 60), (216, 99, 67), (31, 130, 245),
               (180, 30, 145), (35, 240, 240), (230, 50, 240), (12, 246, 188)]
    h, w = frame.shape[:2]
    for b in boxes:
        cx, cy, bw, bh = b["cx"] * w, b["cy"] * h, b["w"] * w, b["h"] * h
        x0, y0 = int(cx - bw / 2), int(cy - bh / 2)
        x1, y1 = int(cx + bw / 2), int(cy + bh / 2)
        color = palette[b.get("class_id", 0) % len(palette)]
        cv2.rectangle(frame, (x0, y0), (x1, y1), color, 2)
        label = f"{b['class_name']} {b['score']:.2f}"
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 1)
        ty0 = y0 - th - 6 if y0 - th - 6 >= 0 else y0
        cv2.rectangle(frame, (x0, ty0), (x0 + tw + 4, ty0 + th + 6), color, -1)
        cv2.putText(frame, label, (x0 + 2, ty0 + th + 2),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)


def detect_frame(model, frame, device, conf, imgsz) -> list[dict]:
    """对单帧做检测，返回归一化框列表。图片/视频/摄像头共用。"""
    boxes_out = []
    preds = model.predict(frame, conf=conf, imgsz=imgsz, device=device, verbose=False)
    for r in preds:
        if r.boxes is None:
            continue
        for box in r.boxes:
            cls_id = int(box.cls[0].item())
            cx, cy, bw, bh = [float(v) for v in box.xywhn[0].tolist()]
            boxes_out.append({
                "class_id": cls_id,
                "class_name": str(r.names.get(cls_id, f"class_{cls_id}")) if isinstance(r.names, dict)
                else (str(r.names[cls_id]) if cls_id < len(r.names) else f"class_{cls_id}"),
                "cx": round(cx, 6), "cy": round(cy, 6),
                "w": round(bw, 6), "h": round(bh, 6),
                "score": round(float(box.conf[0].item()), 4),
            })
    return boxes_out


def run_video(model, args, device, names) -> dict:
    """视频文件：逐帧检测，输出标注视频。"""
    import cv2

    os.makedirs(args.save_dir, exist_ok=True)
    cap = cv2.VideoCapture(args.video)
    if not cap.isOpened():
        raise RuntimeError(f"无法打开视频文件: {args.video}")

    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0

    base = os.path.splitext(os.path.basename(args.video))[0]
    out_path = os.path.join(args.save_dir, base + "_det.mp4")
    writer = cv2.VideoWriter(out_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))

    n, total_boxes = 0, 0
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            boxes = detect_frame(model, frame, device, args.conf, args.imgsz)
            total_boxes += len(boxes)
            draw_boxes_cv(frame, boxes, names)
            writer.write(frame)
            n += 1
            if n % 10 == 0 or (total and n == total):
                print(f"[PROGRESS] {n}/{total if total else n}", flush=True)
    finally:
        cap.release()
        writer.release()

    if n == 0:
        raise RuntimeError("视频里没有读到任何帧，文件可能损坏。")
    return {"video": n, "total_boxes": total_boxes, "saved": out_path,
            "width": w, "height": h}


def run_camera(model, args, device, names) -> dict:
    """摄像头实时检测：弹窗显示，按 Q 或关窗口结束。"""
    import cv2

    os.makedirs(args.save_dir, exist_ok=True)
    cap = cv2.VideoCapture(args.camera if args.camera >= 0 else 0)
    if not cap.isOpened():
        raise RuntimeError(
            "无法打开摄像头。请确认：\n"
            "1. 电脑有摄像头且没被其他程序占用\n"
            "2. Windows 隐私设置允许桌面应用访问摄像头")

    writer = None
    n, total_boxes = 0, 0
    win = "VisionTrainer 检测（按 Q 退出）"
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            boxes = detect_frame(model, frame, device, args.conf, args.imgsz)
            total_boxes += len(boxes)
            draw_boxes_cv(frame, boxes, names)
            n += 1

            if args.save_camera:
                if writer is None:
                    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
                    h, w = frame.shape[:2]
                    save_path = os.path.join(args.save_dir, "camera_det.mp4")
                    writer = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
                    print(f"[INFO] 录制保存到: {save_path}", flush=True)
                writer.write(frame)

            cv2.imshow(win, frame)
            # waitKey 必须有，否则窗口无响应；返回 113 = 'q'
            if cv2.waitKey(1) & 0xFF == ord('q') or cv2.getWindowProperty(win, cv2.WND_PROP_VISIBLE) < 1:
                break
    finally:
        cap.release()
        if writer is not None:
            writer.release()
        cv2.destroyAllWindows()

    if n == 0:
        raise RuntimeError("摄像头一帧都没读到。")
    saved = os.path.join(args.save_dir, "camera_det.mp4") if writer is not None else ""
    return {"camera": n, "total_boxes": total_boxes, "saved": saved}


def main() -> int:
    p = argparse.ArgumentParser(description="VisionTrainer model verify inference")
    p.add_argument("--model", required=True, help=".pt 模型路径")
    p.add_argument("--images", nargs="*", default=[], help="图片路径或目录（图片模式）")
    p.add_argument("--video", default="", help="视频文件路径（视频模式）")
    p.add_argument("--camera", type=int, default=-1, help="摄像头序号（摄像头模式，0 为默认）")
    p.add_argument("--save-camera", action="store_true", help="摄像头模式同时录制保存")
    p.add_argument("--save-dir", required=True, help="可视化结果保存目录")
    p.add_argument("--conf", type=float, default=0.25)
    p.add_argument("--imgsz", type=int, default=640)
    args = p.parse_args()

    try:
        import torch
        from ultralytics import YOLO
    except Exception as exc:  # noqa: BLE001
        print(f"[FATAL] 导入依赖失败: {exc}", file=sys.stderr, flush=True)
        traceback.print_exc()
        return 2

    if not os.path.isfile(args.model):
        print(f"[FATAL] 模型文件不存在: {args.model}", file=sys.stderr, flush=True)
        return 2

    os.makedirs(args.save_dir, exist_ok=True)
    device = 0 if torch.cuda.is_available() else "cpu"

    try:
        model = YOLO(args.model)
    except Exception as exc:  # noqa: BLE001
        print(f"[FATAL] 加载模型失败: {exc}", file=sys.stderr, flush=True)
        traceback.print_exc()
        return 3

    names = []
    try:
        n = model.names
        names = [n[k] for k in sorted(n.keys())] if isinstance(n, dict) else list(n)
    except Exception:  # noqa: BLE001
        pass

    # ---------- 视频模式 ----------
    if args.video:
        print(f"[INFO] 设备: {'GPU' if device == 0 else 'CPU'}，视频模式", flush=True)
        video_summary = run_video(model, args, device, names)
        print("__RESULT__" + json.dumps(
            {"model_classes": names, "video": video_summary}, ensure_ascii=False), flush=True)
        return 0

    # ---------- 摄像头模式 ----------
    if args.camera >= 0:
        print(f"[INFO] 设备: {'GPU' if device == 0 else 'CPU'}，摄像头模式", flush=True)
        cam_summary = run_camera(model, args, device, names)
        print("__RESULT__" + json.dumps(
            {"model_classes": names, "camera": cam_summary}, ensure_ascii=False), flush=True)
        return 0

    # ---------- 图片模式 ----------
    images = collect_images(args.images)
    if not images:
        print("[FATAL] 没有找到可处理的图片", file=sys.stderr, flush=True)
        return 2

    print(f"[INFO] 设备: {'GPU' if device == 0 else 'CPU'}，共 {len(images)} 张图片", flush=True)
    results = []
    for path in images:
        boxes_out = []
        w_px = h_px = 0
        try:
            preds = model.predict(path, conf=args.conf, imgsz=args.imgsz,
                                  device=device, verbose=False)
            for r in preds:
                if r.boxes is None:
                    continue
                h_px, w_px = r.orig_shape[0], r.orig_shape[1]
                for box in r.boxes:
                    cls_id = int(box.cls[0].item())
                    cx, cy, bw, bh = [float(v) for v in box.xywhn[0].tolist()]
                    boxes_out.append({
                        "class_id": cls_id,
                        "class_name": str(names[cls_id]) if cls_id < len(names) else f"class_{cls_id}",
                        "cx": round(cx, 6), "cy": round(cy, 6),
                        "w": round(bw, 6), "h": round(bh, 6),
                        "score": round(float(box.conf[0].item()), 4),
                    })
        except torch.cuda.OutOfMemoryError:
            torch.cuda.empty_cache()
            print(f"[WARN] {path} 显存不足，跳过", file=sys.stderr, flush=True)
            continue
        except Exception as exc:  # noqa: BLE001
            print(f"[WARN] {path} 处理失败: {exc}", file=sys.stderr, flush=True)
            continue

        vis_path = os.path.join(
            args.save_dir,
            os.path.splitext(os.path.basename(path))[0] + "_det" + os.path.splitext(path)[1].lower(),
        )
        try:
            draw_boxes(path, boxes_out, vis_path, names)
        except Exception as exc:  # noqa: BLE001
            vis_path = ""
            print(f"[WARN] 画框失败: {exc}", file=sys.stderr, flush=True)

        results.append({
            "image": path,
            "width": w_px, "height": h_px,
            "vis_path": vis_path,
            "boxes": boxes_out,
        })
        print(f"[PROGRESS] {len(results)}/{len(images)}", flush=True)

    payload = {"model_classes": names, "results": results, "save_dir": args.save_dir}
    print("__RESULT__" + json.dumps(payload, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
