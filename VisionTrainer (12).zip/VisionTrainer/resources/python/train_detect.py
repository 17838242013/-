"""
YOLO11 目标检测训练脚本。

设计约束（改代码前请先读）：
1. 这个脚本被 C# 以子进程方式调用，所有进度必须打到 stdout，且不能依赖 tqdm 的
   覆盖式刷新（重定向后 tqdm 会把进度写成单行无换行，正则匹配不到）。
   所以这里关掉 tqdm，用 callback 自己 print 结构化行。
2. 只允许通过命令行参数接收配置，不读环境变量、不读全局配置文件。
3. 任何异常都必须 print 到 stderr 并以非 0 退出码结束，C# 侧靠退出码判定成败。
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import traceback
import warnings

warnings.filterwarnings("ignore")

# 让 tqdm 输出可被重定向解析（必须在 import ultralytics 之前设置）
os.environ.setdefault("TQDM_DISABLE", "1")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="VisionTrainer YOLO detection training")
    p.add_argument("--data", required=True, help="data.yaml 绝对路径")
    p.add_argument("--workdir", required=True, help="任务工作目录，产物写在这里")
    p.add_argument("--model", default="yolo11n", help="基础模型，如 yolo11n/yolo11s")
    p.add_argument("--epochs", type=int, default=100)
    p.add_argument("--batch", type=int, default=16)
    p.add_argument("--imgsz", type=int, default=640)
    p.add_argument("--lr0", type=float, default=0.01)
    p.add_argument("--patience", type=int, default=30)
    p.add_argument("--workers", type=int, default=0)
    p.add_argument("--augment", type=int, default=1)
    p.add_argument("--pretrained", type=int, default=1)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--resume", action="store_true")
    p.add_argument("--weights-dir", default="", help="C# 侧预下载权重的目录")
    p.add_argument("--names-json", default="", help="类别名映射 {index: name}")
    p.add_argument("--set", action="append", default=[], help="额外 ultralytics 参数 key=value")
    return p


def resolve_weights(model_name: str, workdir: str, allow_download: bool, weights_dir: str = "") -> str:
    """
    优先用随程序分发的本地权重（离线可用），其次用 ultralytics 缓存，最后才联网下载。
    客户内网机器联网会卡很久，本地权重是"开箱即用"体验的关键。

    weights_dir: C# 侧在装环境时自动下载权重的目录（%LOCALAPPDATA%\VisionTrainer\weights），
    训练前权重就已就位，这里只是接住它。
    """
    if model_name.endswith(".pt"):
        return model_name

    exe_dir = os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))
    candidates = [
        os.path.join(weights_dir, f"{model_name}.pt") if weights_dir else "",
        os.path.join(exe_dir, "resources", "weights", f"{model_name}.pt"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "weights", f"{model_name}.pt"),
        os.path.join(workdir, f"{model_name}.pt"),
    ]
    for c in candidates:
        if c and os.path.isfile(c):
            print(f"[INFO] 使用本地权重: {c}", flush=True)
            return c

    if not allow_download:
        raise FileNotFoundError(
            f"未找到本地权重 {model_name}.pt，且当前为离线模式。"
            f"请在「设置」页点一次「安装 / 修复运行环境」（会自动下载 5.4MB 的权重），"
            f"或手动把 {model_name}.pt 放到 {weights_dir or 'resources/weights/'} 目录下。"
        )

    print(f"[INFO] 本地无 {model_name}.pt，将从官方源下载（首次较慢）", flush=True)
    return f"{model_name}.pt"


def main() -> int:
    args = build_parser().parse_args()

    try:
        import torch
        from ultralytics import YOLO
        from ultralytics.utils import LOGGER
    except Exception as exc:  # noqa: BLE001
        print(f"[FATAL] 导入依赖失败: {exc}", file=sys.stderr, flush=True)
        traceback.print_exc()
        return 2

    device = 0 if torch.cuda.is_available() else "cpu"
    if device == 0:
        gpu_name = torch.cuda.get_device_name(0)
        total_mb = torch.cuda.get_device_properties(0).total_memory // (1024 * 1024)
        print(f"[INFO] 训练设备: GPU {gpu_name} ({total_mb} MB)", flush=True)
    else:
        print("[WARN] 未检测到可用 GPU，使用 CPU 训练。速度会慢 20~50 倍。", flush=True)

    # 关掉 ultralytics 的联网检查/遥测，避免内网环境长时间卡住
    LOGGER.setLevel("INFO")

    names_map = {}
    if args.names_json:
        try:
            names_map = {int(k): v for k, v in json.loads(args.names_json).items()}
        except Exception:  # noqa: BLE001
            names_map = {}

    allow_download = args.pretrained == 1 and not os.environ.get("YOLO_OFFLINE")
    weights = resolve_weights(args.model, args.workdir, allow_download, args.weights_dir)

    train_kwargs = dict(
        data=args.data,
        epochs=args.epochs,
        batch=args.batch,
        imgsz=args.imgsz,
        lr0=args.lr0,
        patience=args.patience if args.patience > 0 else 0,
        workers=args.workers,
        device=device,
        project=args.workdir,
        name="runs/detect/train",
        exist_ok=True,
        seed=args.seed,
        deterministic=False,
        # 客户常是小样本数据集：这几项对小数据提升最明显
        cache=False,
        cos_lr=True,
        close_mosaic=10,
        plots=True,
        val=True,
        verbose=True,
    )
    if args.pretrained == 1 and os.path.isfile(weights):
        train_kwargs["pretrained"] = True
    if args.augment == 0:
        train_kwargs.update(
            mosaic=0.0, mixup=0.0, copy_paste=0.0, degrees=0.0,
            shear=0.0, perspective=0.0, hsv_h=0.0, hsv_s=0.0, hsv_v=0.0,
            fliplr=0.0, flipud=0.0, scale=0.0, translate=0.0,
        )

    # 透传额外参数，做类型转换避免字符串传成 int 参数时报错
    for item in args.set:
        if "=" not in item:
            continue
        key, value = item.split("=", 1)
        train_kwargs[key.strip()] = _coerce(value.strip())

    def on_epoch_end(trainer) -> None:
        """
        每轮结束打印一行结构化汇总，C# 侧正则解析。
        格式固定，改动必须同步 DetectionProgressParser。
        """
        epoch = int(getattr(trainer, "epoch", 0)) + 1
        total = int(getattr(trainer, "epochs", args.epochs))
        metrics = getattr(trainer, "metrics", {}) or {}
        loss_items = getattr(trainer, "label_loss_items", None)
        losses = loss_items() if callable(loss_items) else {}

        box_loss = _first(losses, ("train/box_loss", "box_loss"))
        cls_loss = _first(losses, ("train/cls_loss", "cls_loss"))
        dfl_loss = _first(losses, ("train/dfl_loss", "dfl_loss"))

        # 单轮训练行（供进度解析）
        print(
            f"      {epoch}/{total}  "
            f"{_fmt(box_loss)}  {_fmt(cls_loss)}  {_fmt(dfl_loss)}",
            flush=True,
        )

        # 验证汇总行（供指标解析）
        p = metrics.get("metrics/precision(B)")
        r = metrics.get("metrics/recall(B)")
        m50 = metrics.get("metrics/mAP50(B)")
        m5095 = metrics.get("metrics/mAP50-95(B)")
        if m5095 is not None:
            print("                  Class     Images  Instances      Box(P          R      mAP50  mAP50-95)",
                  flush=True)
            print(
                f"                    all          -          -      "
                f"{_fmt(p)}      {_fmt(r)}      {_fmt(m50)}      {_fmt(m5095)}",
                flush=True,
            )

        lr = None
        for group in getattr(getattr(trainer, "optimizer", None), "param_groups", []) or []:
            lr = group.get("lr")
            break
        print(f"[PROGRESS] epoch={epoch} total={total} lr={lr}", flush=True)

    try:
        model = YOLO(weights)
        model.add_callback("on_train_epoch_end", on_epoch_end)
        model.train(**train_kwargs)
    except torch.cuda.OutOfMemoryError:
        print(
            f"[FATAL] 显存不足（当前 batch={args.batch}, imgsz={args.imgsz}）。"
            f"请把批大小或输入尺寸调小后重试。",
            file=sys.stderr, flush=True,
        )
        return 3
    except Exception as exc:  # noqa: BLE001
        print(f"[FATAL] 训练失败: {exc}", file=sys.stderr, flush=True)
        traceback.print_exc()
        return 4

    # 训练完顺手导出 ONNX，客户拿去部署不用再装 Python
    best = os.path.join(args.workdir, "runs", "detect", "train", "weights", "best.pt")
    if os.path.isfile(best):
        print(f"[INFO] 最优模型: {best}", flush=True)
        try:
            YOLO(best).export(format="onnx", imgsz=args.imgsz, opset=12, simplify=True)
            print("[INFO] ONNX 导出完成", flush=True)
        except Exception as exc:  # noqa: BLE001
            # 导出失败不应判定训练失败，只提示
            print(f"[WARN] ONNX 导出失败（不影响模型使用）: {exc}", flush=True)
    else:
        print("[WARN] 未找到 best.pt，训练可能未正常完成", file=sys.stderr, flush=True)

    return 0


def _coerce(value: str):
    for cast in (int, float):
        try:
            return cast(value)
        except ValueError:
            continue
    if value.lower() in ("true", "false"):
        return value.lower() == "true"
    return value


def _first(mapping: dict, keys: tuple) -> float | None:
    if not isinstance(mapping, dict):
        return None
    for k in keys:
        if k in mapping and mapping[k] is not None:
            try:
                return float(mapping[k])
            except (TypeError, ValueError):
                continue
    return None


def _fmt(value) -> str:
    return "0.0000" if value is None else f"{float(value):.4f}"


if __name__ == "__main__":
    sys.exit(main())
