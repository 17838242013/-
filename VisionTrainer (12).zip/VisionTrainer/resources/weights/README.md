# 默认权重目录

## 为什么需要这个目录

`ultralytics` 默认会在首次训练时联网下载 `yolo11n.pt` 等预训练权重。
客户内网机器联网会被防火墙拦下，表现为"卡在下载中"或超时失败。
把权重随安装包分发，可以彻底消除这个故障点。

## 需要放哪些文件

| 文件 | 大小 | 何时需要 |
|---|---|---|
| `yolo11n.pt` | ~5.4 MB | 使用 Nano 模型 |
| `yolo11s.pt` | ~18 MB | 使用 Small 模型 |
| `yolo11m.pt` | ~38 MB | 使用 Medium 模型 |

下载地址（任选其一）：
- https://github.com/ultralytics/assets/releases
- 国内加速：搜索 "yolo11n.pt 镜像" 获取可用地址

## 命名要求

文件名必须与模型标识完全一致（`yolo11n.pt`、`yolo11s.pt`），
训练脚本按此规则查找，不做模糊匹配。
